import hashlib,json,shlex,subprocess,sys
from pathlib import Path
R=Path('/tmp/mimalloc-585-ci-failure');B=R/'build';phase=sys.argv[1]
src=Path('test/test-arena-reclaim.cpp').resolve();text=src.read_text()
text='#ifndef MI_TEST_STALL_WORKER_DELAY_US\n#define MI_TEST_STALL_WORKER_DELAY_US 200000\n#endif\n'+text
for worker in ['stall_worker','park_worker']:
 needle='static THREAD_RET '+worker+'(void* arg) {\n  (void)arg;'
 assert text.count(needle)==1
 text=text.replace(needle,needle+'\n  usleep(MI_TEST_STALL_WORKER_DELAY_US); // diagnostic-only controlled scheduling delay')
probe=R/(phase+'.cpp');probe.write_text(text);obj=R/(phase+'.o');exe=R/phase
command=next(c for c in json.loads((B/'compile_commands.json').read_text()) if Path(c['file'])==src)
args=shlex.split(command['command']);assert args[0].endswith('/soldr') and args[1]=='c++'
args[args.index('-o')+1]=str(obj);args[args.index('-c')+1]=str(probe)
subprocess.run(args,cwd=B,check=True,capture_output=True,text=True)
link=subprocess.check_output(['ninja','-t','commands','mimalloc-test-arena-reclaim'],cwd=B,text=True).splitlines()[-1]
parts=shlex.split(link);assert parts[:2]==[':','&&'] and parts[-2:]==['&&',':'];parts=parts[2:-2];assert parts[0].endswith('/soldr') and parts[1]=='c++'
parts=[str(obj) if p.endswith('test-arena-reclaim.cpp.o') else p for p in parts];parts[parts.index('-o')+1]=str(exe)
subprocess.run(parts,cwd=B,check=True,capture_output=True,text=True)
p=subprocess.run([str(exe)],capture_output=True,text=True,timeout=30)
(R/(phase+'.stdout')).write_text(p.stdout);(R/(phase+'.stderr')).write_text(p.stderr)
result={'phase':phase,'delay_us_per_worker':200000,'exit_code':p.returncode,'library_sha256':hashlib.sha256((B/'libmimalloc-debug.a').read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'assertions':[s for s in p.stdout.splitlines() if 'A5:' in s or 'A6:' in s],'note':'Controlled delayed schedule; not proof of historical CI cause or performance acceptance.'}
(R/(phase+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
expected=1 if phase=='before' else 0
assert p.returncode==expected,(p.returncode,expected)
