import hashlib,json,os,subprocess,sys
from pathlib import Path
sys.path.insert(0,'/home/niteris/dev/mimalloc-pprof/ci')
import perf_ab
root=Path('/tmp/mimalloc-585/affinity-retention');exe=root/'bin-base-chart/perf_ab';cpus=sorted(os.sched_getaffinity(0))[:2]
params=perf_ab.WORKLOADS['large-class-ephemeral/8 (chart build)'][1];data={'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'baseline':'ee3623f6b7a485754a0a0aa3462d8cba43390e8b','cpus':cpus,'params':params._asdict(),'samples':[]}
for rep in range(6):
 p=subprocess.run(['taskset','-c',','.join(map(str,cpus)),str(exe),*map(str,params),'1300'],capture_output=True,text=True,check=True,env={'PATH':os.environ['PATH'],'MIMALLOC_PROF':'0','MIMALLOC_MEMORY_EVENTS':'0'})
 (root/f'null-repeat-{rep}.stdout').write_text(p.stdout);(root/f'null-repeat-{rep}.stderr').write_text(p.stderr)
 raw=list(map(float,p.stdout.split()));x={'rep':rep,'peak_MiB':raw[4]/2**20,'drain_MiB':raw[5]/2**20,'bound_MiB':raw[6]/2**20,'release_ms':raw[7]};data['samples'].append(x)
 (root/'null-repeat-results.json').write_text(json.dumps(data,indent=2));print(x,flush=True)
