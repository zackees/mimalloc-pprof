from pathlib import Path
import json,os,subprocess,sys
sys.path.insert(0,'/home/niteris/dev/mimalloc-pprof/ci')
import perf_ab
root=Path('/tmp/mimalloc-585/affinity-retention');root.mkdir(exist_ok=False)
try:
    exe=perf_ab.build('base','ee3623f6b7a485754a0a0aa3462d8cba43390e8b',root,'chart',[])
finally:
    for tree in root.glob('src-*'):
        subprocess.run(['safe-rm','-r',str(tree)],check=True)
    subprocess.run(['git','worktree','prune'],check=True)
cpus=sorted(os.sched_getaffinity(0))
params=perf_ab.WORKLOADS['large-class-ephemeral/8 (chart build)'][1]
records=[]
for rep in range(3):
    for count in ([1,4,2] if rep%2==0 else [2,4,1]):
        chosen=cpus[:count]
        cmd=['taskset','-c',','.join(map(str,chosen)),str(exe),*map(str,params),'1300']
        p=subprocess.run(cmd,capture_output=True,text=True,check=True,env={'PATH':os.environ['PATH'],'MIMALLOC_PROF':'0','MIMALLOC_MEMORY_EVENTS':'0'})
        (root/f'cpus-{count}-rep-{rep}.stdout').write_text(p.stdout)
        (root/f'cpus-{count}-rep-{rep}.stderr').write_text(p.stderr)
        raw=list(map(float,p.stdout.split()))
        records.append({'rep':rep,'cpus':chosen,'peak_MiB':raw[4]/2**20,'drain_MiB':raw[5]/2**20,'bound_MiB':raw[6]/2**20,'release_ms':raw[7]})
        (root/'results.json').write_text(json.dumps({'baseline':'ee3623f6b7a485754a0a0aa3462d8cba43390e8b','params':params._asdict(),'samples':records},indent=2))
        print(records[-1],flush=True)
