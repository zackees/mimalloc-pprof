import json,os,statistics,subprocess,sys
from pathlib import Path
ROOT=Path('/home/niteris/dev/mimalloc-pprof')
OUT=Path('/tmp/mimalloc-585/age-two-memory-screen')
OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'ci'))
import attribution_probe as probe
exes={}
try:
 for arm,defs in [('age-four',''),('age-two','MI_LARGE_AGE_STEP=2')]:
  out=OUT/arm
  out.mkdir(exist_ok=True)
  exes[arm]=probe.build(out,defs)
 results=[]
 for rep in range(3):
  arms=list(exes)
  if rep%2: arms.reverse()
  for arm in arms:
   cmd=[str(exes[arm]),*probe.ROWS['persistent'],'500']
   env=os.environ.copy()
   env['PERF_AB_HOLES_REPORT']='1'
   p=subprocess.run(cmd,capture_output=True,text=True,env=env,check=True)
   (OUT/f'{rep}-{arm}.stdout').write_text(p.stdout)
   (OUT/f'{rep}-{arm}.stderr').write_text(p.stderr)
   parsed=probe.parse(p.stdout,p.stderr)
   assert len(parsed['workers'])==8
   b=probe.buckets(parsed)
   results.append({'rep':rep,'arm':arm,'command':cmd,'buckets':b,'minor_faults_diagnostic_only':int(p.stdout.split()[3])})
   print(rep,arm,{k:round(b[k]/probe.MIB,3) for k in ('_peak','_rss','unformed, empty pages','unformed tail, partly used pages','free slices: queued for purge (resident)')},flush=True)
   (OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
except subprocess.CalledProcessError as e:
 print(e.stdout,e.stderr,file=sys.stderr)
 raise
print('Diagnostic screen only: no local CPU, throughput or p99 acceptance.',flush=True)
