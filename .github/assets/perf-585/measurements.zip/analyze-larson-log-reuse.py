import bisect,collections,json,statistics,struct
from pathlib import Path
R=Path('/tmp/mimalloc-585/larson-growth/arena-traced');SLICE=65536;LARGE=512*1024;out={}
for rec in json.loads((R/'results.json').read_text())['records']:
 arm=rec['arm'];g=rec['growth_events'];events=list(struct.iter_unpack('<QQII',(R/f'arena-{arm}.bin').read_bytes()));end=next(e['ns'] for e in g if e['kind']==6)
 bytable={i:[e for e in g if e['table']==i and e['kind'] in (1,2)] for i in range(8)};free_by_range=collections.defaultdict(list)
 for i,(addr,ns,n,freed) in enumerate(events):
  if freed:free_by_range[(addr,n*SLICE)].append((i,ns))
 frees=[]
 for t,trace in bytable.items():
  for before,after in zip(trace[::2],trace[1::2]):
   assert before['kind']==1 and after['kind']==2
   if before['usable']<=LARGE or not before['span'] or before['pointer']==after['pointer']:continue
   # For these singleton buffers the separate-metadata data pointer is the slice start.
   assert before['pointer']%SLICE==0
   matches=[(i,ns) for i,ns in free_by_range[(before['pointer'],before['span'])] if before['ns']<=ns<=after['ns']]
   assert len(matches)==1,(arm,t,before,matches)
   i,ns=matches[0];frees.append({'table':t,'requested':before['requested'],'address':before['pointer'],'span':before['span'],'event_index':i,'free_ns':ns})
 assert len(frees)==40,(arm,len(frees))
 keys={addr for f in frees for addr in range(f['address'],f['address']+f['span'],SLICE)};claims=collections.defaultdict(list)
 for i,(addr,ns,n,freed) in enumerate(events):
  if freed:continue
  for p in range(addr,addr+n*SLICE,SLICE):
   if p in keys:claims[p].append((i,ns,n))
 completed=[];censored=[];completed_payload=[];censored_payload=[];reused_by_small=0;perfree=[]
 for f in frees:
  c=[];z=[]
  for addr in range(f['address'],f['address']+f['span'],SLICE):
   xs=claims[addr];pos=bisect.bisect_right(xs,(f['event_index'],2**64,2**64))
   if pos<len(xs) and xs[pos][1]<=end:
    _,ns,n=xs[pos];dt=ns-f['free_ns'];assert dt>=0;c.append(dt);completed.append(dt);completed_payload.append((dt,max(0,min(SLICE,f['address']+f['requested']-addr))));reused_by_small+=n<=8
   else:z.append(end-f['free_ns']);censored.append(end-f['free_ns']);censored_payload.append((end-f['free_ns'],max(0,min(SLICE,f['address']+f['requested']-addr))))
  perfree.append({**f,'completed_slices':len(c),'censored_slices':len(z),'minimum_completed_us':min(c)/1000 if c else None,'maximum_completed_us':max(c)/1000 if c else None})
 result={'singleton_old_log_frees':len(frees),'old_log_slice_observations':len(completed)+len(censored),'completed_reused_slice_observations':len(completed),'right_censored_slice_observations':len(censored),'completed_reused_MiB_counting_each_old_log_free':len(completed)*SLICE/2**20,'first_reuse_claim_small_medium_slices':reused_by_small,'median_completed_reuse_us':statistics.median(completed)/1000 if completed else None,'completed_reuse_under_ms':{str(ms):sum(x<ms*1e6 for x in completed) for ms in (1,10,100,200,400)},'completed_payload_reuse_MiB':sum(w for dt,w in completed_payload)/2**20,'completed_payload_reuse_MiB_under_ms':{str(ms):sum(w for dt,w in completed_payload if dt<ms*1e6)/2**20 for ms in (1,10,100,200,400)},'right_censored_payload_MiB':sum(w for dt,w in censored_payload)/2**20,'per_free':perfree,'limits':['This is local instrumented address reuse, not proof of residency or CI hotness.','Slice observations may count an address again after a later distinct old-log free.','Censored slices have no observed later claim before work end; not proof of permanent coldness.','Small/medium classification uses claim slice_count<=8, not a precise page-type tag.']};out[arm]=result
 print(arm,{k:v for k,v in result.items() if k not in ('per_free','limits')})
(R/'old-log-reuse-summary.json').write_text(json.dumps(out,indent=2)+'\n')
