import hashlib,io,json,shutil,subprocess,tarfile
from pathlib import Path
R=Path('/tmp/mimalloc-585/huge-headroom');R.mkdir(exist_ok=True)
ref='3db601e13aace89ca44b2be9dbd59b2ee8f5f034'
tree=R/'src';tree.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',ref]))) as tar:tar.extractall(tree,filter='data')
p=tree/'src/page.c';s=p.read_text();needle='  const size_t block_size = _mi_os_good_alloc_size(size);';assert s.count(needle)==1
replacement=r"""  size_t block_size = _mi_os_good_alloc_size(size);
#ifndef MI_SCRATCH_HUGE_HEADROOM
#define MI_SCRATCH_HUGE_HEADROOM 0
#endif
#ifndef MI_HUGE_HEADROOM_MIN_SIZE
#define MI_HUGE_HEADROOM_MIN_SIZE (8 * MI_MiB)
#endif
#ifndef MI_HUGE_HEADROOM_FACTOR
#define MI_HUGE_HEADROOM_FACTOR 2
#endif
#if defined(__linux__) && MI_INTPTR_SIZE >= 8 && MI_SCRATCH_HUGE_HEADROOM
  // Scratch RSS experiment only: spare virtual capacity avoids a later copy.
  if (size >= MI_HUGE_HEADROOM_MIN_SIZE && page_alignment == 0 &&
      _mi_os_has_overcommit() && !mi_option_is_enabled(mi_option_allow_large_os_pages) &&
      !mi_option_is_enabled(mi_option_disallow_os_alloc) &&
      size <= MI_MAX_ALLOC_SIZE / MI_HUGE_HEADROOM_FACTOR - MI_MAX_ALIGN_SIZE) {
    block_size = _mi_align_up(size, MI_MAX_ALIGN_SIZE) * MI_HUGE_HEADROOM_FACTOR;
  }
#endif"""
p.write_text(s.replace(needle,replacement))
(R/'patch.diff').write_bytes(subprocess.check_output(['diff','-u','src/page.c',str(p)]) if False else b'')
r=subprocess.run(['diff','-u','src/page.c',str(p)],capture_output=True,check=False);assert r.returncode==1;(R/'patch.diff').write_bytes(r.stdout)
flags=['-DCMAKE_BUILD_TYPE=Release','-DMI_BUILD_SHARED=OFF','-DMI_BUILD_OBJECT=OFF','-DMI_BUILD_TESTS=OFF','-DMI_OVERRIDE=OFF','-DMI_PPROF=ON','-DMI_MEMEVT=ON','-DMI_DIAGNOSTICS=OFF','-DMI_DHAT=OFF','-DMI_OWNER_GATE=OFF','-DCMAKE_C_COMPILER='+shutil.which('soldr'),'-DCMAKE_C_COMPILER_ARG1=cc']
plan={'ref':ref,'flags':flags,'purpose':'scratch only RSS screen; original uninstrumented workload; three fixed alternating pairs','builds':{}}
for arm,enabled in [('control',0),('prototype',1)]:
 out=R/f'build-{arm}'
 with (R/f'{arm}-build.log').open('w') as log:
  subprocess.run(['cmake','-S',str(tree),'-B',str(out),*flags,f'-DCMAKE_C_FLAGS=-DMI_SCRATCH_HUGE_HEADROOM={enabled}'],stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['cmake','--build',str(out),'--target','mimalloc-static','--parallel','4'],stdout=log,stderr=subprocess.STDOUT,check=True)
  lib=next(out.glob('libmimalloc*.a'));exe=R/arm
  subprocess.run(['soldr','cc','-O2','-DNDEBUG','-DMI_DEBUG=0','-DMI_PPROF=1','-DMI_MEMEVT=1','-I',str(tree/'include'),str(tree/'ci/perf_ab.c'),str(lib),'-lpthread','-o',str(exe)],stdout=log,stderr=subprocess.STDOUT,check=True)
 plan['builds'][arm]={'library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'enabled':enabled}
 (R/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(arm,'built through soldr',flush=True)
