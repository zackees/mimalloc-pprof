import hashlib,json,shutil,subprocess
from pathlib import Path
R=Path('/tmp/mimalloc-585/larson-growth');T=R/'arena-traced';T.mkdir(exist_ok=True)
patch=Path('/tmp/mimalloc-585/reuse-trace.patch').read_text();hunk=patch.split('@@',2)[2].split('@@',1)[0];helper='\n'.join(line[1:] for line in hunk.splitlines() if line.startswith('+'))+'\n'
assert 'static void mi_scratch_record' in helper and '__attribute__((destructor))' in helper
meta={'purpose':'untimed arena-claim/free reuse attribution plus per-log growth events; no policy/acceptance change','workload':['8','1','8','1000','2500000','0','5000','uniform','8','1300'],'builds':{}}
for arm in ('base','head'):
 tree=R/f'src-{arm}';p=tree/'src/arena.c';s=p.read_text();assert 'mi_scratch_record' not in s
 marker='// #493 (strategy 9): resident-first claiming.';assert marker in s;s=s.replace(marker,helper+'\n'+marker,1)
 marker='if (!resident && !mi_bbitmap_try_find_and_clearN(arena->slices_free, tseq, slice_count, &slice_index)) return NULL;';assert marker in s;s=s.replace(marker,marker+'\n  mi_scratch_record(arena, slice_index, slice_count, false);',1)
 marker='bool all_inuse = mi_bbitmap_setN(arena->slices_free, slice_index, slice_count);';assert marker in s;s=s.replace(marker,'mi_scratch_record(arena, slice_index, slice_count, true);\n    '+marker,1);p.write_text(s)
 lib=R/f'build-{arm}'/'libmimalloc.a';shutil.copy2(lib,R/f'phase1-lib-{arm}.a')
 with (T/f'{arm}-build.log').open('w') as log:
  subprocess.run(['cmake','--build',str(R/f'build-{arm}'),'--target','mimalloc-static','--parallel','4'],stdout=log,stderr=subprocess.STDOUT,check=True)
  exe=T/f'growth-{arm}';subprocess.run(['soldr','cc','-O2','-DNDEBUG','-DMI_DEBUG=0','-DMI_PPROF=1','-DMI_MEMEVT=1','-I',str(tree/'include'),str(R/'perf_ab_growth.c'),str(lib),'-lpthread','-o',str(exe)],stdout=log,stderr=subprocess.STDOUT,check=True)
 meta['builds'][arm]={'arena_source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'lib_sha256':hashlib.sha256(lib.read_bytes()).hexdigest()};print(arm,'arena callbacks built through soldr',flush=True)
(T/'plan.json').write_text(json.dumps(meta,indent=2)+'\n')
