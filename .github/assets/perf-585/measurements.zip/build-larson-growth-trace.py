import hashlib,io,json,shutil,subprocess,tarfile
from pathlib import Path
R=Path('/tmp/mimalloc-585/larson-growth');R.mkdir(exist_ok=True)
refs={'base':'ee3623f6b7a485754a0a0aa3462d8cba43390e8b','head':'3db601e13aace89ca44b2be9dbd59b2ee8f5f034'}
source=Path('ci/perf_ab.c').read_text()
helper=r'''
#ifndef TRACE_GROW_CAPACITY
#define TRACE_GROW_CAPACITY 4096
#endif
#ifndef TRACE_GROW_TABLES
#define TRACE_GROW_TABLES 256
#endif
typedef struct { uint64_t ns,kind,table,pointer,requested,usable,span,rss,peak,live_log_requested; } grow_event_t;
static grow_event_t grow_events[TRACE_GROW_CAPACITY];
static atomic_size_t grow_count;
static atomic_size_t grow_requested[TRACE_GROW_TABLES];
static long peak_rss_bytes(void);
static void grow_record(unsigned kind,size_t index,void* pointer,size_t requested) {
  size_t n=atomic_fetch_add(&grow_count,1);if(n>=TRACE_GROW_CAPACITY)return;
  struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);
  const mi_page_t* page=pointer?_mi_ptr_page(pointer):NULL;
  uint64_t span=page&&page->memid.memkind==MI_MEM_ARENA?mi_size_of_slices(page->memid.mem.arena.slice_count):0;
  size_t live=0;for(int i=0;i<threads&&i<TRACE_GROW_TABLES;i++)live+=atomic_load(&grow_requested[i]);
  grow_events[n]=(grow_event_t){(uint64_t)ts.tv_sec*UINT64_C(1000000000)+(uint64_t)ts.tv_nsec,kind,index,(uintptr_t)pointer,requested,pointer?mi_usable_size(pointer):0, (uint64_t)span,(uint64_t)rss_bytes(),(uint64_t)peak_rss_bytes(),live};
}
static void grow_dump(void) {
 const char* path=getenv("PERF_AB_GROW_TRACE");if(!path)return;
 size_t n=atomic_load(&grow_count);if(n>TRACE_GROW_CAPACITY){fprintf(stderr,"growth trace overflow %zu\n",n);exit(1);}
 FILE* out=fopen(path,"wb");if(!out){perror(path);exit(1);}if(fwrite(grow_events,sizeof(grow_events[0]),n,out)!=n){perror(path);exit(1);}fclose(out);
}
'''
source=source.replace('#include <mimalloc.h>','#include <mimalloc.h>\n#include "mimalloc/internal.h"',1)
assert 'static void larson_round(' in source
source=source.replace('static void larson_round(',helper+'\nstatic void larson_round(',1)
a='if (tb->log_len == tb->log_cap) {   /* as the harness\'s VecDeque::push_back: double */';assert a in source
source=source.replace(a,a+'\n      grow_record(1,(size_t)(tb-tables),tb->log,tb->log_cap*sizeof(size_t));',1)
a='if (tb->log == NULL) { fprintf(stderr, "allocation failed\\n"); exit(1); }';assert a in source
source=source.replace(a,a+'\n      atomic_store(&grow_requested[tb-tables],tb->log_cap*sizeof(size_t));\n      grow_record(2,(size_t)(tb-tables),tb->log,tb->log_cap*sizeof(size_t));',1)
a='mi_free(own->log); own->log = NULL;';assert a in source
source=source.replace(a,'grow_record(3,(size_t)st->index,own->log,own->log_cap*sizeof(size_t));\n    '+a+'\n    atomic_store(&grow_requested[st->index],0);grow_record(4,(size_t)st->index,NULL,0);',1)
a='tables[i].log = (size_t*)mi_malloc(tables[i].log_cap * sizeof(size_t));';assert a in source
source=source.replace(a,a+'\n      atomic_store(&grow_requested[i],tables[i].log_cap*sizeof(size_t));grow_record(0,(size_t)i,tables[i].log,tables[i].log_cap*sizeof(size_t));',1)
a='for (int i = 0; i < threads; i++) pthread_create(&t[i], NULL, &worker_main, &st[i]);';assert a in source
source=source.replace(a,'if(threads>TRACE_GROW_TABLES)exit(1);grow_record(5,0,NULL,0);\n  '+a,1)
a='while (atomic_load(&drained) < threads) usleep(100);';assert a in source
source=source.replace(a,a+'\n  grow_record(6,0,NULL,0);',1)
i=source.rfind('return 0;');assert i>=0;source=source[:i]+'grow_dump();\n  '+source[i:]
(R/'perf_ab_growth.c').write_text(source)
flags=['-DCMAKE_BUILD_TYPE=Release','-DMI_BUILD_SHARED=OFF','-DMI_BUILD_OBJECT=OFF','-DMI_BUILD_TESTS=OFF','-DMI_OVERRIDE=OFF','-DMI_PPROF=ON','-DMI_MEMEVT=ON','-DMI_DIAGNOSTICS=OFF','-DMI_DHAT=OFF','-DMI_OWNER_GATE=OFF','-DCMAKE_C_COMPILER='+shutil.which('soldr'),'-DCMAKE_C_COMPILER_ARG1=cc']
plan={'purpose':'untimed local growth/realloc/RSS attribution, not exact CI executable or acceptance','refs':refs,'feature_flags':flags,'workload':['8','1','8','1000','2500000','0','5000','uniform','8','1300'],'harness_sha256':hashlib.sha256(source.encode()).hexdigest(),'limits':['Per-growth clock and proc reads perturb scheduling.','Atomic per-table requested-log counters are sampled, not a simultaneous global state.','RSS minus current log requests includes objects, rounding, queues and other mappings; not a direct queue measurement.','No workload seed, operation count, size choice, slot/table count, or log-growth rule changed.'],'builds':{}}
(R/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for arm,ref in refs.items():
 tree=R/f'src-{arm}';tree.mkdir(exist_ok=True)
 archive=subprocess.check_output(['git','archive',ref])
 with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(tree,filter='data')
 out=R/f'build-{arm}'
 with (R/f'{arm}-build.log').open('w') as log:
  subprocess.run(['cmake','-S',str(tree),'-B',str(out),*flags],stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(['cmake','--build',str(out),'--target','mimalloc-static','--parallel','4'],stdout=log,stderr=subprocess.STDOUT,check=True)
  lib=next(out.glob('libmimalloc*.a'));exe=R/f'growth-{arm}'
  subprocess.run(['soldr','cc','-O2','-DNDEBUG','-DMI_DEBUG=0','-DMI_PPROF=1','-DMI_MEMEVT=1','-I',str(tree/'include'),str(R/'perf_ab_growth.c'),str(lib),'-lpthread','-o',str(exe)],stdout=log,stderr=subprocess.STDOUT,check=True)
 plan['builds'][arm]={'library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
 (R/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(arm,'built through soldr',flush=True)
