#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
#ifndef TRACE_CAPACITY
#define TRACE_CAPACITY 16384
#endif
typedef struct { uint64_t start,end,kind,tid,address,length,result; _Atomic int ready; } event_t;
static event_t events[TRACE_CAPACITY];
static _Atomic size_t count;
static int (*real_madvise)(void*,size_t,int);
static int (*real_usleep)(useconds_t);
static uint64_t stamp(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return (uint64_t)t.tv_sec*UINT64_C(1000000000)+(uint64_t)t.tv_nsec; }
static void record(uint64_t start,uint64_t end,uint64_t kind,uint64_t addr,uint64_t len,int result) {
 size_t i=atomic_fetch_add_explicit(&count,1,memory_order_relaxed); if(i>=TRACE_CAPACITY)return;
 event_t* e=&events[i];e->start=start;e->end=end;e->kind=kind;e->tid=(uint64_t)syscall(SYS_gettid);e->address=addr;e->length=len;e->result=(uint64_t)(int64_t)result;atomic_store_explicit(&e->ready,1,memory_order_release);
}
__attribute__((constructor)) static void init(void) { real_madvise=dlsym(RTLD_NEXT,"madvise");real_usleep=dlsym(RTLD_NEXT,"usleep");if(!real_madvise||!real_usleep)_exit(127);uint64_t t=stamp();record(t,t,0,(uint64_t)getpid(),0,0); }
int madvise(void* p,size_t n,int advice) { uint64_t s=stamp();int rc=real_madvise(p,n,advice);int saved=errno;record(s,stamp(),(uint64_t)advice+10,(uint64_t)(uintptr_t)p,n,rc);errno=saved;return rc; }
int usleep(useconds_t delay) { if(syscall(SYS_gettid)!=getpid())return real_usleep(delay);uint64_t s=stamp();int rc=real_usleep(delay);int saved=errno;record(s,stamp(),1,0,(uint64_t)delay,rc);errno=saved;return rc; }
static int write_all(int fd,const void* p,size_t n) { const char* q=p;while(n){ssize_t w=write(fd,q,n);if(w<0&&errno==EINTR)continue;if(w<=0)return 0;q+=w;n-=(size_t)w;}return 1; }
__attribute__((destructor)) static void dump(void) { const char* p=getenv("MIMALLOC_ATTRIB_TRACE");if(!p)return;int fd=open(p,O_WRONLY|O_CREAT|O_TRUNC,0600);if(fd<0)return;size_t n=atomic_load_explicit(&count,memory_order_acquire);uint64_t header[7]={stamp(),stamp(),2,(uint64_t)getpid(),n,TRACE_CAPACITY,0};if(!write_all(fd,header,sizeof(header))){close(fd);return;}if(n>TRACE_CAPACITY)n=TRACE_CAPACITY;for(size_t i=0;i<n;i++){event_t*e=&events[i];if(!atomic_load_explicit(&e->ready,memory_order_acquire))continue;uint64_t words[7]={e->start,e->end,e->kind,e->tid,e->address,e->length,e->result};if(!write_all(fd,words,sizeof(words)))break;}close(fd); }
