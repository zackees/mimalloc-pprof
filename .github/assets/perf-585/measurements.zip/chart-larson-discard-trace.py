import hashlib,json,os,struct,subprocess
from pathlib import Path
R=Path('/tmp/mimalloc-585');cpus=sorted(os.sched_getaffinity(0))[:4];records=[]
for rep in range(2):
 for arm in (('base','head') if rep==0 else ('head','base')):
  exe=R/'current-chart-larson-followup/builds'/arm/'chart/perf_ab';trace=R/f'chart-larson-trace-{rep}-{arm}.bin'
  env=dict(os.environ,LD_PRELOAD=str(R/'chart-larson-discard-trace.so'),MIMALLOC_ATTRIB_TRACE=str(trace),MIMALLOC_PROF='0',MIMALLOC_MEMORY_EVENTS='0')
  cmd=['taskset','-c',','.join(map(str,cpus)),str(exe),'8','1','8','1000','2500000','0','5000','uniform','8','1300']
  run=subprocess.run(cmd,env=env,capture_output=True,text=True,check=True)
  ev=list(struct.iter_unpack('<7Q',trace.read_bytes()));header=ev[0];assert header[2]==2 and header[4]<=header[5],header
  events=ev[1:];start=next(x[0] for x in events if x[2]==0);sleep=[x for x in events if x[2]==1];drain=next(x[0] for x in sleep if x[5]>1000)
  # First main-thread long sleep follows the drain's first RSS sample; approx drain+10ms.
  discard=[x for x in events if x[2]==14 and x[6]==0];post=[x for x in discard if x[0]>=drain]
  rec={'rep':rep,'arm':arm,'command':cmd,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'trace_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'stdout':run.stdout,'stderr':run.stderr,'events':len(events),'captured_counter':header[4],'main_first_drain_sleep_since_init_ms':(drain-start)/1e6,'post_drain_discard_calls':len(post),'post_drain_discard_MiB':sum(x[5] for x in post)/2**20,'post_drain_discards':[{'start_after_first_drain_sleep_ms':(x[0]-drain)/1e6,'duration_ms':(x[1]-x[0])/1e6,'MiB':x[5]/2**20,'tid':x[3]} for x in post]}
  records.append(rec);(R/'chart-larson-discard-trace.json').write_text(json.dumps({'purpose':'untimed exact-binary OS discard attribution, not acceptance','cpus':cpus,'plan':'two alternating pairs, no discarded observations','limits':['Preload records perturb timing; different host from CI.','First main-thread >1000us usleep approximates drain+10ms, not exact drain start.','madvise length is virtual range, not proof all those bytes were resident.'],'shim_source_sha256':hashlib.sha256((R/'chart-larson-discard-trace.c').read_bytes()).hexdigest(),'shim_so_sha256':hashlib.sha256((R/'chart-larson-discard-trace.so').read_bytes()).hexdigest(),'records':records},indent=2)+'\n');print(rep,arm,'events',len(events),'drain sleep',rec['main_first_drain_sleep_since_init_ms'],'postdiscard MiB',rec['post_drain_discard_MiB'],'RSS output',run.stdout.strip(),flush=True)
