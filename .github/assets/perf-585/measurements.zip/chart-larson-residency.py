import hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path('/tmp/mimalloc-585');OUT=ROOT/'chart-larson-residency.json'
CPUS=sorted(os.sched_getaffinity(0))[:4]

def sample(pid,exe):
    groups={};huge={};group='other';regions=[];region=None
    for line in Path(f'/proc/{pid}/smaps').read_text().splitlines():
        f=line.split()
        if len(f)>=5 and '-' in f[0] and ':' not in f[0]:
            path=f[5] if len(f)>5 else ''
            group=('binary' if path==str(exe) else 'stack' if path.startswith('[stack') else 'heap' if path=='[heap]' else 'anonymous' if not path else 'other')
            region={'range':f[0],'group':group,'path':path};regions.append(region)
        elif line.startswith('Rss:'):
            groups[group]=groups.get(group,0)+int(f[1])*1024
            if region is not None:region['rss_bytes']=int(f[1])*1024
        elif line.startswith('AnonHugePages:'):
            huge[group]=huge.get(group,0)+int(f[1])*1024
            if region is not None:region['anon_huge_bytes']=int(f[1])*1024
    status={}
    for line in Path(f'/proc/{pid}/status').read_text().splitlines():
        if line.startswith(('VmRSS:','VmHWM:')):status[line.split(':')[0]]=int(line.split()[1])*1024
    return {'rss_by_group':groups,'anon_huge_by_group':huge,'status':status,'regions':regions}

results=[]
for rep in range(6):
    for arm in (('base','head') if rep%2==0 else ('head','base')):
        exe=ROOT/'current-chart-larson-followup/builds'/arm/'chart/perf_ab'
        env=dict(os.environ,MIMALLOC_PROF='0',MIMALLOC_MEMORY_EVENTS='0')
        cmd=['taskset','-c',','.join(map(str,CPUS)),str(exe),'8','1','8','1000','2500000','0','5000','uniform','8','1300']
        start=time.monotonic();p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env);snaps=[]
        while p.poll() is None:
            try:
                shot=sample(p.pid,exe);shot['since_launch_s']=time.monotonic()-start;snaps.append(shot)
            except (FileNotFoundError,ProcessLookupError):pass
            time.sleep(.05)
        stdout,stderr=p.communicate()
        if p.returncode:raise RuntimeError((rep,arm,p.returncode,stderr))
        row={'rep':rep,'arm':arm,'command':cmd,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'snapshots':snaps,'stdout':stdout,'stderr':stderr}
        results.append(row)
        OUT.write_text(json.dumps({'purpose':'untimed exact-CI-binary local residency attribution; no CPU/latency/performance acceptance','cpus':CPUS,'plan':'six alternating pairs, no discarded observations or adaptive retry','limits':['External smaps sampling perturbs scheduling.','Launch-relative time is not an authoritative work/drain boundary.','This host is not the CI host; no CI cause or acceptance follows from local observations.'],'results':results},indent=1)+'\n')
        vals=stdout.split();print(rep,arm,'peak/drain/bound MiB',[round(int(vals[i])/2**20,3) for i in (4,5,6)],'release_ms',vals[7],'last_groups',snaps[-1]['rss_by_group'] if snaps else {},flush=True)
