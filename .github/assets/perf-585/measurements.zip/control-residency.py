import hashlib,json,os,struct,subprocess,time
from pathlib import Path
ROOT=Path('/tmp/mimalloc-585/balanced-combined-controls/builds')
OUT=Path('/tmp/mimalloc-585/control-residency.json')
PAGE=os.sysconf('SC_PAGE_SIZE')
CPUS=sorted(os.sched_getaffinity(0))[:4]

def sample(pid,exe):
    maps=Path(f'/proc/{pid}/maps').read_text().splitlines()
    file_pages=[]
    with open(f'/proc/{pid}/pagemap','rb',buffering=0) as pm:
        for line in maps:
            fields=line.split(maxsplit=5)
            if len(fields)<6 or fields[5]!=str(exe): continue
            lo,hi=(int(v,16) for v in fields[0].split('-'))
            offset=int(fields[2],16)
            pm.seek(lo//PAGE*8)
            bits=pm.read((hi-lo)//PAGE*8)
            for index,(value,) in enumerate(struct.iter_unpack('Q',bits)):
                if value>>63: file_pages.append({'offset':offset+index*PAGE,'perms':fields[1]})
    groups={}
    group='other'
    for line in Path(f'/proc/{pid}/smaps').read_text().splitlines():
        fields=line.split()
        if len(fields)>=5 and '-' in fields[0] and ':' not in fields[0]:
            path=fields[5] if len(fields)>5 else ''
            group=('binary' if path==str(exe) else 'stack' if path.startswith('[stack') else 'heap' if path=='[heap]' else 'anonymous' if not path else 'other')
        elif line.startswith('Rss:'):
            groups[group]=groups.get(group,0)+int(fields[1])*1024
    return {'rss_by_group':groups,'file_pages':file_pages}

results=[]
# Three alternating paired blocks; untimed diagnostic, not a performance ledger.
for rep in range(3):
    for arm in (('base','head') if rep%2==0 else ('head','base')):
        exe=ROOT/arm/'plain/perf_ab'
        env=os.environ.copy();env.update(MIMALLOC_PROF='0',MIMALLOC_MEMORY_EVENTS='0')
        cmd=['taskset','-c',','.join(map(str,CPUS)),str(exe),'8','1','16','1024','5000000','0','0','uniform','8','1300']
        p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env)
        snapshots=[]
        while p.poll() is None:
            try: snapshots.append(sample(p.pid,exe))
            except FileNotFoundError: pass
            time.sleep(.1)
        stdout,stderr=p.communicate()
        if p.returncode: raise RuntimeError((p.returncode,stderr))
        result={'rep':rep,'arm':arm,'command':cmd,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'snapshots':snapshots,'stdout':stdout,'stderr':stderr}
        results.append(result)
        OUT.write_text(json.dumps({'purpose':'untimed local residency attribution only; no timing acceptance','cpus':CPUS,'results':results},indent=1)+'\n')
        if snapshots:
            last=snapshots[-1]
            print(rep,arm,'snapshots',len(snapshots),'last RSS',last['rss_by_group'],'present executable file pages',len(last['file_pages']),flush=True)
