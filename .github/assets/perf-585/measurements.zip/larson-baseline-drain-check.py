import hashlib,json,os,subprocess
from pathlib import Path
root=Path('/tmp/mimalloc-585')
r=root/'balanced-byte-threshold-controls-failure'
d=json.loads((r/'perf-ab-samples.json').read_text())
p=d['workloads']['larson/1']['params']
exe=r/'builds/base/plain/perf_ab'
args=[p[k] for k in ('threads','generations','min_size','max_size','ops','pause_ms','table_slots','sizes','slots')]
cpus=','.join(map(str,sorted(os.sched_getaffinity(0))[:4]))
cmd=['taskset','-c',cpus,str(exe),*map(str,args),str(d['release_bound_ms'])]
env=os.environ.copy();env.update(MIMALLOC_PROF='0',MIMALLOC_MEMORY_EVENTS='0')
rows=[]
for rep in range(12):
 q=subprocess.run(cmd,capture_output=True,text=True,check=True,env=env)
 vals=list(map(float,q.stdout.split()))
 row={'rep':rep,'peak_MiB':vals[4]/(1<<20),'drain_MiB':vals[5]/(1<<20),'bound_MiB':vals[6]/(1<<20),'release_ms':vals[7]}
 rows.append(row)
 (root/f'larson-null-{rep}.stdout').write_text(q.stdout)
 (root/f'larson-null-{rep}.stderr').write_text(q.stderr)
 (root/'larson-baseline-drain-check.json').write_text(json.dumps({'command':cmd,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'environment':{'MIMALLOC_PROF':'0','MIMALLOC_MEMORY_EVENTS':'0'},'purpose':'local baseline-only residency attribution, not performance acceptance','samples':rows},indent=2)+'\n')
 print(row,flush=True)
