#include "mimalloc.h"
#include "mimalloc/internal.h"
#include <stdint.h>
#include <stdio.h>
#define PROBE_WORKERS 8
#define PROBE_TABLE_SLOTS 5000
#define PROBE_LOG_DOUBLINGS 9
#define PROBE_HUGE_REGION_BYTES ((size_t)2*1024*1024)
int main(void) {
 void* blocks[PROBE_WORKERS];
 const size_t request=(size_t)PROBE_TABLE_SLOTS*((size_t)1<<PROBE_LOG_DOUBLINGS)*sizeof(size_t);
 printf("request_bytes=%zu,good_size=%zu\n",request,mi_good_size(request));
 for(size_t i=0;i<PROBE_WORKERS;i++){
  blocks[i]=mi_malloc(request);if(!blocks[i])return 1;
  const mi_page_t* page=_mi_ptr_page(blocks[i]);
  printf("block=%zu,block_size=%zu,slices=%u,slice_bytes=%zu,separate_metadata=%d,block_offset=%zu,offset_in_2MiB=%zu,usable=%zu\n",i,mi_page_block_size(page),page->memid.mem.arena.slice_count,mi_size_of_slices(page->memid.mem.arena.slice_count),(int)mi_page_meta_is_separated(page),(size_t)((uint8_t*)blocks[i]-mi_page_slice_start(page)),(size_t)((uintptr_t)blocks[i]%PROBE_HUGE_REGION_BYTES),mi_usable_size(blocks[i]));
  ((volatile char*)blocks[i])[0]=1;((volatile char*)blocks[i])[request-1]=1;
 }
 for(size_t i=0;i<PROBE_WORKERS;i++)mi_free(blocks[i]);
 return 0;
}
