import hashlib,json,os,platform,subprocess
from pathlib import Path
ROOT=Path('/w');OUT=Path('/out');MAX_RUNS=10
exes={'old15':ROOT/'old-byte-musl-bundle/unpacked/mimalloc-test-purge-holes','new6f':ROOT/'wordhash-musl-bundle/unpacked/mimalloc-test-purge-holes'}
report={'purpose':'Reproduction/attribution only; not CI gate acceptance','maximum_per_source':MAX_RUNS,'stop_each_source_at_first_failure':True,'cpu':next((x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')),'unknown'),'affinity':sorted(os.sched_getaffinity(0)),'kernel':platform.uname()._asdict(),'alpine':Path('/etc/alpine-release').read_text().strip(),'mimalloc_environment':{k:v for k,v in os.environ.items() if k.startswith('MIMALLOC_')},'sha256':{a:hashlib.sha256(p.read_bytes()).hexdigest() for a,p in exes.items()},'runs':[]}
active=set(exes)
for rep in range(MAX_RUNS):
 arms=list(exes) if rep%2==0 else list(reversed(exes))
 for arm in arms:
  if arm not in active:continue
  p=exes[arm]
  try:
   proc=subprocess.run([str(p)],cwd=p.parent,capture_output=True,timeout=600)
   code=proc.returncode;stdout=proc.stdout;stderr=proc.stderr
  except subprocess.TimeoutExpired as e:
   code='timeout600';stdout=e.stdout or b'';stderr=e.stderr or b''
  (OUT/f'{rep}-{arm}.stdout').write_bytes(stdout);(OUT/f'{rep}-{arm}.stderr').write_bytes(stderr)
  report['runs'].append({'rep':rep,'arm':arm,'returncode':code,'stdout_file':f'{rep}-{arm}.stdout','stderr_file':f'{rep}-{arm}.stderr'})
  (OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
  print(rep,arm,code,flush=True)
  if code!=0:active.remove(arm)
 if not active:break
