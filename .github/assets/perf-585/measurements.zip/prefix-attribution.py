from pathlib import Path
import json, statistics, subprocess, sys
sys.path.insert(0, '/home/niteris/dev/mimalloc-pprof/ci')
import attribution_probe as probe
root=Path('/tmp/mimalloc-585/prefix-attribution')
root.mkdir(exist_ok=True)
exe=probe.build(root, '')
records={}
for row,prefixes in [('persistent',[500,2000,10000,50000,100000,200000,400000]),('sparse',[500,2000,5000,10000,25000])]:
    for count in prefixes:
        runs=[]
        params=probe.ROWS[row].copy(); params[4]=str(count)
        for rep in range(3):
            child=subprocess.run([str(exe),*params,'500'],capture_output=True,text=True,check=True,env={'PERF_AB_HOLES_REPORT':'1','PATH':'/usr/bin:/bin'})
            (root/f'{row}-{count}-{rep}.stdout').write_text(child.stdout)
            (root/f'{row}-{count}-{rep}.stderr').write_text(child.stderr)
            parsed=probe.parse(child.stdout,child.stderr)
            assert len(parsed['workers'])==8
            runs.append({'buckets':probe.buckets(parsed),'workers':parsed['workers']})
        med={k:statistics.median(r['buckets'][k] for r in runs) for k in runs[0]['buckets']}
        records[f'{row}/{count}']={'median':med,'runs':runs}
        (root/'results.json').write_text(json.dumps(records,indent=2))
        show=['_rss','_peak','_requested','unformed tail, partly used pages','unformed, empty pages','free slices: queued for purge (resident)']
        print(row,count,{k:round(med[k]/probe.MIB,2) for k in show},flush=True)
