"""Prepare an owned-scratch evidence inventory; no repository write or publication."""
import hashlib,json,zipfile
from pathlib import Path
R=Path('/tmp/mimalloc-585');out=R/'profiler-idle-guard/evidence-preview';out.mkdir(exist_ok=True)
selected={}
def add(path,kind):
 assert path.resolve().is_relative_to(R.resolve())
 if path.is_file():selected.setdefault(str(path.relative_to(R)),(path,kind))
for p in R.rglob('perf-ab-samples.json'):add(p,'original-perf-ab-raw')
for p in (R/'combined-scaling').rglob('scaling-raw-run.json'):add(p,'original-scaling-raw')
for p in R.rglob('sha256.json'):add(p,'preserved-executable-digests')
for p in R.rglob('build-report.json'):add(p,'build-only-provenance-not-timings')
for p in (R/'profiler-idle-guard/linux-parallel-results').glob('*.json'):add(p,'current-linux-memory-raw')
for p in [R/'profiler-idle-guard/plain-identity/identity-verification.json',R/'profiler-idle-guard/linux-memory-verification.json',R/'profiler-idle-guard/acceptance-plan.json',R/'profiler-idle-guard/dispatches.json',R/'current-commit-audit.json']:add(p,'verification-or-provenance')
# Preserve local diagnostics separately; none is a CI timing verdict.
def is_build_input(path):
 return any(x in {'src','build','cargo-target','target','CMakeFiles','evidence-preview','ruff-cache','.git','.pytest_cache','.ruff_cache'} or x.startswith(('src-','build-')) or x.endswith('-src') for x in path.relative_to(R).parts)
for pattern in ['*.json','*.csv','*.bin','*.data','*.data.old','*.txt','*.log','*.stdout','*.stderr','*.report','*.samples','*.out','*.err']:
 for p in R.rglob(pattern):
  if not is_build_input(p):add(p,'original-local-diagnostic-not-CI-acceptance')
for p in R.glob('*.json'):add(p,'historical-or-current-local-analysis')
for directory in ['windows-memory-baseline','current3db-windows-gnu-memory','current3db-windows-msvc-memory','larson-growth','huge-headroom','prefix-attribution','capacity-fit-probe','reserve-claim-probe','profiler-cycle-attribution','profiler-hash-cycle-attribution','profiler-idle-guard']:
 for p in (R/directory).rglob('*.json'):
  if not is_build_input(p):add(p,'historical-or-current-provenance-and-diagnostics')
for p in (R/'profiler-idle-guard').glob('*.py'):add(p,'local-verification-source')
for p in (R/'profiler-idle-guard').glob('*.c'):add(p,'local-reproducer-source')
for pattern in ['*.py','*.c','*.patch']:
 for p in R.glob(pattern):add(p,'local-reproducer-or-analysis-source')
manifest={'stage':'PREVIEW-NOT-FINAL','head':'ad9fbd952ca934257f4acdc19889e74d8886a18f','note':'Exact raw bytes retained, including legacy, failed and incomplete datasets. Inclusion is not an acceptance verdict. Different sources/hosts/protocols must not be pooled. All measurement runs are terminal; current acceptance remains 11/13 supported PASS and two INCONCLUSIVE. Platform104SUCCESS/five intentional SKIPs. This evidence does not certify goal completion. Surviving benchmark executables are included once per actual digest, with original-path aliases. Missing original files are explicitly recorded; no reconstruction or source relabeling. No source change or repository publication.','pending_runs':[39689518823,39689522180,39689525291,39689528498],'files':[]}
# Retain surviving benchmark executables once per actual SHA256.
manifest['binary_aliases']=[]
manifest['missing_binary_references']=[]
for digest_path in R.rglob('sha256.json'):
 if is_build_input(digest_path):continue
 for name,digest in json.loads(digest_path.read_text()).items():
  p=digest_path.parent/name
  if not isinstance(digest,str) or len(digest)!=64 or p.name not in ['perf_ab','perf_ab_latency']:continue
  assert p.resolve().is_relative_to(R.resolve())
  original=str(p.relative_to(R))
  if not p.is_file():
   manifest['missing_binary_references'].append({'path':original,'sha256':digest});continue
  assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
  archive_name='executables/'+digest+'.elf'
  selected.setdefault(archive_name,(p,'preserved-benchmark-executable'))
  manifest['binary_aliases'].append({'original_path':original,'archive_path':archive_name,'sha256':digest})
manifest['known_unavailable']=[{'run':39491166866,'detail':'The old harness lost first-sanity raw samples; do not reconstruct numbers from rounded logs.'},{'run':39521491231,'detail':'90-minute job timeout before checkpoints existed; no raw artifact/verdict was produced.'},{'run':39489674226,'detail':'Original failed timing binaries were not retained by the old harness; cannot establish their code-layout cause.'}]
completed={}
for p in (R/'profiler-idle-guard').glob('*/verified-full-precision.json'):
 d=json.loads(p.read_text())
 if d.get('head',{}).get('sha')==manifest['head']:completed[d['workload']]=d['row_verdict']
dispatches=json.loads((R/'profiler-idle-guard/dispatches.json').read_text())
manifest['pending_runs']=[d['run_id'] for d in dispatches if d['name']!='plain-binary-identity' and d['name'] not in completed]
manifest['completed_numeric_results']=completed
for p in (R/'profiler-idle-guard').glob('*terminal.log'):add(p,'terminal-CI-log')
archive=out/'measurements-preview.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,(path,kind) in sorted(selected.items()):
  b=path.read_bytes();info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
  manifest['files'].append({'path':name,'kind':kind,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(manifest['files'])
 for record in manifest['files']:
  b=z.read(record['path']);assert len(b)==record['bytes'] and hashlib.sha256(b).hexdigest()==record['sha256']
manifest['archive']={'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Files',len(manifest['files']),'raw bytes',sum(x['bytes'] for x in manifest['files']),'ZIP bytes',manifest['archive']['bytes'],'all archived entries round-trip verified; preview only')
