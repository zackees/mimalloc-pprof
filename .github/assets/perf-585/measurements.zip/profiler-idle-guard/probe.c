#ifdef NDEBUG
#undef NDEBUG
#endif
#include "mimalloc.h"
#include "mimalloc/internal.h"
#include <assert.h>
#include <stdio.h>
#ifndef PROBE_ALLOC_SIZE
#define PROBE_ALLOC_SIZE (96 * 1024)
#endif
#ifndef PROBE_CALLS
#define PROBE_CALLS 64
#endif
static int active;
static size_t meta_calls,once_calls;
bool __real__mi_meta_is_meta_page(const mi_subproc_t*, const mi_page_t*);
bool __wrap__mi_meta_is_meta_page(const mi_subproc_t* s,const mi_page_t* p) { if(active)meta_calls++; return __real__mi_meta_is_meta_page(s,p); }
bool __real__mi_atomic_once_enter(mi_atomic_once_t*);
bool __wrap__mi_atomic_once_enter(mi_atomic_once_t* o) { if(active)once_calls++; return __real__mi_atomic_once_enter(o); }
int main(void) {
 mi_option_disable(mi_option_scavenger);
 void* p=mi_malloc(PROBE_ALLOC_SIZE);assert(p);mi_prof_stop();
 mi_page_t* page=_mi_ptr_page(p);mi_theap_t* theap=mi_page_theap(page);
 active=1;
 for(size_t i=0;i<PROBE_CALLS;i++)_mi_prof_on_alloc(theap,page,p,PROBE_ALLOC_SIZE);
 active=0;
 printf("stopped calls=%d metadata=%zu once=%zu\n",PROBE_CALLS,meta_calls,once_calls);
 mi_free(p);
 assert(mi_prof_start_seeded(1,1));p=mi_malloc(PROBE_ALLOC_SIZE);assert(p);
 mi_prof_stats_t_decl(st);assert(mi_prof_stats_get(&st));assert(st.live_samples>0);
 mi_free(p);mi_prof_stop();
 return meta_calls==0 && once_calls==0 ? 0:1;
}
