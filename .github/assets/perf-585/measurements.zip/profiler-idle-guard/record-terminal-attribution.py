import hashlib,json,os,subprocess
from pathlib import Path
R=Path('/tmp/mimalloc-585/profiler-idle-guard');out=R/'terminal-attribution';out.mkdir(exist_ok=True)
cpus=','.join(map(str,sorted(os.sched_getaffinity(0))[:4]));records=[]
manifest={'purpose':'Bounded local attribution; no CI acceptance, pooling or retry','cpus':cpus,'repetitions':3,'runs':records}
for folder,event,kind,exe in [('chart-standard','minor-faults','chart','perf_ab'),('profiler','cycles:u','pprof','perf_ab_latency')]:
 d=json.loads((R/folder/'perf-ab-samples.json').read_text());name=next(iter(d['workloads']));params=d['workloads'][name]['params'];args=[str(params[k]) for k in ['threads','generations','min_size','max_size','ops','pause_ms','table_slots','sizes','slots']]+[str(d['release_bound_ms'])]
 for rep in range(3):
  for arm in (['base','head'] if rep%2==0 else ['head','base']):
   binary=R/folder/'builds'/arm/kind/exe;digest=hashlib.sha256(binary.read_bytes()).hexdigest();assert digest==json.loads((R/folder/'builds/sha256.json').read_text())[arm+'/'+kind+'/'+exe]
   binary.chmod(binary.stat().st_mode|0o100)
   stem=f'{folder}-{rep}-{arm}';data=out/(stem+'.data')
   command=['perf','record','-q','-e',event,'-c','1' if event=='minor-faults' else '100000','-o',str(data),'--','taskset','-c',cpus,str(binary),*args]
   env=os.environ.copy()
   if kind=='pprof':env['MIMALLOC_PROF']='1'
   else:env.pop('MIMALLOC_PROF',None)
   result=subprocess.run(command,capture_output=True,text=True,env=env)
   (out/(stem+'.stdout')).write_text(result.stdout);(out/(stem+'.stderr')).write_text(result.stderr)
   record={'folder':folder,'rep':rep,'arm':arm,'sha256':digest,'command':command,'exit_code':result.returncode};records.append(record)
   (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
   if result.returncode:raise SystemExit(result.returncode)
   for toolargs,suffix in [(['report','--stdio','--percent-limit','0.1'],'.report'),(['script','-F','comm,ip,sym,dso'],'.samples')]:
    view=subprocess.run(['perf',*toolargs,'-i',str(data)],capture_output=True,text=True,check=True)
    (out/(stem+suffix)).write_text(view.stdout);(out/(stem+suffix+'.stderr')).write_text(view.stderr)
   print(stem,'completed',flush=True)
