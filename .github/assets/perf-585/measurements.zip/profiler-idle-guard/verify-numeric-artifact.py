"""Read one completed original artifact; never dispatch, pool, retry, or alter samples."""
import dataclasses,hashlib,json,math,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'ci'))
import perf_ab,perf_ab_ledger
R=Path('/tmp/mimalloc-585/profiler-idle-guard');directory=Path(sys.argv[1]);name=sys.argv[2]
plan=json.loads((R/'acceptance-plan.json').read_text());row=next(x for x in plan['rows'] if x['exact']==name)
d=json.loads((directory/'perf-ab-samples.json').read_text())
assert d['complete'] is True,'incomplete is diagnostic only'
assert d['base']['sha']==plan['base'] and d['head']['sha']==plan['head']
assert d['fields']==[*perf_ab.METRICS,'ideal RSS MiB']
assert d['reps']==row['start'] and d['max_reps']==row['max']
assert d['variants']==[{'arm':'head','env':{},'cppdefs':[]}]
assert set(d['workloads'])==set(d['samples'])=={name}
kind,params=perf_ab.WORKLOADS[name];assert d['workloads'][name]=={'kind':kind,'params':params._asdict()}
reference=Path('/tmp/mimalloc-585')/('wordhash-fixed-baseline-profiler' if kind=='pprof' else 'current-chart-larson-followup')
ref=json.loads((reference/'perf-ab-samples.json').read_text())
assert d['latency_protocol']==ref['latency_protocol']
assert d['arm_order_protocol']==ref['arm_order_protocol']
assert d['release_bound_ms']==ref['release_bound_ms']==1300
assert d['logical_cpus']>0 and isinstance(d['cpu'],str) and d['cpu']
arms=d['samples'][name];assert set(arms)=={'base','head','null'}
counts={k:len(v) for k,v in arms.items()};assert len(set(counts.values()))==1
assert row['start']<=counts['head']<=row['max']
for samples in arms.values():
 assert all(len(s)==len(d['fields']) and all(math.isfinite(v) for v in s) for s in samples)
assert not perf_ab.sanity_failures({(name,a):arms[a][0] for a in ['base','head']},[name])
hashes=json.loads((directory/'builds/sha256.json').read_text());old_hashes=json.loads((reference/'builds/sha256.json').read_text());verified={}
for arm in ['base','head']:
 for exe in ['perf_ab','perf_ab_latency']:
  key=arm+'/'+kind+'/'+exe;p=directory/'builds'/key;actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==hashes[key]
  verified[key]={'sha256':actual,'bytes':p.stat().st_size,'same_as_previous_binary':actual==old_hashes[key]}
saved,cells=perf_ab.ledger_row(arms['base'],arms['head'],arms['null'])
release_index=d['fields'].index('release ms');p95=perf_ab.percentile([s[release_index] for s in arms['head']],perf_ab.RELEASE_PERCENTILE)
result={'workload':name,'base':d['base'],'head':d['head'],'cpu':d['cpu'],'logical_cpus':d['logical_cpus'],'counts':counts,'saved':saved,'cells':[dataclasses.asdict(c) for c in cells],'row_verdict':perf_ab_ledger.row_verdict(cells),'head_p95_release_ms':p95,'release_bound_ms':d['release_bound_ms'],'release_bound_held':p95<=d['release_bound_ms'],'actual_executable_hashes':verified,'protocols_verified':{'latency':d['latency_protocol'],'arm_order':d['arm_order_protocol']},'note':'Standalone original completed run only. No pooling, unchanged-source retry, rounded waiver, new memory-credit claim or cross-host aggregation.'}
(directory/'verified-full-precision.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
