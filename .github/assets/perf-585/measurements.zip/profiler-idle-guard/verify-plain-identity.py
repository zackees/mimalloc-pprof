import dataclasses,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'ci'))
import perf_ab,perf_ab_ledger
R=Path('/tmp/mimalloc-585');N=R/'profiler-idle-guard/plain-identity'
report=json.loads((N/'build-report.json').read_text());assert report['complete'] is False
assert report['arms']['base']['sha']=='ee3623f6b7a485754a0a0aa3462d8cba43390e8b'
assert report['arms']['head']['sha']=='ad9fbd952ca934257f4acdc19889e74d8886a18f'
assert report['flags']==perf_ab.FLAGS
fresh={}
for arm,meta in report['arms'].items():
 assert meta['kind']=='plain'
 for name,info in meta['files'].items():
  b=(N/arm/name).read_bytes();assert len(b)==info['bytes'];assert hashlib.sha256(b).hexdigest()==info['sha256'];fresh[arm+'/'+name]=info['sha256']
selections=[('balanced-byte-threshold-main','large-class/8'),('balanced-byte-threshold-ephemeral','large-class-ephemeral/8'),('balanced-byte-threshold-sparse','sparse-large-buffers 64-slot budget/8 (#422)'),('balanced-byte-threshold-bursty','random-large-bursty/8'),('balanced-byte-threshold-larson1','larson/1'),('balanced-byte-threshold-random','random-large/1'),('current-small8','small/8 (control)'),('current-larson8','larson/8'),('current-random8','random-large/8')]
rows=[]
for dirname,name in selections:
 old=R/dirname;data=json.loads((old/'perf-ab-samples.json').read_text());hashes=json.loads((old/'builds/sha256.json').read_text())
 assert data.get('complete') is not False and data['base']['sha']==report['arms']['base']['sha']
 if 'complete' not in data:assert data['head']['sha']=='15bfcba0c3e59aea6b22dd04f91db9d95cd63a0a' # inspected legacy writer: success omits flag, sanity failure writes false
 assert data['variants']==[{'arm':'head','env':{},'cppdefs':[]}]
 assert data['latency_protocol']['version']=='sampled-stream-operation-v1'
 assert data['arm_order_protocol']=={'version':'rotating-reversed-blocks-v1','arms':['base','head','null']}
 assert data['release_bound_ms']==1300
 expected_kind,expected_params={**perf_ab.WORKLOADS,**perf_ab.DIAGNOSTIC_WORKLOADS}[name]
 assert expected_kind=='plain'
 assert data['workloads'][name]=={'kind':expected_kind,'params':expected_params._asdict()}
 verified=[]
 for arm in ['base','head']:
  for exe in ['perf_ab','perf_ab_latency']:
   key=arm+'/plain/'+exe;b=(old/'builds'/key).read_bytes()
   assert hashlib.sha256(b).hexdigest()==hashes[key]==fresh[arm+'/'+exe]
   assert b==(N/arm/exe).read_bytes();verified.append(key)
 arms=data['samples'][name];assert set(arms)=={'base','head','null'}
 assert len({len(v) for v in arms.values()})==1 and len(arms['base'])>=data['reps']
 saved,cells=perf_ab.ledger_row(arms['base'],arms['head'],arms['null'])
 assert perf_ab_ledger.row_verdict(cells)=='PASS'
 rows.append({'workload':name,'original_directory':dirname,'original_base':data['base'],'original_head':data['head'],'legacy_complete_flag_absent':'complete' not in data,'cpu':data['cpu'],'logical_cpus':data['logical_cpus'],'counts':{k:len(v) for k,v in arms.items()},'verified_whole_executables':verified,'saved':saved,'cells':[dataclasses.asdict(c) for c in cells]})
result={'purpose':'Build-only exact executable identity, not new timings or pooling. Original refs/CPU/sample counts/outcomes retained. New chart and profiler binaries excluded.','source':report,'fresh_actual_files_verified':len(fresh),'previous_timed_executable_checks':sum(len(r['verified_whole_executables']) for r in rows),'supported_plain_rows':len(rows),'rows':rows}
(N/'identity-verification.json').write_text(json.dumps(result,indent=2)+'\n')
for row in rows:print(row['workload'],row['counts'],row['cpu'],'PASS',row['saved'])
