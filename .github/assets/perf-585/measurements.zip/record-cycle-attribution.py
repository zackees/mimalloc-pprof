import json,os,subprocess
from pathlib import Path
ROOT=Path('/tmp/mimalloc-585')
OUT=ROOT/'cycle-attribution'
OUT.mkdir(exist_ok=True)
exes={
 'base': ROOT/'balanced-combined-targets/builds/base/plain/perf_ab_latency',
 'exactfit': ROOT/'balanced-exactfit-control/builds/head/plain/perf_ab_latency',
 'combined': ROOT/'balanced-combined-targets/builds/head/plain/perf_ab_latency',
}
cpus=','.join(map(str,sorted(os.sched_getaffinity(0))[:4]))
results=[]
for rep in range(3):
 arms=list(exes);arms=arms[rep:]+arms[:rep]
 for arm in arms:
  data=OUT/f'{rep}-{arm}.data'
  cmd=['perf','record','-q','-e','cycles:u','-c','100000','-o',str(data),'--','taskset','-c',cpus,str(exes[arm]),'8','8','98304','524288','400000','0','0','uniform','8','1300']
  env=os.environ.copy();env.update(MIMALLOC_PROF='0',MIMALLOC_MEMORY_EVENTS='0')
  proc=subprocess.run(cmd,capture_output=True,text=True,env=env,check=True)
  (OUT/f'{rep}-{arm}.stderr').write_text(proc.stderr)
  (OUT/f'{rep}-{arm}.stdout').write_text(proc.stdout)
  report=subprocess.run(['perf','report','--stdio','--percent-limit','0.1','-i',str(data)],capture_output=True,text=True,check=True)
  (OUT/f'{rep}-{arm}.report').write_text(report.stdout)
  annotation=subprocess.run(['perf','annotate','--stdio','-s','mi_page_fresh_alloc','-i',str(data)],capture_output=True,text=True,check=True)
  (OUT/f'{rep}-{arm}.annotate').write_text(annotation.stdout)
  results.append({'rep':rep,'arm':arm,'command':cmd,'purpose':'local hardware cycle attribution only; profiler-perturbed latency is not acceptance'})
  (OUT/'manifest.json').write_text(json.dumps({'cpus':cpus,'runs':results},indent=1)+'\n')
  print(rep,arm,'record/report/annotation saved',flush=True)
