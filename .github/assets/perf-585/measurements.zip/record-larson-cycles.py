import hashlib,json,os,subprocess
from pathlib import Path
root=Path('/tmp/mimalloc-585');out=root/'larson-cycle-attribution';out.mkdir(exist_ok=True)
exes={arm:root/f'current-chart-larson-followup/builds/{arm}/chart/perf_ab' for arm in ('base','head')}
cpus=','.join(map(str,sorted(os.sched_getaffinity(0))[:4]));results=[]
manifest={'cpus':cpus,'environment':{'MIMALLOC_PROF':'0','MIMALLOC_MEMORY_EVENTS':'0'},'purpose':'Three fixed alternating pairs; exact CI throughput executables; local user cycles only, no timing acceptance or CI cause claim','hashes':{a:hashlib.sha256(p.read_bytes()).hexdigest() for a,p in exes.items()},'runs':results}
for rep in range(3):
 arms=list(exes) if rep%2==0 else list(reversed(exes))
 for arm in arms:
  data=out/f'{rep}-{arm}.data'
  cmd=['perf','record','-q','-e','cycles:u','-c','100000','-o',str(data),'--','taskset','-c',cpus,str(exes[arm]),'8','1','8','1000','2500000','0','5000','uniform','8','1300']
  env=os.environ.copy();env.update(manifest['environment'])
  proc=subprocess.run(cmd,capture_output=True,text=True,env=env,check=True)
  (out/f'{rep}-{arm}.stderr').write_text(proc.stderr);(out/f'{rep}-{arm}.stdout').write_text(proc.stdout)
  report=subprocess.run(['perf','report','--stdio','--percent-limit','0.1','-i',str(data)],capture_output=True,text=True,check=True)
  (out/f'{rep}-{arm}.report').write_text(report.stdout)
  results.append({'rep':rep,'arm':arm,'command':cmd});(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
  print(rep,arm,'saved',flush=True)
