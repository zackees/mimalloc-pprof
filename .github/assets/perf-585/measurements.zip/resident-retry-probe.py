import json, os, statistics, subprocess, sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd() / "ci"))
import attribution_probe as probe
root = Path("/tmp/mimalloc-585/resident-retry")
root.mkdir(exist_ok=True)
results = {}
for limit in (8, 32, 128):
    exe = probe.build(root, f"MI_RESIDENT_FIRST_MAX_TRIES={limit}")
    runs = []
    for rep in range(5):
        env = dict(os.environ, PERF_AB_HOLES_REPORT="1")
        proc = subprocess.run([str(exe), *probe.ROWS["sparse"], "1300"], env=env, text=True, capture_output=True, check=True)
        (root / f"tries-{limit}-{rep}.stdout").write_text(proc.stdout)
        (root / f"tries-{limit}-{rep}.stderr").write_text(proc.stderr)
        runs.append(probe.buckets(probe.parse(proc.stdout, proc.stderr)))
    results[str(limit)] = runs
    print(limit, {key: round(statistics.median(r[key] for r in runs) / probe.MIB, 2) for key in ("_rss", "free slices: queued for purge (resident)", "_thp")}, flush=True)
(root / "results.json").write_text(json.dumps(results, indent=2))
