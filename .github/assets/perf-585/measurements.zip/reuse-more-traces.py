import os, subprocess
from pathlib import Path
exe = "/tmp/mimalloc-585/reuse-trace-build/perf_ab"
for name, lo, hi, ops in (("sparse-2",65536,4194304,25000),("sparse-3",65536,4194304,25000),("persistent",98304,524288,400000)):
    dest = Path("/tmp/mimalloc-585")
    env = dict(os.environ, MI_SCRATCH_TRACE=str(dest/f"reuse-{name}.bin"))
    result = subprocess.run([exe,"8","1",str(lo),str(hi),str(ops),"0","0","log" if name.startswith("sparse") else "uniform","8","1300"], env=env, text=True, capture_output=True, check=True)
    (dest/f"reuse-{name}.stdout").write_text(result.stdout)
    (dest/f"reuse-{name}.stderr").write_text(result.stderr)
    print(name,"trace bytes",(dest/f"reuse-{name}.bin").stat().st_size,flush=True)
