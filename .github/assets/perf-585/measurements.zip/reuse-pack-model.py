import bisect, json, struct, sys
from pathlib import Path
events = list(struct.iter_unpack("<QQII", Path(sys.argv[1]).read_bytes()))
results = {}
for strategy in ("first-fit", "best-fit"):
    holes = []
    live = {}
    top = 0
    peak_live = 0
    current_live = 0
    for addr, ns, count, freed in events:
        if freed:
            start, held = live.pop(addr)
            assert held == count
            current_live -= count
            end = start + count
            pos = bisect.bisect_left(holes, (start,))
            if pos > 0 and sum(holes[pos-1]) == start:
                start = holes[pos-1][0]
                holes.pop(pos-1)
                pos -= 1
            if pos < len(holes) and holes[pos][0] == end:
                end += holes[pos][1]
                holes.pop(pos)
            holes.insert(pos, (start, end-start))
        else:
            choices = []
            for i, (start, size) in enumerate(holes):
                # A bitmap claim cannot cross a 512-slice chunk.
                aligned = start if start // 512 == (start+count-1) // 512 else ((start+511)//512)*512
                if aligned+count <= start+size:
                    choices.append((size if strategy == "best-fit" else start, i, aligned))
                    if strategy == "first-fit": break
            if choices:
                _, pos, start = min(choices)
                old, size = holes.pop(pos)
                if old < start: holes.insert(pos, (old, start-old)); pos += 1
                if start+count < old+size: holes.insert(pos, (start+count, old+size-start-count))
            else:
                start = top if top//512 == (top+count-1)//512 else ((top+511)//512)*512
                if start > top: holes.append((top, start-top))
                top = start+count
            assert addr not in live
            live[addr] = (start, count)
            current_live += count
            peak_live = max(peak_live, current_live)
    results[strategy] = {"footprint_MiB": top/16, "peak_outstanding_MiB": peak_live/16}
print(json.dumps(results, indent=2))
Path(sys.argv[1]+".model.json").write_text(json.dumps(results, indent=2))
