"""Offline arena-free slice-time; not RSS, retired-page lifetimes or a discard-policy trial."""
import hashlib,json,struct
from pathlib import Path
ROOT=Path('/tmp/mimalloc-585')
SLICE_BYTES=64*1024
MIB=1024*1024
AGE_THRESHOLDS_NS={str(ms):ms*1_000_000 for ms in (1,10,25,50,100)}
NAMES=('sparse','sparse-2','sparse-3','persistent')

def analyze(events,cutoff):
    selected=events[:cutoff+1]
    start=min(x[1] for x in selected);end=max(x[1] for x in selected)
    live=set();free={};completed=[];changes=[];negative=[]
    for addr,ns,count,freed in selected:
        assert addr%SLICE_BYTES==0
        for index in range(count):
            key=addr//SLICE_BYTES+index
            if freed:
                assert key in live,('free without claim',key)
                live.remove(key);assert key not in free
                free[key]=ns;changes.append((ns,1))
            else:
                assert key not in live,('duplicate claim',key)
                live.add(key)
                if key in free:
                    duration=ns-free.pop(key)
                    if duration<0:negative.append(duration)
                    completed.append(duration);changes.append((ns,-1))
    if negative:
        return {'valid':False,'negative_reuse_intervals':len(negative),'minimum_ns':min(negative)}
    censored=[end-ns for ns in free.values()]
    completed_area=sum(completed);censored_area=sum(censored);area=completed_area+censored_area
    # Independent conservation: integrate the inventory of known free slices over time.
    inventory=0;integral=0;previous=start
    for ns,delta in sorted(changes):
        integral+=inventory*(ns-previous);inventory+=delta;previous=ns
        assert inventory>=0
    integral+=inventory*(end-previous)
    assert integral==area,(integral,area)
    assert inventory==len(free)
    durations=completed+censored
    return {'valid':True,'events':len(selected),'window_ms':(end-start)/1e6,
        'global_timestamp_inversions':sum(a[1]>b[1] for a,b in zip(selected,selected[1:])),
        'completed_reuse_slices':len(completed),'right_censored_free_slices':len(censored),
        'completed_within_1ms_fraction':sum(d<1_000_000 for d in completed)/len(completed),
        'known_free_MiB_at_cutoff':len(free)*SLICE_BYTES/MIB,
        'time_average_known_free_MiB':area/(end-start)*SLICE_BYTES/MIB,
        'right_censored_share_of_observed_free_slice_time':censored_area/area,
        'share_of_free_slice_time_with_age_above_ms':{label:sum(max(0,d-age) for d in durations)/area for label,age in AGE_THRESHOLDS_NS.items()},
        'known_free_MiB_with_age_at_least_ms_at_cutoff':{label:sum(d>=age for d in censored)*SLICE_BYTES/MIB for label,age in AGE_THRESHOLDS_NS.items()},
        'free_slice_time_conservation_exact':True}

out={'purpose':'Descriptive existing local traces; virtual arena-free slice-time, not residency or acceptance',
     'limits':['Callbacks instrumented the old8b policy; wall time affected by instrumentation.',
               'Arena claim/free only; no purge/residency events and no page-retirement events.',
               'Full trace includes drain/shutdown. Last recorded arena allocation is only a second diagnostic cutoff, NOT an authoritative work/peak marker.',
               'Intervals still free at cutoff are right-censored; observed time is a lower bound on lifetime.'],
     'traces':{}}
old=json.loads((ROOT/'reuse-trace-reports.json').read_text())
for name in NAMES:
    path=ROOT/f'reuse-{name}.bin';raw=path.read_bytes();events=list(struct.iter_unpack('<QQII',raw))
    last_claim=max(i for i,e in enumerate(events) if e[3]==0)
    full=analyze(events,len(events)-1);proxy=analyze(events,last_claim)
    assert full['valid'] and proxy['valid'],(name,full,proxy)
    assert full['completed_reuse_slices']==old[name]['reused_slices']
    assert full['completed_within_1ms_fraction']==old[name]['fraction_reused_under_1ms']
    out['traces'][name]={'sha256':hashlib.sha256(raw).hexdigest(),'full_trace':full,'last_recorded_arena_claim_cutoff':proxy}
    print(name,'lastclaim: avgfreeMiB',round(proxy['time_average_known_free_MiB'],2),'censoredshare',round(proxy['right_censored_share_of_observed_free_slice_time'],3),'areaage>1ms',round(proxy['share_of_free_slice_time_with_age_above_ms']['1'],3),'areaage>10ms',round(proxy['share_of_free_slice_time_with_age_above_ms']['10'],3),flush=True)
(ROOT/'reuse-time-weighted.json').write_text(json.dumps(out,indent=2)+'\n')
