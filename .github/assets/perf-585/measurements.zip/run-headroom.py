import json,os,subprocess
from pathlib import Path
R=Path('/tmp/mimalloc-585/huge-headroom');cpus=sorted(os.sched_getaffinity(0))[:4];records=[]
for rep in range(3):
 for arm in (('control','prototype') if rep%2==0 else ('prototype','control')):
  cmd=['taskset','-c',','.join(map(str,cpus)),str(R/arm),'8','1','8','1000','2500000','0','5000','uniform','8','1300']
  p=subprocess.run(cmd,env=dict(os.environ,MIMALLOC_PROF='0',MIMALLOC_MEMORY_EVENTS='0'),capture_output=True,text=True)
  row={'pair':rep,'arm':arm,'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr};records.append(row)
  if p.returncode==0:
   values=p.stdout.strip().split();assert len(values)==9,values
   row.update(peak_rss_bytes=int(values[4]),drain_rss_bytes=int(values[5]),bound_rss_bytes=int(values[6]))
  (R/'results.json').write_text(json.dumps({'purpose':'local RSS screen only, not timing/CI acceptance','cpus':cpus,'records':records},indent=2)+'\n')
  print(rep,arm,{k:row.get(k) for k in ['returncode','peak_rss_bytes','drain_rss_bytes','bound_rss_bytes']},flush=True)
  if p.returncode:raise RuntimeError('numeric process failed; preserved')
