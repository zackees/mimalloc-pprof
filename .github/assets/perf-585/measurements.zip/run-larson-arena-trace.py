import hashlib,json,os,struct,subprocess
from pathlib import Path
R=Path('/tmp/mimalloc-585/larson-growth/arena-traced');cpus=sorted(os.sched_getaffinity(0))[:4];out=[];keys=['ns','kind','table','pointer','requested','usable','span','rss','peak','live_log_requested']
for arm in ('base','head'):
 trace=R/f'growth-{arm}.bin';arena=R/f'arena-{arm}.bin';env=dict(os.environ,MIMALLOC_PROF='0',MIMALLOC_MEMORY_EVENTS='0',PERF_AB_GROW_TRACE=str(trace),MI_SCRATCH_TRACE=str(arena));cmd=['taskset','-c',','.join(map(str,cpus)),str(R/f'growth-{arm}'),'8','1','8','1000','2500000','0','5000','uniform','8','1300']
 run=subprocess.run(cmd,env=env,capture_output=True,text=True,check=True);ev=[dict(zip(keys,x)) for x in struct.iter_unpack('<10Q',trace.read_bytes())];assert len(ev)==170
 assert 'OVERFLOW' not in run.stderr
 ae=list(struct.iter_unpack('<QQII',arena.read_bytes()));assert len(ae)<1<<20
 row={'arm':arm,'command':cmd,'stdout':run.stdout,'stderr':run.stderr,'growth_events':ev,'arena_event_count':len(ae),'growth_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'arena_sha256':hashlib.sha256(arena.read_bytes()).hexdigest()};out.append(row)
 (R/'results.json').write_text(json.dumps({'purpose':'untimed address-level reuse attribution, not timing or acceptance','plan':'one fixed base/head pair, all observations retained','cpus':cpus,'records':out},indent=2)+'\n');print(arm,'growth_events',len(ev),'arena_events',len(ae),'output',run.stdout.strip(),flush=True)
