import hashlib,json,os,struct,subprocess
from pathlib import Path
R=Path('/tmp/mimalloc-585/larson-growth');cpus=sorted(os.sched_getaffinity(0))[:4];out=[]
keys=['ns','kind','table','pointer','requested','usable','span','rss','peak','live_log_requested']
for rep in range(3):
 for arm in (('base','head') if rep%2==0 else ('head','base')):
  trace=R/f'growth-{rep}-{arm}.bin';env=dict(os.environ,MIMALLOC_PROF='0',MIMALLOC_MEMORY_EVENTS='0',PERF_AB_GROW_TRACE=str(trace));cmd=['taskset','-c',','.join(map(str,cpus)),str(R/f'growth-{arm}'),'8','1','8','1000','2500000','0','5000','uniform','8','1300']
  p=subprocess.run(cmd,env=env,capture_output=True,text=True,check=True);events=[dict(zip(keys,x)) for x in struct.iter_unpack('<10Q',trace.read_bytes())]
  counts={kind:sum(e['kind']==kind for e in events) for kind in range(7)};assert counts=={0:8,1:72,2:72,3:8,4:8,5:1,6:1},counts
  assert all(e['usable']>=e['requested'] for e in events if e['pointer'])
  assert next(e for e in events if e['kind']==6)['live_log_requested']==0
  row={'rep':rep,'arm':arm,'command':cmd,'stdout':p.stdout,'stderr':p.stderr,'trace_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'event_counts':counts,'events':events};out.append(row)
  (R/'results.json').write_text(json.dumps({'purpose':'untimed instrumented chart-feature replay,not exact CI executable or acceptance','cpus':cpus,'plan':'three alternating pairs,no observations discarded','records':out},indent=1)+'\n')
  peak=max(events,key=lambda e:e['rss']);print(rep,arm,'events',len(events),'max sampled RSS MiB',peak['rss']/2**20,'current logs MiB',peak['live_log_requested']/2**20,'extra MiB',(peak['rss']-peak['live_log_requested'])/2**20,'output',p.stdout.strip(),flush=True)
