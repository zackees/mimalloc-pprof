import json,os,statistics,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/"ci"))
import attribution_probe as probe
probe.ROOT=Path("/home/niteris/.clud/worktrees/mimalloc-pprof-wt-585-singleton")
root=Path("/tmp/mimalloc-585/singleton-memory")
root.mkdir(exist_ok=True)
results={}
for enabled in (0,1):
    exe=probe.build(root,f"MI_SINGLETON_COMPACT_ARENA={enabled}")
    child=exe.parent/"structural-probe"
    subprocess.run(["cc","-O2","-DNDEBUG","-DMI_DEBUG=0","-DMI_DIAGNOSTICS=1","-DMI_STAT=1",f"-I{probe.ROOT/'include'}","/tmp/mimalloc-585/singleton-probe.c",str(exe.parent/"libmimalloc.a"),"-o",str(child),"-lpthread"],check=True)
    structural=subprocess.run([str(child)],capture_output=True,text=True)
    (root/f"structural-{enabled}.log").write_text(structural.stdout+structural.stderr)
    print("structural",enabled,"exit",structural.returncode,flush=True)
    if structural.returncode != (1 if enabled==0 else 0): raise SystemExit("unexpected structural probe result")
    for row in ("sparse","persistent"):
        runs=[]
        for rep in range(5):
            proc=subprocess.run([str(exe),*probe.ROWS[row],"1300"],env=dict(os.environ,PERF_AB_HOLES_REPORT="1"),capture_output=True,text=True,check=True)
            (root/f"{row}-{enabled}-{rep}.stdout").write_text(proc.stdout)
            (root/f"{row}-{enabled}-{rep}.stderr").write_text(proc.stderr)
            runs.append(probe.buckets(probe.parse(proc.stdout,proc.stderr)))
        results[f"{row}/{enabled}"]=runs
        print(row,enabled,{key:round(statistics.median(r[key] for r in runs)/probe.MIB,2) for key in ("_rss","free slices: queued for purge (resident)","_thp")},flush=True)
(root/"results.json").write_text(json.dumps(results,indent=2))
