#include "mimalloc.h"
#include "mimalloc/internal.h"
#include <stdio.h>
#include <string.h>
int main(void) {
  const size_t sizes[] = {576*1024,768*1024,1024*1024,2*1024*1024,4*1024*1024};
  int failed = 0;
  for (size_t i=0; i<sizeof(sizes)/sizeof(sizes[0]); ++i) {
    const size_t n=sizes[i];
    unsigned char* p=(unsigned char*)mi_malloc(n);
    if (!p) return 2;
    mi_page_t* page=_mi_ptr_page(p);
    const size_t wanted=mi_slice_count_of_size(mi_page_block_size(page));
    printf("size=%zu block=%zu arena=%d separated=%d slices=%u wanted=%zu\n",n,mi_page_block_size(page),page->memid.memkind==MI_MEM_ARENA,mi_page_meta_is_separated(page),page->memid.mem.arena.slice_count,wanted);
    if (page->memid.memkind!=MI_MEM_ARENA || !mi_page_meta_is_separated(page) || page->memid.mem.arena.slice_count!=wanted) failed++;
    memset(p,0xA7,n);
    if (_mi_ptr_page(p+n-1)!=page || p[n-1]!=0xA7) failed++;
    mi_free(p);
  }
  mi_option_enable(mi_option_disallow_arena_alloc);
  unsigned char* p=(unsigned char*)mi_malloc(1024*1024);
  if (!p) return 2;
  mi_page_t* page=_mi_ptr_page(p);
  printf("OS fallback memkind=%u separated=%d\n",(unsigned)page->memid.memkind,mi_page_meta_is_separated(page));
  if (page->memid.memkind==MI_MEM_ARENA || mi_page_meta_is_separated(page)) failed++;
  memset(p,0x5B,1024*1024);
  if (_mi_ptr_page(p+1024*1024-1)!=page) failed++;
  mi_free(p);
  return failed ? 1 : 0;
}
