base `227eef06ff03` head `287cac2f664a` on AMD EPYC 7763 64-Core Processor, 60 reps (up to 120); 4 logical CPUs, 8-worker cells have 2.00 workers per logical CPU (above 1 means oversubscription); arm order: rotating-reversed-blocks-v1

Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| large-class/8 | 0% | **INCONCLUSIVE** | +0.1% [-0.6, +0.6] / 0.7% **PASS** | -0.0% [-0.4, +0.3] / 0.3% **INCONCLUSIVE** | -0.6% [-2.0, +1.4] / 2.2% **PASS** | +0.1% [-1.0, +0.6] / 1.1% **PASS** | -0.0% [-0.2, +0.0] / 0.1% **PASS** | -0.4% [-1.8, +0.1] / 1.8% **PASS** |
