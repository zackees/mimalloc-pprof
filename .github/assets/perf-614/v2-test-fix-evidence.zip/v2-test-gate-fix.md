## V2 platform failure and test correction

Original ASan run [39831434073](https://github.com/zackees/mimalloc-pprof/actions/runs/39831434073), owner-gate Debug lane, failed `test-event-counters`: `_mi_page_free_collect` asserted `_mi_gate_held_theap`. The new test called this internal function without acquiring the owner gate. This is a test defect and a real failed platform gate; it is not marked passing or retried unchanged.

The failure reproduces locally. The correction holds the owner gate across internal page access/sweeping, including both clean and dirty tests, and releases it before deleting the heap. The focused test passes with Debug/full + owner gate + actual ASan enabled (`__asan_init` verified), and with the gate disabled. An initial local setup lacked the ASan header and compiled sanitizer support out; its RED/GREEN results establish gate coverage only. The later sanitized configuration explicitly enables it.

Only the test changes. Allocator sources, Rust amalgamation, build flags and performance harness remain the measured V2 implementation, so the three original live measurement cohorts are retained without duplicates. Original platform failure logs are preserved. Full platform validation of the corrected tests is still required before merge, and performance acceptance remains pending. PR #616 stays draft.
