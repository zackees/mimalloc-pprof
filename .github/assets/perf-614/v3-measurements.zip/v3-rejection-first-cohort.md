### V3 rejected: confirmed throughput regression in original plain ephemeral cohort

Run https://github.com/zackees/mimalloc-pprof/actions/runs/39840357033 completed at 75 samples per arm under the unchanged adaptive protocol. Exact baseline `227eef06ff03f92966f38508441d6c2f60a75135`; candidate `5b2d8f960297fda825b05b7471893fc4cf6c2f33`. AMD EPYC 7763, four logical CPUs. Original raw samples, exact binaries and SHA manifests downloaded and independently verified.

| Metric | Change % [95% CI] | Noise allowance % | Original verdict |
| --- | --- | --- | --- |
| ops/s | -0.8333 [-1.0046, -0.5076] | 0.3310 | FAIL |
| cpu s | +0.3109 [+0.0964, +0.4994] | 0.1852 | INCONCLUSIVE |
| minor faults | +0.0000 [-0.3906, +0.7968] | 1.5444 | PASS |
| p99 operation ns | +0.6169 [-0.0564, +1.6256] | 1.0839 | INCONCLUSIVE |
| peak RSS MiB | +0.1045 [+0.0052, +2.6618] | 2.6071 | INCONCLUSIVE |
| RSS 0.5 s after drain MiB | +10.9141 [+0.0000, +14.1152] | 13.1240 | INCONCLUSIVE |

Release p95: 1050 ms against 1300 ms bound (held). Zero memory credit. **1 PASS, 4 INCONCLUSIVE, 1 FAIL.** Workflow success means the measurement completed; it does not make the performance verdict pass.

**Disposition: reject V3.** The confirmed throughput regression violates rule12. No gain in another cell can pay for it. The other two original cohorts remain active and will be retained, but cannot reverse this rejection. No stage two, unchanged rerun, threshold adjustment or waiver. Production changes will be removed after retaining the original evidence; the PR must not merge this candidate.
