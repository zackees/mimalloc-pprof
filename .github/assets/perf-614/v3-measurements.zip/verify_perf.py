"""Verify one original perf-ab cohort; report evidence, never merge acceptance."""

import argparse
import dataclasses
import hashlib
import json
import math
import sys
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("directory", type=Path)
parser.add_argument("--repo", type=Path, required=True)
parser.add_argument("--baseline", required=True)
parser.add_argument("--candidate", required=True)
parser.add_argument("--workload", required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.repo / "ci"))
import perf_ab
import perf_ab_ledger
import perf_ab_stats


def require(condition, message):
    if not condition:
        raise SystemExit(message)


raw = (args.directory / "samples/perf-ab-samples.json").read_bytes()
data = json.loads(raw)
require(data["base"]["sha"] == args.baseline, "wrong baseline")
require(data["head"]["sha"] == args.candidate, "wrong candidate")
require(data.get("requested_reps", data["reps"]) == 60, "wrong initial cohort size")
require(data["max_reps"] == 120, "wrong adaptive cap")
require(data["variants"] == [{"arm": "head", "env": {}, "cppdefs": []}], "altered variants")
require(data["fields"] == [*perf_ab.METRICS, "ideal RSS MiB"], "altered metric fields")
require(data["latency_protocol"]["version"] == "sampled-stream-operation-v1", "wrong latency protocol")
require(data["arm_order_protocol"] == {"version": perf_ab.ARM_ORDER_VERSION, "arms": ["base", "head", "null"]}, "wrong arm order")
kind, params = {**perf_ab.WORKLOADS, **perf_ab.DIAGNOSTIC_WORKLOADS}[args.workload]
require(data["workloads"] == {args.workload: {"kind": kind, "params": params._asdict()}}, "altered workload or trace parameters")
require(set(data["samples"]) == {args.workload}, "unexpected samples")
hashes = json.loads((args.directory / "builds/sha256.json").read_text())
expected = {f"{arm}/{kind}/{exe}" for arm in ["base", "head"] for exe in ["perf_ab", "perf_ab_latency"]}
require(set(hashes) == expected, "missing or unexpected binary manifests")
for name, digest in hashes.items():
    require(hashlib.sha256((args.directory / "builds" / name).read_bytes()).hexdigest() == digest, f"binary hash mismatch: {name}")

arms = data["samples"][args.workload]
require(set(arms) == {"base", "head", "null"}, "missing or unexpected arms")
counts = {arm: len(samples) for arm, samples in arms.items()}
require(all(len(row) == len(data["fields"]) and all(math.isfinite(x) and x >= 0 for x in row) for rows in arms.values() for row in rows), "invalid raw sample")
report = {
    "raw_sha256": hashlib.sha256(raw).hexdigest(),
    "baseline": args.baseline,
    "candidate": args.candidate,
    "workload": args.workload,
    "cpu": data["cpu"],
    "logical_cpus": data["logical_cpus"],
    "complete": data.get("complete"),
    "counts": counts,
    "binary_hashes": hashes,
    "note": "Original cohort only, no pooling. Integrity and numeric verdicts do not establish merge acceptance.",
}
if data.get("complete") is not True:
    require(bool(data.get("failure")), "incomplete samples lack failure context")
    report["failure"] = data["failure"]
else:
    require(len(set(counts.values())) == 1, "unpaired completed cohort")
    count = counts["base"]
    require(60 <= count <= 120 and (count - 60) % perf_ab.ADAPTIVE_STEP == 0, "wrong sample count")
    saved, cells = perf_ab.ledger_row(arms["base"], arms["head"], arms["null"])
    report["saved_percent"] = saved
    report["cells"] = [dataclasses.asdict(cell) for cell in cells]
    report["verdict"] = perf_ab_ledger.row_verdict(cells)
    strict = []
    for cell in cells:
        noise = perf_ab_stats.noise_floor(perf_ab_stats.paired_percent(perf_ab.column(arms["base"], cell.metric), perf_ab.column(arms["null"], cell.metric)))
        strict.append({"metric": cell.metric, "allowance": noise, "verdict": perf_ab_ledger.judge(cell.regression, noise)})
    report["zero_memory_credit_check"] = strict
    release_index = perf_ab.METRICS.index("release ms")
    release = perf_ab.percentile([row[release_index] for row in arms["head"]], perf_ab.RELEASE_PERCENTILE)
    report["p95_release_ms"] = release
    report["release_bound_ms"] = data["release_bound_ms"]
    report["release_held"] = release <= data["release_bound_ms"]
print(json.dumps(report, indent=2))
