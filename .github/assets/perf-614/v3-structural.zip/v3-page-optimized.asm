
/tmp/mimalloc-614-campaign/v2-codegen/CMakeFiles/mimalloc-static.dir/src/page.c.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <mi_page_free_list_extend>:
       0:	0f b7 47 14          	movzwl 0x14(%rdi),%eax
       4:	48 89 d1             	mov    %rdx,%rcx
       7:	8b 57 30             	mov    0x30(%rdi),%edx
       a:	49 89 c0             	mov    %rax,%r8
       d:	48 8d 44 08 ff       	lea    -0x1(%rax,%rcx,1),%rax
      12:	48 c1 e2 04          	shl    $0x4,%rdx
      16:	4c 0f af c6          	imul   %rsi,%r8
      1a:	48 01 fa             	add    %rdi,%rdx
      1d:	48 0f af c6          	imul   %rsi,%rax
      21:	49 01 d0             	add    %rdx,%r8
      24:	48 01 c2             	add    %rax,%rdx
      27:	4c 39 c2             	cmp    %r8,%rdx
      2a:	72 12                	jb     3e <mi_page_free_list_extend+0x3e>
      2c:	4c 89 c0             	mov    %r8,%rax
      2f:	90                   	nop
      30:	48 89 c1             	mov    %rax,%rcx
      33:	48 01 f0             	add    %rsi,%rax
      36:	48 89 01             	mov    %rax,(%rcx)
      39:	48 39 c2             	cmp    %rax,%rdx
      3c:	73 f2                	jae    30 <mi_page_free_list_extend+0x30>
      3e:	48 8b 47 08          	mov    0x8(%rdi),%rax
      42:	48 89 02             	mov    %rax,(%rdx)
      45:	4c 89 47 08          	mov    %r8,0x8(%rdi)
      49:	c3                   	ret
      4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000000050 <mi_page_extend_free>:
      50:	48 83 7e 08 00       	cmpq   $0x0,0x8(%rsi)
      55:	74 09                	je     60 <mi_page_extend_free+0x10>
      57:	b8 01 00 00 00       	mov    $0x1,%eax
      5c:	c3                   	ret
      5d:	0f 1f 00             	nopl   (%rax)
      60:	41 57                	push   %r15
      62:	41 56                	push   %r14
      64:	41 55                	push   %r13
      66:	41 54                	push   %r12
      68:	55                   	push   %rbp
      69:	53                   	push   %rbx
      6a:	48 89 f3             	mov    %rsi,%rbx
      6d:	48 83 ec 08          	sub    $0x8,%rsp
      71:	0f b7 56 14          	movzwl 0x14(%rsi),%edx
      75:	0f b7 46 36          	movzwl 0x36(%rsi),%eax
      79:	66 39 c2             	cmp    %ax,%dx
      7c:	0f 83 61 01 00 00    	jae    1e3 <mi_page_extend_free+0x193>
      82:	48 83 be a0 00 00 00 	cmpq   $0x0,0xa0(%rsi)
      89:	00 
      8a:	49 89 fd             	mov    %rdi,%r13
      8d:	74 13                	je     a2 <mi_page_extend_free+0x52>
      8f:	48 8b 37             	mov    (%rdi),%rsi
      92:	48 89 df             	mov    %rbx,%rdi
      95:	e8 00 00 00 00       	call   9a <mi_page_extend_free+0x4a>
			96: R_X86_64_PLT32	_mi_page_unpublish_retired-0x4
      9a:	0f b7 53 14          	movzwl 0x14(%rbx),%edx
      9e:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
      a2:	4c 8b 63 28          	mov    0x28(%rbx),%r12
      a6:	0f b7 c8             	movzwl %ax,%ecx
      a9:	b8 01 00 00 00       	mov    $0x1,%eax
      ae:	48 29 d1             	sub    %rdx,%rcx
      b1:	49 81 fc ff 0f 00 00 	cmp    $0xfff,%r12
      b8:	0f 86 e2 00 00 00    	jbe    1a0 <mi_page_extend_free+0x150>
      be:	48 39 c8             	cmp    %rcx,%rax
      c1:	44 0f b7 7b 34       	movzwl 0x34(%rbx),%r15d
      c6:	48 0f 46 c8          	cmovbe %rax,%rcx
      ca:	48 89 cd             	mov    %rcx,%rbp
      cd:	e8 00 00 00 00       	call   d2 <mi_page_extend_free+0x82>
			ce: R_X86_64_PLT32	_mi_os_page_size-0x4
      d2:	4c 0f af f8          	imul   %rax,%r15
      d6:	4d 85 ff             	test   %r15,%r15
      d9:	0f 84 35 01 00 00    	je     214 <mi_page_extend_free+0x1c4>
      df:	48 89 e8             	mov    %rbp,%rax
      e2:	49 0f af c4          	imul   %r12,%rax
      e6:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
      ec:	76 1a                	jbe    108 <mi_page_extend_free+0xb8>
      ee:	bd 00 00 01 00       	mov    $0x10000,%ebp
      f3:	4d 85 e4             	test   %r12,%r12
      f6:	74 10                	je     108 <mi_page_extend_free+0xb8>
      f8:	49 8d 84 24 ff ff 00 	lea    0xffff(%r12),%rax
      ff:	00 
     100:	31 d2                	xor    %edx,%edx
     102:	49 f7 f4             	div    %r12
     105:	48 89 c5             	mov    %rax,%rbp
     108:	44 0f b7 73 14       	movzwl 0x14(%rbx),%r14d
     10d:	e8 00 00 00 00       	call   112 <mi_page_extend_free+0xc2>
			10e: R_X86_64_PLT32	_mi_os_page_size-0x4
     112:	8b 73 30             	mov    0x30(%rbx),%esi
     115:	44 8b 43 68          	mov    0x68(%rbx),%r8d
     119:	48 89 c1             	mov    %rax,%rcx
     11c:	49 01 ee             	add    %rbp,%r14
     11f:	b8 00 40 00 00       	mov    $0x4000,%eax
     124:	4d 0f af f4          	imul   %r12,%r14
     128:	48 39 c1             	cmp    %rax,%rcx
     12b:	48 0f 42 c8          	cmovb  %rax,%rcx
     12f:	48 c1 e6 04          	shl    $0x4,%rsi
     133:	48 01 de             	add    %rbx,%rsi
     136:	48 89 f0             	mov    %rsi,%rax
     139:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
     13d:	48 89 f7             	mov    %rsi,%rdi
     140:	66 31 c0             	xor    %ax,%ax
     143:	41 83 f8 06          	cmp    $0x6,%r8d
     147:	48 0f 45 c3          	cmovne %rbx,%rax
     14b:	49 01 d6             	add    %rdx,%r14
     14e:	48 29 c7             	sub    %rax,%rdi
     151:	49 01 fe             	add    %rdi,%r14
     154:	48 85 ca             	test   %rcx,%rdx
     157:	74 57                	je     1b0 <mi_page_extend_free+0x160>
     159:	4c 89 f0             	mov    %r14,%rax
     15c:	31 d2                	xor    %edx,%edx
     15e:	48 f7 f1             	div    %rcx
     161:	49 29 d6             	sub    %rdx,%r14
     164:	4d 39 f7             	cmp    %r14,%r15
     167:	73 52                	jae    1bb <mi_page_extend_free+0x16b>
     169:	4c 89 f2             	mov    %r14,%rdx
     16c:	66 31 f6             	xor    %si,%si
     16f:	49 8b 7d 10          	mov    0x10(%r13),%rdi
     173:	4c 29 fa             	sub    %r15,%rdx
     176:	41 83 f8 06          	cmp    $0x6,%r8d
     17a:	48 0f 45 f3          	cmovne %rbx,%rsi
     17e:	31 c9                	xor    %ecx,%ecx
     180:	4c 01 fe             	add    %r15,%rsi
     183:	e8 00 00 00 00       	call   188 <mi_page_extend_free+0x138>
			184: R_X86_64_PLT32	_mi_os_commit-0x4
     188:	84 c0                	test   %al,%al
     18a:	75 74                	jne    200 <mi_page_extend_free+0x1b0>
     18c:	48 83 c4 08          	add    $0x8,%rsp
     190:	5b                   	pop    %rbx
     191:	5d                   	pop    %rbp
     192:	41 5c                	pop    %r12
     194:	41 5d                	pop    %r13
     196:	41 5e                	pop    %r14
     198:	41 5f                	pop    %r15
     19a:	c3                   	ret
     19b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     1a0:	b8 00 10 00 00       	mov    $0x1000,%eax
     1a5:	31 d2                	xor    %edx,%edx
     1a7:	49 f7 f4             	div    %r12
     1aa:	e9 0f ff ff ff       	jmp    be <mi_page_extend_free+0x6e>
     1af:	90                   	nop
     1b0:	48 f7 d9             	neg    %rcx
     1b3:	49 21 ce             	and    %rcx,%r14
     1b6:	4d 39 f7             	cmp    %r14,%r15
     1b9:	72 ae                	jb     169 <mi_page_extend_free+0x119>
     1bb:	0f b7 43 14          	movzwl 0x14(%rbx),%eax
     1bf:	48 89 df             	mov    %rbx,%rdi
     1c2:	48 01 e8             	add    %rbp,%rax
     1c5:	49 0f af c4          	imul   %r12,%rax
     1c9:	48 01 c6             	add    %rax,%rsi
     1cc:	e8 00 00 00 00       	call   1d1 <mi_page_extend_free+0x181>
			1cd: R_X86_64_PLT32	_mi_page_unpurge_unformed_upto-0x4
     1d1:	48 89 ea             	mov    %rbp,%rdx
     1d4:	4c 89 e6             	mov    %r12,%rsi
     1d7:	48 89 df             	mov    %rbx,%rdi
     1da:	e8 21 fe ff ff       	call   0 <mi_page_free_list_extend>
     1df:	66 01 6b 14          	add    %bp,0x14(%rbx)
     1e3:	48 83 c4 08          	add    $0x8,%rsp
     1e7:	b8 01 00 00 00       	mov    $0x1,%eax
     1ec:	5b                   	pop    %rbx
     1ed:	5d                   	pop    %rbp
     1ee:	41 5c                	pop    %r12
     1f0:	41 5d                	pop    %r13
     1f2:	41 5e                	pop    %r14
     1f4:	41 5f                	pop    %r15
     1f6:	c3                   	ret
     1f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     1fe:	00 00 
     200:	e8 00 00 00 00       	call   205 <mi_page_extend_free+0x1b5>
			201: R_X86_64_PLT32	_mi_os_page_size-0x4
     205:	31 d2                	xor    %edx,%edx
     207:	48 89 c1             	mov    %rax,%rcx
     20a:	4c 89 f0             	mov    %r14,%rax
     20d:	48 f7 f1             	div    %rcx
     210:	66 89 43 34          	mov    %ax,0x34(%rbx)
     214:	8b 73 30             	mov    0x30(%rbx),%esi
     217:	48 c1 e6 04          	shl    $0x4,%rsi
     21b:	48 01 de             	add    %rbx,%rsi
     21e:	eb 9b                	jmp    1bb <mi_page_extend_free+0x16b>

0000000000000220 <mi_page_free_collect_ex.constprop.0>:
     220:	55                   	push   %rbp
     221:	89 f5                	mov    %esi,%ebp
     223:	48 8d 77 20          	lea    0x20(%rdi),%rsi
     227:	53                   	push   %rbx
     228:	48 89 fb             	mov    %rdi,%rbx
     22b:	48 83 ec 08          	sub    $0x8,%rsp
     22f:	48 8b 07             	mov    (%rdi),%rax
     232:	48 8b 57 20          	mov    0x20(%rdi),%rdx
     236:	48 83 fa 01          	cmp    $0x1,%rdx
     23a:	77 74                	ja     2b0 <mi_page_free_collect_ex.constprop.0+0x90>
     23c:	48 8b 43 18          	mov    0x18(%rbx),%rax
     240:	48 8b 53 08          	mov    0x8(%rbx),%rdx
     244:	48 85 c0             	test   %rax,%rax
     247:	74 27                	je     270 <mi_page_free_collect_ex.constprop.0+0x50>
     249:	48 85 d2             	test   %rdx,%rdx
     24c:	0f 85 c6 00 00 00    	jne    318 <mi_page_free_collect_ex.constprop.0+0xf8>
     252:	48 89 43 08          	mov    %rax,0x8(%rbx)
     256:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
     25d:	00 
     25e:	c6 43 17 00          	movb   $0x0,0x17(%rbx)
     262:	48 83 c4 08          	add    $0x8,%rsp
     266:	5b                   	pop    %rbx
     267:	5d                   	pop    %rbp
     268:	c3                   	ret
     269:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     270:	48 85 d2             	test   %rdx,%rdx
     273:	75 ed                	jne    262 <mi_page_free_collect_ex.constprop.0+0x42>
     275:	48 83 7b 70 00       	cmpq   $0x0,0x70(%rbx)
     27a:	75 1b                	jne    297 <mi_page_free_collect_ex.constprop.0+0x77>
     27c:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
     281:	75 14                	jne    297 <mi_page_free_collect_ex.constprop.0+0x77>
     283:	48 83 bb 80 00 00 00 	cmpq   $0x0,0x80(%rbx)
     28a:	00 
     28b:	75 0a                	jne    297 <mi_page_free_collect_ex.constprop.0+0x77>
     28d:	48 83 bb 88 00 00 00 	cmpq   $0x0,0x88(%rbx)
     294:	00 
     295:	74 cb                	je     262 <mi_page_free_collect_ex.constprop.0+0x42>
     297:	e8 00 00 00 00       	call   29c <mi_page_free_collect_ex.constprop.0+0x7c>
			298: R_X86_64_PLT32	_mi_page_purge_holes_in_progress-0x4
     29c:	84 c0                	test   %al,%al
     29e:	75 c2                	jne    262 <mi_page_free_collect_ex.constprop.0+0x42>
     2a0:	48 83 c4 08          	add    $0x8,%rsp
     2a4:	48 89 df             	mov    %rbx,%rdi
     2a7:	5b                   	pop    %rbx
     2a8:	5d                   	pop    %rbp
     2a9:	e9 00 00 00 00       	jmp    2ae <mi_page_free_collect_ex.constprop.0+0x8e>
			2aa: R_X86_64_PLT32	_mi_page_unpurge_run-0x4
     2ae:	66 90                	xchg   %ax,%ax
     2b0:	48 89 d1             	mov    %rdx,%rcx
     2b3:	48 89 d0             	mov    %rdx,%rax
     2b6:	83 e1 01             	and    $0x1,%ecx
     2b9:	f0 48 0f b1 0e       	lock cmpxchg %rcx,(%rsi)
     2be:	0f 94 c1             	sete   %cl
     2c1:	0f b6 c9             	movzbl %cl,%ecx
     2c4:	0f 85 b5 00 00 00    	jne    37f <mi_page_free_collect_ex.constprop.0+0x15f>
     2ca:	48 89 d0             	mov    %rdx,%rax
     2cd:	0f b7 73 14          	movzwl 0x14(%rbx),%esi
     2d1:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
     2d5:	48 8b 10             	mov    (%rax),%rdx
     2d8:	48 85 f6             	test   %rsi,%rsi
     2db:	74 5e                	je     33b <mi_page_free_collect_ex.constprop.0+0x11b>
     2dd:	48 85 d2             	test   %rdx,%rdx
     2e0:	75 0b                	jne    2ed <mi_page_free_collect_ex.constprop.0+0xcd>
     2e2:	eb 57                	jmp    33b <mi_page_free_collect_ex.constprop.0+0x11b>
     2e4:	0f 1f 40 00          	nopl   0x0(%rax)
     2e8:	48 85 d2             	test   %rdx,%rdx
     2eb:	74 51                	je     33e <mi_page_free_collect_ex.constprop.0+0x11e>
     2ed:	48 83 c1 01          	add    $0x1,%rcx
     2f1:	48 89 d7             	mov    %rdx,%rdi
     2f4:	48 8b 12             	mov    (%rdx),%rdx
     2f7:	48 39 ce             	cmp    %rcx,%rsi
     2fa:	73 ec                	jae    2e8 <mi_page_free_collect_ex.constprop.0+0xc8>
     2fc:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 303 <mi_page_free_collect_ex.constprop.0+0xe3>
			2ff: R_X86_64_PC32	.LC0-0x4
     303:	bf 0e 00 00 00       	mov    $0xe,%edi
     308:	31 c0                	xor    %eax,%eax
     30a:	e8 00 00 00 00       	call   30f <mi_page_free_collect_ex.constprop.0+0xef>
			30b: R_X86_64_PLT32	_mi_error_message-0x4
     30f:	e9 28 ff ff ff       	jmp    23c <mi_page_free_collect_ex.constprop.0+0x1c>
     314:	0f 1f 40 00          	nopl   0x0(%rax)
     318:	40 84 ed             	test   %bpl,%bpl
     31b:	0f 84 41 ff ff ff    	je     262 <mi_page_free_collect_ex.constprop.0+0x42>
     321:	48 89 c1             	mov    %rax,%rcx
     324:	0f 1f 40 00          	nopl   0x0(%rax)
     328:	48 89 ce             	mov    %rcx,%rsi
     32b:	48 8b 09             	mov    (%rcx),%rcx
     32e:	48 85 c9             	test   %rcx,%rcx
     331:	75 f5                	jne    328 <mi_page_free_collect_ex.constprop.0+0x108>
     333:	48 89 16             	mov    %rdx,(%rsi)
     336:	e9 17 ff ff ff       	jmp    252 <mi_page_free_collect_ex.constprop.0+0x32>
     33b:	48 89 c7             	mov    %rax,%rdi
     33e:	48 39 ce             	cmp    %rcx,%rsi
     341:	72 b9                	jb     2fc <mi_page_free_collect_ex.constprop.0+0xdc>
     343:	8b 73 10             	mov    0x10(%rbx),%esi
     346:	48 89 f2             	mov    %rsi,%rdx
     349:	48 39 ce             	cmp    %rcx,%rsi
     34c:	72 19                	jb     367 <mi_page_free_collect_ex.constprop.0+0x147>
     34e:	48 8b 73 18          	mov    0x18(%rbx),%rsi
     352:	29 ca                	sub    %ecx,%edx
     354:	48 89 37             	mov    %rsi,(%rdi)
     357:	89 53 10             	mov    %edx,0x10(%rbx)
     35a:	48 8b 53 08          	mov    0x8(%rbx),%rdx
     35e:	48 89 43 18          	mov    %rax,0x18(%rbx)
     362:	e9 e2 fe ff ff       	jmp    249 <mi_page_free_collect_ex.constprop.0+0x29>
     367:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 36e <mi_page_free_collect_ex.constprop.0+0x14e>
			36a: R_X86_64_PC32	.LC1-0x4
     36e:	bf 0e 00 00 00       	mov    $0xe,%edi
     373:	31 c0                	xor    %eax,%eax
     375:	e8 00 00 00 00       	call   37a <mi_page_free_collect_ex.constprop.0+0x15a>
			376: R_X86_64_PLT32	_mi_error_message-0x4
     37a:	e9 bd fe ff ff       	jmp    23c <mi_page_free_collect_ex.constprop.0+0x1c>
     37f:	48 89 c2             	mov    %rax,%rdx
     382:	e9 af fe ff ff       	jmp    236 <mi_page_free_collect_ex.constprop.0+0x16>
     387:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     38e:	00 00 

0000000000000390 <mi_page_queue_push>:
     390:	4c 8b 46 18          	mov    0x18(%rsi),%r8
     394:	49 89 f9             	mov    %rdi,%r9
     397:	48 8b 02             	mov    (%rdx),%rax
     39a:	48 89 d7             	mov    %rdx,%rdi
     39d:	49 81 f8 10 00 08 00 	cmp    $0x80010,%r8
     3a4:	41 0f 94 c2          	sete   %r10b
     3a8:	0f 85 92 01 00 00    	jne    540 <mi_page_queue_push+0x1b0>
     3ae:	48 89 c1             	mov    %rax,%rcx
     3b1:	48 89 c2             	mov    %rax,%rdx
     3b4:	48 83 c9 01          	or     $0x1,%rcx
     3b8:	f0 48 0f b1 0f       	lock cmpxchg %rcx,(%rdi)
     3bd:	75 ef                	jne    3ae <mi_page_queue_push+0x1e>
     3bf:	83 e2 01             	and    $0x1,%edx
     3c2:	41 38 d2             	cmp    %dl,%r10b
     3c5:	74 34                	je     3fb <mi_page_queue_push+0x6b>
     3c7:	48 8b 57 38          	mov    0x38(%rdi),%rdx
     3cb:	48 85 d2             	test   %rdx,%rdx
     3ce:	74 2b                	je     3fb <mi_page_queue_push+0x6b>
     3d0:	48 8b 8a d0 00 00 00 	mov    0xd0(%rdx),%rcx
     3d7:	0f b7 47 36          	movzwl 0x36(%rdi),%eax
     3db:	48 0f af 47 28       	imul   0x28(%rdi),%rax
     3e0:	49 89 ca             	mov    %rcx,%r10
     3e3:	49 29 c2             	sub    %rax,%r10
     3e6:	48 01 c8             	add    %rcx,%rax
     3e9:	49 81 f8 10 00 08 00 	cmp    $0x80010,%r8
     3f0:	49 0f 45 c2          	cmovne %r10,%rax
     3f4:	48 89 82 d0 00 00 00 	mov    %rax,0xd0(%rdx)
     3fb:	48 8b 06             	mov    (%rsi),%rax
     3fe:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
     405:	00 
     406:	48 89 47 48          	mov    %rax,0x48(%rdi)
     40a:	48 85 c0             	test   %rax,%rax
     40d:	0f 84 5d 01 00 00    	je     570 <mi_page_queue_push+0x1e0>
     413:	48 89 78 50          	mov    %rdi,0x50(%rax)
     417:	4c 8b 46 18          	mov    0x18(%rsi),%r8
     41b:	48 83 46 10 01       	addq   $0x1,0x10(%rsi)
     420:	48 89 3e             	mov    %rdi,(%rsi)
     423:	49 81 f8 00 04 00 00 	cmp    $0x400,%r8
     42a:	0f 87 80 01 00 00    	ja     5b0 <mi_page_queue_push+0x220>
     430:	49 83 c0 07          	add    $0x7,%r8
     434:	4d 8d 91 18 01 00 00 	lea    0x118(%r9),%r10
     43b:	49 c1 e8 03          	shr    $0x3,%r8
     43f:	4b 3b bc c1 18 01 00 	cmp    0x118(%r9,%r8,8),%rdi
     446:	00 
     447:	0f 84 63 01 00 00    	je     5b0 <mi_page_queue_push+0x220>
     44d:	41 54                	push   %r12
     44f:	55                   	push   %rbp
     450:	53                   	push   %rbx
     451:	49 83 f8 01          	cmp    $0x1,%r8
     455:	0f 86 05 01 00 00    	jbe    560 <mi_page_queue_push+0x1d0>
     45b:	49 83 f8 08          	cmp    $0x8,%r8
     45f:	0f 87 54 01 00 00    	ja     5b9 <mi_page_queue_push+0x229>
     465:	4d 8d 58 01          	lea    0x1(%r8),%r11
     469:	4c 89 dd             	mov    %r11,%rbp
     46c:	48 83 e5 fe          	and    $0xfffffffffffffffe,%rbp
     470:	48 83 ee 20          	sub    $0x20,%rsi
     474:	49 8d 99 20 05 00 00 	lea    0x520(%r9),%rbx
     47b:	eb 19                	jmp    496 <mi_page_queue_push+0x106>
     47d:	0f 1f 00             	nopl   (%rax)
     480:	48 8d 50 01          	lea    0x1(%rax),%rdx
     484:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
     488:	48 39 d5             	cmp    %rdx,%rbp
     48b:	75 28                	jne    4b5 <mi_page_queue_push+0x125>
     48d:	48 39 f3             	cmp    %rsi,%rbx
     490:	73 23                	jae    4b5 <mi_page_queue_push+0x125>
     492:	48 83 ee 20          	sub    $0x20,%rsi
     496:	48 8b 46 18          	mov    0x18(%rsi),%rax
     49a:	48 8d 50 07          	lea    0x7(%rax),%rdx
     49e:	48 89 d0             	mov    %rdx,%rax
     4a1:	48 c1 e8 03          	shr    $0x3,%rax
     4a5:	48 83 fa 47          	cmp    $0x47,%rdx
     4a9:	0f 87 d1 00 00 00    	ja     580 <mi_page_queue_push+0x1f0>
     4af:	48 83 f8 01          	cmp    $0x1,%rax
     4b3:	77 cb                	ja     480 <mi_page_queue_push+0xf0>
     4b5:	48 83 c0 01          	add    $0x1,%rax
     4b9:	4c 39 c0             	cmp    %r8,%rax
     4bc:	49 0f 47 c0          	cmova  %r8,%rax
     4c0:	48 8d 50 01          	lea    0x1(%rax),%rdx
     4c4:	4c 89 d9             	mov    %r11,%rcx
     4c7:	be 01 00 00 00       	mov    $0x1,%esi
     4cc:	48 29 c1             	sub    %rax,%rcx
     4cf:	49 39 d3             	cmp    %rdx,%r11
     4d2:	48 0f 42 ce          	cmovb  %rsi,%rcx
     4d6:	49 39 c0             	cmp    %rax,%r8
     4d9:	74 51                	je     52c <mi_page_queue_push+0x19c>
     4db:	49 39 d3             	cmp    %rdx,%r11
     4de:	72 4c                	jb     52c <mi_page_queue_push+0x19c>
     4e0:	48 89 ce             	mov    %rcx,%rsi
     4e3:	49 8d 94 c1 18 01 00 	lea    0x118(%r9,%rax,8),%rdx
     4ea:	00 
     4eb:	66 48 0f 6e c7       	movq   %rdi,%xmm0
     4f0:	48 d1 ee             	shr    $1,%rsi
     4f3:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
     4f7:	48 c1 e6 04          	shl    $0x4,%rsi
     4fb:	4c 8d 04 16          	lea    (%rsi,%rdx,1),%r8
     4ff:	83 e6 10             	and    $0x10,%esi
     502:	74 0c                	je     510 <mi_page_queue_push+0x180>
     504:	0f 11 02             	movups %xmm0,(%rdx)
     507:	48 83 c2 10          	add    $0x10,%rdx
     50b:	49 39 d0             	cmp    %rdx,%r8
     50e:	74 10                	je     520 <mi_page_queue_push+0x190>
     510:	0f 11 02             	movups %xmm0,(%rdx)
     513:	48 83 c2 20          	add    $0x20,%rdx
     517:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
     51b:	49 39 d0             	cmp    %rdx,%r8
     51e:	75 f0                	jne    510 <mi_page_queue_push+0x180>
     520:	f6 c1 01             	test   $0x1,%cl
     523:	74 0b                	je     530 <mi_page_queue_push+0x1a0>
     525:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     529:	48 01 c8             	add    %rcx,%rax
     52c:	49 89 3c c2          	mov    %rdi,(%r10,%rax,8)
     530:	5b                   	pop    %rbx
     531:	49 83 81 b8 00 00 00 	addq   $0x1,0xb8(%r9)
     538:	01 
     539:	5d                   	pop    %rbp
     53a:	41 5c                	pop    %r12
     53c:	c3                   	ret
     53d:	0f 1f 00             	nopl   (%rax)
     540:	48 89 c1             	mov    %rax,%rcx
     543:	48 89 c2             	mov    %rax,%rdx
     546:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     54a:	f0 48 0f b1 0f       	lock cmpxchg %rcx,(%rdi)
     54f:	0f 84 6a fe ff ff    	je     3bf <mi_page_queue_push+0x2f>
     555:	eb e9                	jmp    540 <mi_page_queue_push+0x1b0>
     557:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     55e:	00 00 
     560:	31 c0                	xor    %eax,%eax
     562:	4d 8d 58 01          	lea    0x1(%r8),%r11
     566:	e9 55 ff ff ff       	jmp    4c0 <mi_page_queue_push+0x130>
     56b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     570:	48 89 7e 08          	mov    %rdi,0x8(%rsi)
     574:	e9 9e fe ff ff       	jmp    417 <mi_page_queue_push+0x87>
     579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     580:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
     586:	0f 87 29 ff ff ff    	ja     4b5 <mi_page_queue_push+0x125>
     58c:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
     590:	4c 0f bd e2          	bsr    %rdx,%r12
     594:	41 8d 4c 24 fe       	lea    -0x2(%r12),%ecx
     599:	48 d3 ea             	shr    %cl,%rdx
     59c:	83 e2 03             	and    $0x3,%edx
     59f:	4a 8d 54 a2 fd       	lea    -0x3(%rdx,%r12,4),%rdx
     5a4:	e9 df fe ff ff       	jmp    488 <mi_page_queue_push+0xf8>
     5a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     5b0:	49 83 81 b8 00 00 00 	addq   $0x1,0xb8(%r9)
     5b7:	01 
     5b8:	c3                   	ret
     5b9:	49 8d 40 ff          	lea    -0x1(%r8),%rax
     5bd:	4d 8d 58 01          	lea    0x1(%r8),%r11
     5c1:	48 0f bd d0          	bsr    %rax,%rdx
     5c5:	8d 4a fe             	lea    -0x2(%rdx),%ecx
     5c8:	48 d3 e8             	shr    %cl,%rax
     5cb:	83 e0 03             	and    $0x3,%eax
     5ce:	48 8d 6c 90 fd       	lea    -0x3(%rax,%rdx,4),%rbp
     5d3:	e9 98 fe ff ff       	jmp    470 <mi_page_queue_push+0xe0>
     5d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     5df:	00 

00000000000005e0 <mi_page_queue_remove>:
     5e0:	41 56                	push   %r14
     5e2:	41 55                	push   %r13
     5e4:	41 54                	push   %r12
     5e6:	49 89 fc             	mov    %rdi,%r12
     5e9:	55                   	push   %rbp
     5ea:	53                   	push   %rbx
     5eb:	48 8b 56 50          	mov    0x50(%rsi),%rdx
     5ef:	48 89 f3             	mov    %rsi,%rbx
     5f2:	48 8b 6e 38          	mov    0x38(%rsi),%rbp
     5f6:	48 85 d2             	test   %rdx,%rdx
     5f9:	74 08                	je     603 <mi_page_queue_remove+0x23>
     5fb:	48 8b 46 48          	mov    0x48(%rsi),%rax
     5ff:	48 89 42 48          	mov    %rax,0x48(%rdx)
     603:	48 8b 43 48          	mov    0x48(%rbx),%rax
     607:	48 85 c0             	test   %rax,%rax
     60a:	74 04                	je     610 <mi_page_queue_remove+0x30>
     60c:	48 89 50 50          	mov    %rdx,0x50(%rax)
     610:	49 39 5c 24 08       	cmp    %rbx,0x8(%r12)
     615:	74 49                	je     660 <mi_page_queue_remove+0x80>
     617:	49 39 1c 24          	cmp    %rbx,(%r12)
     61b:	74 52                	je     66f <mi_page_queue_remove+0x8f>
     61d:	48 83 ad b8 00 00 00 	subq   $0x1,0xb8(%rbp)
     624:	01 
     625:	66 0f ef c0          	pxor   %xmm0,%xmm0
     629:	49 83 6c 24 10 01    	subq   $0x1,0x10(%r12)
     62f:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
     633:	f0 48 0f ba 33 00    	lock btrq $0x0,(%rbx)
     639:	73 19                	jae    654 <mi_page_queue_remove+0x74>
     63b:	48 8b 43 38          	mov    0x38(%rbx),%rax
     63f:	48 85 c0             	test   %rax,%rax
     642:	74 10                	je     654 <mi_page_queue_remove+0x74>
     644:	0f b7 53 36          	movzwl 0x36(%rbx),%edx
     648:	48 0f af 53 28       	imul   0x28(%rbx),%rdx
     64d:	48 29 90 d0 00 00 00 	sub    %rdx,0xd0(%rax)
     654:	5b                   	pop    %rbx
     655:	5d                   	pop    %rbp
     656:	41 5c                	pop    %r12
     658:	41 5d                	pop    %r13
     65a:	41 5e                	pop    %r14
     65c:	c3                   	ret
     65d:	0f 1f 00             	nopl   (%rax)
     660:	48 8b 53 50          	mov    0x50(%rbx),%rdx
     664:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
     669:	49 39 1c 24          	cmp    %rbx,(%r12)
     66d:	75 ae                	jne    61d <mi_page_queue_remove+0x3d>
     66f:	4d 8b 6c 24 18       	mov    0x18(%r12),%r13
     674:	49 89 04 24          	mov    %rax,(%r12)
     678:	49 81 fd 00 04 00 00 	cmp    $0x400,%r13
     67f:	77 9c                	ja     61d <mi_page_queue_remove+0x3d>
     681:	48 85 c0             	test   %rax,%rax
     684:	0f 84 56 01 00 00    	je     7e0 <mi_page_queue_remove+0x200>
     68a:	49 8d 7d 07          	lea    0x7(%r13),%rdi
     68e:	4c 8d 85 18 01 00 00 	lea    0x118(%rbp),%r8
     695:	48 c1 ef 03          	shr    $0x3,%rdi
     699:	48 39 84 fd 18 01 00 	cmp    %rax,0x118(%rbp,%rdi,8)
     6a0:	00 
     6a1:	0f 84 76 ff ff ff    	je     61d <mi_page_queue_remove+0x3d>
     6a7:	48 83 ff 01          	cmp    $0x1,%rdi
     6ab:	0f 86 1f 01 00 00    	jbe    7d0 <mi_page_queue_remove+0x1f0>
     6b1:	48 83 ff 08          	cmp    $0x8,%rdi
     6b5:	0f 87 2f 01 00 00    	ja     7ea <mi_page_queue_remove+0x20a>
     6bb:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     6bf:	4d 89 cb             	mov    %r9,%r11
     6c2:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
     6c6:	49 8d 74 24 e0       	lea    -0x20(%r12),%rsi
     6cb:	4c 8d 95 20 05 00 00 	lea    0x520(%rbp),%r10
     6d2:	eb 1a                	jmp    6ee <mi_page_queue_remove+0x10e>
     6d4:	0f 1f 40 00          	nopl   0x0(%rax)
     6d8:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
     6dc:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     6e0:	49 39 cb             	cmp    %rcx,%r11
     6e3:	75 28                	jne    70d <mi_page_queue_remove+0x12d>
     6e5:	49 39 f2             	cmp    %rsi,%r10
     6e8:	73 23                	jae    70d <mi_page_queue_remove+0x12d>
     6ea:	48 83 ee 20          	sub    $0x20,%rsi
     6ee:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
     6f2:	48 83 c1 07          	add    $0x7,%rcx
     6f6:	48 89 ca             	mov    %rcx,%rdx
     6f9:	48 c1 ea 03          	shr    $0x3,%rdx
     6fd:	48 83 f9 47          	cmp    $0x47,%rcx
     701:	0f 87 99 00 00 00    	ja     7a0 <mi_page_queue_remove+0x1c0>
     707:	48 83 fa 01          	cmp    $0x1,%rdx
     70b:	77 cb                	ja     6d8 <mi_page_queue_remove+0xf8>
     70d:	48 83 c2 01          	add    $0x1,%rdx
     711:	48 39 fa             	cmp    %rdi,%rdx
     714:	48 0f 47 d7          	cmova  %rdi,%rdx
     718:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
     71c:	4c 89 ce             	mov    %r9,%rsi
     71f:	41 ba 01 00 00 00    	mov    $0x1,%r10d
     725:	48 29 d6             	sub    %rdx,%rsi
     728:	49 39 c9             	cmp    %rcx,%r9
     72b:	49 0f 42 f2          	cmovb  %r10,%rsi
     72f:	48 39 d7             	cmp    %rdx,%rdi
     732:	74 5d                	je     791 <mi_page_queue_remove+0x1b1>
     734:	49 39 c9             	cmp    %rcx,%r9
     737:	72 58                	jb     791 <mi_page_queue_remove+0x1b1>
     739:	48 89 f7             	mov    %rsi,%rdi
     73c:	48 8d 8c d5 18 01 00 	lea    0x118(%rbp,%rdx,8),%rcx
     743:	00 
     744:	66 48 0f 6e c0       	movq   %rax,%xmm0
     749:	48 d1 ef             	shr    $1,%rdi
     74c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
     750:	48 c1 e7 04          	shl    $0x4,%rdi
     754:	4c 8d 0c 0f          	lea    (%rdi,%rcx,1),%r9
     758:	83 e7 10             	and    $0x10,%edi
     75b:	74 13                	je     770 <mi_page_queue_remove+0x190>
     75d:	0f 11 01             	movups %xmm0,(%rcx)
     760:	48 83 c1 10          	add    $0x10,%rcx
     764:	49 39 c9             	cmp    %rcx,%r9
     767:	74 17                	je     780 <mi_page_queue_remove+0x1a0>
     769:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     770:	0f 11 01             	movups %xmm0,(%rcx)
     773:	48 83 c1 20          	add    $0x20,%rcx
     777:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
     77b:	49 39 c9             	cmp    %rcx,%r9
     77e:	75 f0                	jne    770 <mi_page_queue_remove+0x190>
     780:	40 f6 c6 01          	test   $0x1,%sil
     784:	0f 84 93 fe ff ff    	je     61d <mi_page_queue_remove+0x3d>
     78a:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
     78e:	48 01 f2             	add    %rsi,%rdx
     791:	49 89 04 d0          	mov    %rax,(%r8,%rdx,8)
     795:	e9 83 fe ff ff       	jmp    61d <mi_page_queue_remove+0x3d>
     79a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     7a0:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
     7a7:	0f 87 60 ff ff ff    	ja     70d <mi_page_queue_remove+0x12d>
     7ad:	4c 8d 6a ff          	lea    -0x1(%rdx),%r13
     7b1:	4d 0f bd f5          	bsr    %r13,%r14
     7b5:	41 8d 4e fe          	lea    -0x2(%r14),%ecx
     7b9:	49 d3 ed             	shr    %cl,%r13
     7bc:	41 83 e5 03          	and    $0x3,%r13d
     7c0:	4b 8d 4c b5 fd       	lea    -0x3(%r13,%r14,4),%rcx
     7c5:	e9 16 ff ff ff       	jmp    6e0 <mi_page_queue_remove+0x100>
     7ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     7d0:	31 d2                	xor    %edx,%edx
     7d2:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     7d6:	e9 3d ff ff ff       	jmp    718 <mi_page_queue_remove+0x138>
     7db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     7e0:	e8 00 00 00 00       	call   7e5 <mi_page_queue_remove+0x205>
			7e1: R_X86_64_PLT32	_mi_page_empty_get-0x4
     7e5:	e9 a0 fe ff ff       	jmp    68a <mi_page_queue_remove+0xaa>
     7ea:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
     7ee:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     7f2:	48 0f bd f2          	bsr    %rdx,%rsi
     7f6:	8d 4e fe             	lea    -0x2(%rsi),%ecx
     7f9:	48 d3 ea             	shr    %cl,%rdx
     7fc:	83 e2 03             	and    $0x3,%edx
     7ff:	4c 8d 5c b2 fd       	lea    -0x3(%rdx,%rsi,4),%r11
     804:	e9 bd fe ff ff       	jmp    6c6 <mi_page_queue_remove+0xe6>
     809:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000000810 <mi_page_queue_enqueue_from_ex.constprop.0>:
     810:	41 57                	push   %r15
     812:	41 56                	push   %r14
     814:	41 55                	push   %r13
     816:	41 54                	push   %r12
     818:	49 89 f4             	mov    %rsi,%r12
     81b:	55                   	push   %rbp
     81c:	48 89 fd             	mov    %rdi,%rbp
     81f:	53                   	push   %rbx
     820:	48 89 d3             	mov    %rdx,%rbx
     823:	48 83 ec 08          	sub    $0x8,%rsp
     827:	4c 8b 6a 38          	mov    0x38(%rdx),%r13
     82b:	48 8b 52 50          	mov    0x50(%rdx),%rdx
     82f:	48 85 d2             	test   %rdx,%rdx
     832:	74 08                	je     83c <mi_page_queue_enqueue_from_ex.constprop.0+0x2c>
     834:	48 8b 43 48          	mov    0x48(%rbx),%rax
     838:	48 89 42 48          	mov    %rax,0x48(%rdx)
     83c:	48 8b 43 48          	mov    0x48(%rbx),%rax
     840:	48 85 c0             	test   %rax,%rax
     843:	74 04                	je     849 <mi_page_queue_enqueue_from_ex.constprop.0+0x39>
     845:	48 89 50 50          	mov    %rdx,0x50(%rax)
     849:	49 3b 5c 24 08       	cmp    0x8(%r12),%rbx
     84e:	0f 84 e4 01 00 00    	je     a38 <mi_page_queue_enqueue_from_ex.constprop.0+0x228>
     854:	49 3b 1c 24          	cmp    (%r12),%rbx
     858:	0f 84 ed 01 00 00    	je     a4b <mi_page_queue_enqueue_from_ex.constprop.0+0x23b>
     85e:	48 8b 75 18          	mov    0x18(%rbp),%rsi
     862:	48 8b 45 08          	mov    0x8(%rbp),%rax
     866:	49 83 6c 24 10 01    	subq   $0x1,0x10(%r12)
     86c:	48 83 45 10 01       	addq   $0x1,0x10(%rbp)
     871:	48 81 fe 10 00 08 00 	cmp    $0x80010,%rsi
     878:	48 89 43 50          	mov    %rax,0x50(%rbx)
     87c:	40 0f 94 c7          	sete   %dil
     880:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
     887:	00 
     888:	48 85 c0             	test   %rax,%rax
     88b:	74 7b                	je     908 <mi_page_queue_enqueue_from_ex.constprop.0+0xf8>
     88d:	48 89 58 48          	mov    %rbx,0x48(%rax)
     891:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
     895:	48 81 fe 10 00 08 00 	cmp    $0x80010,%rsi
     89c:	0f 85 76 01 00 00    	jne    a18 <mi_page_queue_enqueue_from_ex.constprop.0+0x208>
     8a2:	48 8b 03             	mov    (%rbx),%rax
     8a5:	48 89 c1             	mov    %rax,%rcx
     8a8:	48 89 c2             	mov    %rax,%rdx
     8ab:	48 83 c9 01          	or     $0x1,%rcx
     8af:	f0 48 0f b1 0b       	lock cmpxchg %rcx,(%rbx)
     8b4:	75 ef                	jne    8a5 <mi_page_queue_enqueue_from_ex.constprop.0+0x95>
     8b6:	83 e2 01             	and    $0x1,%edx
     8b9:	40 38 d7             	cmp    %dl,%dil
     8bc:	74 34                	je     8f2 <mi_page_queue_enqueue_from_ex.constprop.0+0xe2>
     8be:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
     8c2:	48 85 c9             	test   %rcx,%rcx
     8c5:	74 2b                	je     8f2 <mi_page_queue_enqueue_from_ex.constprop.0+0xe2>
     8c7:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
     8ce:	0f b7 53 36          	movzwl 0x36(%rbx),%edx
     8d2:	48 0f af 53 28       	imul   0x28(%rbx),%rdx
     8d7:	48 89 c7             	mov    %rax,%rdi
     8da:	48 29 d7             	sub    %rdx,%rdi
     8dd:	48 01 d0             	add    %rdx,%rax
     8e0:	48 81 fe 10 00 08 00 	cmp    $0x80010,%rsi
     8e7:	48 0f 45 c7          	cmovne %rdi,%rax
     8eb:	48 89 81 d0 00 00 00 	mov    %rax,0xd0(%rcx)
     8f2:	48 83 c4 08          	add    $0x8,%rsp
     8f6:	5b                   	pop    %rbx
     8f7:	5d                   	pop    %rbp
     8f8:	41 5c                	pop    %r12
     8fa:	41 5d                	pop    %r13
     8fc:	41 5e                	pop    %r14
     8fe:	41 5f                	pop    %r15
     900:	c3                   	ret
     901:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     908:	66 48 0f 6e c3       	movq   %rbx,%xmm0
     90d:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
     911:	0f 11 45 00          	movups %xmm0,0x0(%rbp)
     915:	48 81 fe 00 04 00 00 	cmp    $0x400,%rsi
     91c:	0f 87 73 ff ff ff    	ja     895 <mi_page_queue_enqueue_from_ex.constprop.0+0x85>
     922:	4c 8d 46 07          	lea    0x7(%rsi),%r8
     926:	4d 8d 8d 18 01 00 00 	lea    0x118(%r13),%r9
     92d:	49 c1 e8 03          	shr    $0x3,%r8
     931:	4b 3b 9c c5 18 01 00 	cmp    0x118(%r13,%r8,8),%rbx
     938:	00 
     939:	0f 84 d9 00 00 00    	je     a18 <mi_page_queue_enqueue_from_ex.constprop.0+0x208>
     93f:	49 83 f8 01          	cmp    $0x1,%r8
     943:	0f 86 bf 02 00 00    	jbe    c08 <mi_page_queue_enqueue_from_ex.constprop.0+0x3f8>
     949:	49 83 f8 08          	cmp    $0x8,%r8
     94d:	0f 87 cf 02 00 00    	ja     c22 <mi_page_queue_enqueue_from_ex.constprop.0+0x412>
     953:	4d 8d 50 01          	lea    0x1(%r8),%r10
     957:	4d 89 d3             	mov    %r10,%r11
     95a:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
     95e:	48 83 ed 20          	sub    $0x20,%rbp
     962:	4d 8d a5 20 05 00 00 	lea    0x520(%r13),%r12
     969:	eb 1b                	jmp    986 <mi_page_queue_enqueue_from_ex.constprop.0+0x176>
     96b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     970:	48 8d 50 01          	lea    0x1(%rax),%rdx
     974:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
     978:	49 39 d3             	cmp    %rdx,%r11
     97b:	75 28                	jne    9a5 <mi_page_queue_enqueue_from_ex.constprop.0+0x195>
     97d:	49 39 ec             	cmp    %rbp,%r12
     980:	73 23                	jae    9a5 <mi_page_queue_enqueue_from_ex.constprop.0+0x195>
     982:	48 83 ed 20          	sub    $0x20,%rbp
     986:	48 8b 45 18          	mov    0x18(%rbp),%rax
     98a:	48 8d 50 07          	lea    0x7(%rax),%rdx
     98e:	48 89 d0             	mov    %rdx,%rax
     991:	48 c1 e8 03          	shr    $0x3,%rax
     995:	48 83 fa 47          	cmp    $0x47,%rdx
     999:	0f 87 11 02 00 00    	ja     bb0 <mi_page_queue_enqueue_from_ex.constprop.0+0x3a0>
     99f:	48 83 f8 01          	cmp    $0x1,%rax
     9a3:	77 cb                	ja     970 <mi_page_queue_enqueue_from_ex.constprop.0+0x160>
     9a5:	48 83 c0 01          	add    $0x1,%rax
     9a9:	4c 39 c0             	cmp    %r8,%rax
     9ac:	49 0f 47 c0          	cmova  %r8,%rax
     9b0:	48 8d 50 01          	lea    0x1(%rax),%rdx
     9b4:	4c 89 d1             	mov    %r10,%rcx
     9b7:	41 bb 01 00 00 00    	mov    $0x1,%r11d
     9bd:	48 29 c1             	sub    %rax,%rcx
     9c0:	49 39 d2             	cmp    %rdx,%r10
     9c3:	49 0f 42 cb          	cmovb  %r11,%rcx
     9c7:	4c 39 c0             	cmp    %r8,%rax
     9ca:	74 48                	je     a14 <mi_page_queue_enqueue_from_ex.constprop.0+0x204>
     9cc:	49 39 d2             	cmp    %rdx,%r10
     9cf:	72 43                	jb     a14 <mi_page_queue_enqueue_from_ex.constprop.0+0x204>
     9d1:	49 89 c8             	mov    %rcx,%r8
     9d4:	49 8d 94 c5 18 01 00 	lea    0x118(%r13,%rax,8),%rdx
     9db:	00 
     9dc:	49 d1 e8             	shr    $1,%r8
     9df:	49 c1 e0 04          	shl    $0x4,%r8
     9e3:	4d 8d 14 10          	lea    (%r8,%rdx,1),%r10
     9e7:	41 83 e0 10          	and    $0x10,%r8d
     9eb:	0f 85 ef 01 00 00    	jne    be0 <mi_page_queue_enqueue_from_ex.constprop.0+0x3d0>
     9f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     9f8:	0f 11 02             	movups %xmm0,(%rdx)
     9fb:	48 83 c2 20          	add    $0x20,%rdx
     9ff:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
     a03:	4c 39 d2             	cmp    %r10,%rdx
     a06:	75 f0                	jne    9f8 <mi_page_queue_enqueue_from_ex.constprop.0+0x1e8>
     a08:	f6 c1 01             	test   $0x1,%cl
     a0b:	74 0b                	je     a18 <mi_page_queue_enqueue_from_ex.constprop.0+0x208>
     a0d:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     a11:	48 01 c8             	add    %rcx,%rax
     a14:	49 89 1c c1          	mov    %rbx,(%r9,%rax,8)
     a18:	48 8b 03             	mov    (%rbx),%rax
     a1b:	48 89 c1             	mov    %rax,%rcx
     a1e:	48 89 c2             	mov    %rax,%rdx
     a21:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     a25:	f0 48 0f b1 0b       	lock cmpxchg %rcx,(%rbx)
     a2a:	0f 84 86 fe ff ff    	je     8b6 <mi_page_queue_enqueue_from_ex.constprop.0+0xa6>
     a30:	eb e9                	jmp    a1b <mi_page_queue_enqueue_from_ex.constprop.0+0x20b>
     a32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     a38:	48 8b 53 50          	mov    0x50(%rbx),%rdx
     a3c:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
     a41:	49 3b 1c 24          	cmp    (%r12),%rbx
     a45:	0f 85 13 fe ff ff    	jne    85e <mi_page_queue_enqueue_from_ex.constprop.0+0x4e>
     a4b:	4d 8b 74 24 18       	mov    0x18(%r12),%r14
     a50:	49 89 04 24          	mov    %rax,(%r12)
     a54:	49 81 fe 00 04 00 00 	cmp    $0x400,%r14
     a5b:	0f 87 fd fd ff ff    	ja     85e <mi_page_queue_enqueue_from_ex.constprop.0+0x4e>
     a61:	48 85 c0             	test   %rax,%rax
     a64:	0f 84 ae 01 00 00    	je     c18 <mi_page_queue_enqueue_from_ex.constprop.0+0x408>
     a6a:	49 8d 7e 07          	lea    0x7(%r14),%rdi
     a6e:	4d 8d 85 18 01 00 00 	lea    0x118(%r13),%r8
     a75:	48 c1 ef 03          	shr    $0x3,%rdi
     a79:	49 39 84 fd 18 01 00 	cmp    %rax,0x118(%r13,%rdi,8)
     a80:	00 
     a81:	0f 84 d7 fd ff ff    	je     85e <mi_page_queue_enqueue_from_ex.constprop.0+0x4e>
     a87:	48 83 ff 01          	cmp    $0x1,%rdi
     a8b:	0f 86 67 01 00 00    	jbe    bf8 <mi_page_queue_enqueue_from_ex.constprop.0+0x3e8>
     a91:	48 83 ff 08          	cmp    $0x8,%rdi
     a95:	0f 87 a6 01 00 00    	ja     c41 <mi_page_queue_enqueue_from_ex.constprop.0+0x431>
     a9b:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     a9f:	4d 89 cb             	mov    %r9,%r11
     aa2:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
     aa6:	49 8d 74 24 e0       	lea    -0x20(%r12),%rsi
     aab:	4d 8d 95 20 05 00 00 	lea    0x520(%r13),%r10
     ab2:	eb 1a                	jmp    ace <mi_page_queue_enqueue_from_ex.constprop.0+0x2be>
     ab4:	0f 1f 40 00          	nopl   0x0(%rax)
     ab8:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
     abc:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     ac0:	49 39 cb             	cmp    %rcx,%r11
     ac3:	75 28                	jne    aed <mi_page_queue_enqueue_from_ex.constprop.0+0x2dd>
     ac5:	49 39 f2             	cmp    %rsi,%r10
     ac8:	73 23                	jae    aed <mi_page_queue_enqueue_from_ex.constprop.0+0x2dd>
     aca:	48 83 ee 20          	sub    $0x20,%rsi
     ace:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
     ad2:	48 83 c1 07          	add    $0x7,%rcx
     ad6:	48 89 ca             	mov    %rcx,%rdx
     ad9:	48 c1 ea 03          	shr    $0x3,%rdx
     add:	48 83 f9 47          	cmp    $0x47,%rcx
     ae1:	0f 87 99 00 00 00    	ja     b80 <mi_page_queue_enqueue_from_ex.constprop.0+0x370>
     ae7:	48 83 fa 01          	cmp    $0x1,%rdx
     aeb:	77 cb                	ja     ab8 <mi_page_queue_enqueue_from_ex.constprop.0+0x2a8>
     aed:	48 83 c2 01          	add    $0x1,%rdx
     af1:	48 39 fa             	cmp    %rdi,%rdx
     af4:	48 0f 47 d7          	cmova  %rdi,%rdx
     af8:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
     afc:	4c 89 ce             	mov    %r9,%rsi
     aff:	41 ba 01 00 00 00    	mov    $0x1,%r10d
     b05:	48 29 d6             	sub    %rdx,%rsi
     b08:	49 39 c9             	cmp    %rcx,%r9
     b0b:	49 0f 42 f2          	cmovb  %r10,%rsi
     b0f:	48 39 d7             	cmp    %rdx,%rdi
     b12:	74 5d                	je     b71 <mi_page_queue_enqueue_from_ex.constprop.0+0x361>
     b14:	49 39 c9             	cmp    %rcx,%r9
     b17:	72 58                	jb     b71 <mi_page_queue_enqueue_from_ex.constprop.0+0x361>
     b19:	48 89 f7             	mov    %rsi,%rdi
     b1c:	49 8d 8c d5 18 01 00 	lea    0x118(%r13,%rdx,8),%rcx
     b23:	00 
     b24:	66 48 0f 6e c0       	movq   %rax,%xmm0
     b29:	48 d1 ef             	shr    $1,%rdi
     b2c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
     b30:	48 c1 e7 04          	shl    $0x4,%rdi
     b34:	4c 8d 0c 0f          	lea    (%rdi,%rcx,1),%r9
     b38:	83 e7 10             	and    $0x10,%edi
     b3b:	74 13                	je     b50 <mi_page_queue_enqueue_from_ex.constprop.0+0x340>
     b3d:	0f 11 01             	movups %xmm0,(%rcx)
     b40:	48 83 c1 10          	add    $0x10,%rcx
     b44:	49 39 c9             	cmp    %rcx,%r9
     b47:	74 17                	je     b60 <mi_page_queue_enqueue_from_ex.constprop.0+0x350>
     b49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     b50:	0f 11 01             	movups %xmm0,(%rcx)
     b53:	48 83 c1 20          	add    $0x20,%rcx
     b57:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
     b5b:	49 39 c9             	cmp    %rcx,%r9
     b5e:	75 f0                	jne    b50 <mi_page_queue_enqueue_from_ex.constprop.0+0x340>
     b60:	40 f6 c6 01          	test   $0x1,%sil
     b64:	0f 84 f4 fc ff ff    	je     85e <mi_page_queue_enqueue_from_ex.constprop.0+0x4e>
     b6a:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
     b6e:	48 01 f2             	add    %rsi,%rdx
     b71:	49 89 04 d0          	mov    %rax,(%r8,%rdx,8)
     b75:	e9 e4 fc ff ff       	jmp    85e <mi_page_queue_enqueue_from_ex.constprop.0+0x4e>
     b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     b80:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
     b87:	0f 87 60 ff ff ff    	ja     aed <mi_page_queue_enqueue_from_ex.constprop.0+0x2dd>
     b8d:	4c 8d 72 ff          	lea    -0x1(%rdx),%r14
     b91:	4d 0f bd fe          	bsr    %r14,%r15
     b95:	41 8d 4f fe          	lea    -0x2(%r15),%ecx
     b99:	49 d3 ee             	shr    %cl,%r14
     b9c:	41 83 e6 03          	and    $0x3,%r14d
     ba0:	4b 8d 4c be fd       	lea    -0x3(%r14,%r15,4),%rcx
     ba5:	e9 16 ff ff ff       	jmp    ac0 <mi_page_queue_enqueue_from_ex.constprop.0+0x2b0>
     baa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     bb0:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
     bb6:	0f 87 e9 fd ff ff    	ja     9a5 <mi_page_queue_enqueue_from_ex.constprop.0+0x195>
     bbc:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
     bc0:	4c 0f bd f2          	bsr    %rdx,%r14
     bc4:	41 8d 4e fe          	lea    -0x2(%r14),%ecx
     bc8:	48 d3 ea             	shr    %cl,%rdx
     bcb:	83 e2 03             	and    $0x3,%edx
     bce:	4a 8d 54 b2 fd       	lea    -0x3(%rdx,%r14,4),%rdx
     bd3:	e9 a0 fd ff ff       	jmp    978 <mi_page_queue_enqueue_from_ex.constprop.0+0x168>
     bd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     bdf:	00 
     be0:	0f 11 02             	movups %xmm0,(%rdx)
     be3:	48 83 c2 10          	add    $0x10,%rdx
     be7:	4c 39 d2             	cmp    %r10,%rdx
     bea:	0f 85 08 fe ff ff    	jne    9f8 <mi_page_queue_enqueue_from_ex.constprop.0+0x1e8>
     bf0:	e9 13 fe ff ff       	jmp    a08 <mi_page_queue_enqueue_from_ex.constprop.0+0x1f8>
     bf5:	0f 1f 00             	nopl   (%rax)
     bf8:	31 d2                	xor    %edx,%edx
     bfa:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     bfe:	e9 f5 fe ff ff       	jmp    af8 <mi_page_queue_enqueue_from_ex.constprop.0+0x2e8>
     c03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     c08:	31 c0                	xor    %eax,%eax
     c0a:	4d 8d 50 01          	lea    0x1(%r8),%r10
     c0e:	e9 9d fd ff ff       	jmp    9b0 <mi_page_queue_enqueue_from_ex.constprop.0+0x1a0>
     c13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     c18:	e8 00 00 00 00       	call   c1d <mi_page_queue_enqueue_from_ex.constprop.0+0x40d>
			c19: R_X86_64_PLT32	_mi_page_empty_get-0x4
     c1d:	e9 48 fe ff ff       	jmp    a6a <mi_page_queue_enqueue_from_ex.constprop.0+0x25a>
     c22:	49 8d 40 ff          	lea    -0x1(%r8),%rax
     c26:	4d 8d 50 01          	lea    0x1(%r8),%r10
     c2a:	48 0f bd d0          	bsr    %rax,%rdx
     c2e:	8d 4a fe             	lea    -0x2(%rdx),%ecx
     c31:	48 d3 e8             	shr    %cl,%rax
     c34:	83 e0 03             	and    $0x3,%eax
     c37:	4c 8d 5c 90 fd       	lea    -0x3(%rax,%rdx,4),%r11
     c3c:	e9 1d fd ff ff       	jmp    95e <mi_page_queue_enqueue_from_ex.constprop.0+0x14e>
     c41:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
     c45:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     c49:	48 0f bd f2          	bsr    %rdx,%rsi
     c4d:	8d 4e fe             	lea    -0x2(%rsi),%ecx
     c50:	48 d3 ea             	shr    %cl,%rdx
     c53:	83 e2 03             	and    $0x3,%edx
     c56:	4c 8d 5c b2 fd       	lea    -0x3(%rdx,%rsi,4),%r11
     c5b:	e9 46 fe ff ff       	jmp    aa6 <mi_page_queue_enqueue_from_ex.constprop.0+0x296>

0000000000000c60 <_mi_bin>:
     c60:	48 83 c7 07          	add    $0x7,%rdi
     c64:	48 89 fa             	mov    %rdi,%rdx
     c67:	48 c1 ea 03          	shr    $0x3,%rdx
     c6b:	48 83 ff 47          	cmp    $0x47,%rdi
     c6f:	77 1f                	ja     c90 <_mi_bin+0x30>
     c71:	48 8d 42 01          	lea    0x1(%rdx),%rax
     c75:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
     c79:	48 83 fa 01          	cmp    $0x1,%rdx
     c7d:	ba 01 00 00 00       	mov    $0x1,%edx
     c82:	48 0f 46 c2          	cmovbe %rdx,%rax
     c86:	c3                   	ret
     c87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     c8e:	00 00 
     c90:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
     c97:	77 17                	ja     cb0 <_mi_bin+0x50>
     c99:	48 83 ea 01          	sub    $0x1,%rdx
     c9d:	48 0f bd c2          	bsr    %rdx,%rax
     ca1:	8d 48 fe             	lea    -0x2(%rax),%ecx
     ca4:	48 d3 ea             	shr    %cl,%rdx
     ca7:	83 e2 03             	and    $0x3,%edx
     caa:	48 8d 44 82 fd       	lea    -0x3(%rdx,%rax,4),%rax
     caf:	c3                   	ret
     cb0:	b8 49 00 00 00       	mov    $0x49,%eax
     cb5:	c3                   	ret
     cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
     cbd:	00 00 00 

0000000000000cc0 <_mi_bin_size>:
     cc0:	48 c1 e7 05          	shl    $0x5,%rdi
     cc4:	48 8d 05 00 00 00 00 	lea    0x0(%rip),%rax        # ccb <_mi_bin_size+0xb>
			cc7: R_X86_64_PC32	_mi_theap_empty-0x4
     ccb:	48 8b 84 38 38 05 00 	mov    0x538(%rax,%rdi,1),%rax
     cd2:	00 
     cd3:	c3                   	ret
     cd4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     cdb:	00 00 00 00 
     cdf:	90                   	nop

0000000000000ce0 <mi_good_size>:
     ce0:	53                   	push   %rbx
     ce1:	48 89 fb             	mov    %rdi,%rbx
     ce4:	48 81 ff 00 00 08 00 	cmp    $0x80000,%rdi
     ceb:	76 33                	jbe    d20 <mi_good_size+0x40>
     ced:	48 85 ff             	test   %rdi,%rdi
     cf0:	79 0e                	jns    d00 <mi_good_size+0x20>
     cf2:	48 89 d8             	mov    %rbx,%rax
     cf5:	5b                   	pop    %rbx
     cf6:	c3                   	ret
     cf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     cfe:	00 00 
     d00:	e8 00 00 00 00       	call   d05 <mi_good_size+0x25>
			d01: R_X86_64_PLT32	_mi_os_page_size-0x4
     d05:	48 89 c1             	mov    %rax,%rcx
     d08:	48 8d 40 ff          	lea    -0x1(%rax),%rax
     d0c:	48 01 c3             	add    %rax,%rbx
     d0f:	48 85 c1             	test   %rax,%rcx
     d12:	75 4c                	jne    d60 <mi_good_size+0x80>
     d14:	48 f7 d9             	neg    %rcx
     d17:	48 21 cb             	and    %rcx,%rbx
     d1a:	48 89 d8             	mov    %rbx,%rax
     d1d:	5b                   	pop    %rbx
     d1e:	c3                   	ret
     d1f:	90                   	nop
     d20:	48 83 c3 07          	add    $0x7,%rbx
     d24:	48 89 da             	mov    %rbx,%rdx
     d27:	48 c1 ea 03          	shr    $0x3,%rdx
     d2b:	48 83 fb 47          	cmp    $0x47,%rbx
     d2f:	77 3f                	ja     d70 <mi_good_size+0x90>
     d31:	48 8d 42 01          	lea    0x1(%rdx),%rax
     d35:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
     d39:	48 83 fa 01          	cmp    $0x1,%rdx
     d3d:	ba 01 00 00 00       	mov    $0x1,%edx
     d42:	48 0f 46 c2          	cmovbe %rdx,%rax
     d46:	48 c1 e0 05          	shl    $0x5,%rax
     d4a:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # d51 <mi_good_size+0x71>
			d4d: R_X86_64_PC32	_mi_theap_empty-0x4
     d51:	48 8b 9c 02 38 05 00 	mov    0x538(%rdx,%rax,1),%rbx
     d58:	00 
     d59:	48 89 d8             	mov    %rbx,%rax
     d5c:	5b                   	pop    %rbx
     d5d:	c3                   	ret
     d5e:	66 90                	xchg   %ax,%ax
     d60:	48 89 d8             	mov    %rbx,%rax
     d63:	31 d2                	xor    %edx,%edx
     d65:	48 f7 f1             	div    %rcx
     d68:	48 29 d3             	sub    %rdx,%rbx
     d6b:	48 89 d8             	mov    %rbx,%rax
     d6e:	5b                   	pop    %rbx
     d6f:	c3                   	ret
     d70:	48 83 ea 01          	sub    $0x1,%rdx
     d74:	48 0f bd c2          	bsr    %rdx,%rax
     d78:	8d 48 fe             	lea    -0x2(%rax),%ecx
     d7b:	48 d3 ea             	shr    %cl,%rdx
     d7e:	83 e2 03             	and    $0x3,%edx
     d81:	48 8d 44 82 fd       	lea    -0x3(%rdx,%rax,4),%rax
     d86:	eb be                	jmp    d46 <mi_good_size+0x66>
     d88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     d8f:	00 

0000000000000d90 <_mi_page_queue_is_valid>:
     d90:	48 85 f6             	test   %rsi,%rsi
     d93:	74 23                	je     db8 <_mi_page_queue_is_valid+0x28>
     d95:	48 8b 06             	mov    (%rsi),%rax
     d98:	48 85 c0             	test   %rax,%rax
     d9b:	74 0f                	je     dac <_mi_page_queue_is_valid+0x1c>
     d9d:	0f 1f 00             	nopl   (%rax)
     da0:	48 8b 10             	mov    (%rax),%rdx
     da3:	48 8b 40 48          	mov    0x48(%rax),%rax
     da7:	48 85 c0             	test   %rax,%rax
     daa:	75 f4                	jne    da0 <_mi_page_queue_is_valid+0x10>
     dac:	b8 01 00 00 00       	mov    $0x1,%eax
     db1:	c3                   	ret
     db2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     db8:	31 c0                	xor    %eax,%eax
     dba:	c3                   	ret
     dbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000000dc0 <_mi_page_stats_bin>:
     dc0:	66 83 7f 36 01       	cmpw   $0x1,0x36(%rdi)
     dc5:	48 8b 57 28          	mov    0x28(%rdi),%rdx
     dc9:	74 2d                	je     df8 <_mi_page_stats_bin+0x38>
     dcb:	48 83 c2 07          	add    $0x7,%rdx
     dcf:	48 89 d1             	mov    %rdx,%rcx
     dd2:	48 c1 e9 03          	shr    $0x3,%rcx
     dd6:	48 83 fa 47          	cmp    $0x47,%rdx
     dda:	77 74                	ja     e50 <_mi_page_stats_bin+0x90>
     ddc:	48 8d 41 01          	lea    0x1(%rcx),%rax
     de0:	ba 01 00 00 00       	mov    $0x1,%edx
     de5:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
     de9:	48 83 f9 01          	cmp    $0x1,%rcx
     ded:	48 0f 46 c2          	cmovbe %rdx,%rax
     df1:	c3                   	ret
     df2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     df8:	b8 49 00 00 00       	mov    $0x49,%eax
     dfd:	48 81 fa 00 00 08 00 	cmp    $0x80000,%rdx
     e04:	77 11                	ja     e17 <_mi_page_stats_bin+0x57>
     e06:	8b 77 68             	mov    0x68(%rdi),%esi
     e09:	8d 4e fd             	lea    -0x3(%rsi),%ecx
     e0c:	83 f9 02             	cmp    $0x2,%ecx
     e0f:	77 0f                	ja     e20 <_mi_page_stats_bin+0x60>
     e11:	48 39 7f 58          	cmp    %rdi,0x58(%rdi)
     e15:	73 09                	jae    e20 <_mi_page_stats_bin+0x60>
     e17:	c3                   	ret
     e18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     e1f:	00 
     e20:	48 83 c2 07          	add    $0x7,%rdx
     e24:	48 89 d1             	mov    %rdx,%rcx
     e27:	48 c1 e9 03          	shr    $0x3,%rcx
     e2b:	48 83 fa 47          	cmp    $0x47,%rdx
     e2f:	76 ab                	jbe    ddc <_mi_page_stats_bin+0x1c>
     e31:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
     e35:	48 0f bd d0          	bsr    %rax,%rdx
     e39:	8d 4a fe             	lea    -0x2(%rdx),%ecx
     e3c:	48 d3 e8             	shr    %cl,%rax
     e3f:	48 89 c1             	mov    %rax,%rcx
     e42:	83 e1 03             	and    $0x3,%ecx
     e45:	48 8d 44 91 fd       	lea    -0x3(%rcx,%rdx,4),%rax
     e4a:	c3                   	ret
     e4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     e50:	48 81 f9 00 00 01 00 	cmp    $0x10000,%rcx
     e57:	76 d8                	jbe    e31 <_mi_page_stats_bin+0x71>
     e59:	b8 49 00 00 00       	mov    $0x49,%eax
     e5e:	c3                   	ret
     e5f:	90                   	nop

0000000000000e60 <_mi_page_free_collect>:
     e60:	55                   	push   %rbp
     e61:	89 f5                	mov    %esi,%ebp
     e63:	48 8d 77 20          	lea    0x20(%rdi),%rsi
     e67:	53                   	push   %rbx
     e68:	48 89 fb             	mov    %rdi,%rbx
     e6b:	48 83 ec 08          	sub    $0x8,%rsp
     e6f:	48 8b 07             	mov    (%rdi),%rax
     e72:	48 8b 57 20          	mov    0x20(%rdi),%rdx
     e76:	48 83 fa 01          	cmp    $0x1,%rdx
     e7a:	77 74                	ja     ef0 <_mi_page_free_collect+0x90>
     e7c:	48 8b 43 18          	mov    0x18(%rbx),%rax
     e80:	48 8b 53 08          	mov    0x8(%rbx),%rdx
     e84:	48 85 c0             	test   %rax,%rax
     e87:	74 27                	je     eb0 <_mi_page_free_collect+0x50>
     e89:	48 85 d2             	test   %rdx,%rdx
     e8c:	0f 85 c6 00 00 00    	jne    f58 <_mi_page_free_collect+0xf8>
     e92:	48 89 43 08          	mov    %rax,0x8(%rbx)
     e96:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
     e9d:	00 
     e9e:	c6 43 17 00          	movb   $0x0,0x17(%rbx)
     ea2:	48 83 c4 08          	add    $0x8,%rsp
     ea6:	5b                   	pop    %rbx
     ea7:	5d                   	pop    %rbp
     ea8:	c3                   	ret
     ea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     eb0:	48 85 d2             	test   %rdx,%rdx
     eb3:	75 ed                	jne    ea2 <_mi_page_free_collect+0x42>
     eb5:	48 83 7b 70 00       	cmpq   $0x0,0x70(%rbx)
     eba:	75 1b                	jne    ed7 <_mi_page_free_collect+0x77>
     ebc:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
     ec1:	75 14                	jne    ed7 <_mi_page_free_collect+0x77>
     ec3:	48 83 bb 80 00 00 00 	cmpq   $0x0,0x80(%rbx)
     eca:	00 
     ecb:	75 0a                	jne    ed7 <_mi_page_free_collect+0x77>
     ecd:	48 83 bb 88 00 00 00 	cmpq   $0x0,0x88(%rbx)
     ed4:	00 
     ed5:	74 cb                	je     ea2 <_mi_page_free_collect+0x42>
     ed7:	e8 00 00 00 00       	call   edc <_mi_page_free_collect+0x7c>
			ed8: R_X86_64_PLT32	_mi_page_purge_holes_in_progress-0x4
     edc:	84 c0                	test   %al,%al
     ede:	75 c2                	jne    ea2 <_mi_page_free_collect+0x42>
     ee0:	48 83 c4 08          	add    $0x8,%rsp
     ee4:	48 89 df             	mov    %rbx,%rdi
     ee7:	5b                   	pop    %rbx
     ee8:	5d                   	pop    %rbp
     ee9:	e9 00 00 00 00       	jmp    eee <_mi_page_free_collect+0x8e>
			eea: R_X86_64_PLT32	_mi_page_unpurge_run-0x4
     eee:	66 90                	xchg   %ax,%ax
     ef0:	48 89 d1             	mov    %rdx,%rcx
     ef3:	48 89 d0             	mov    %rdx,%rax
     ef6:	83 e1 01             	and    $0x1,%ecx
     ef9:	f0 48 0f b1 0e       	lock cmpxchg %rcx,(%rsi)
     efe:	0f 94 c1             	sete   %cl
     f01:	0f b6 c9             	movzbl %cl,%ecx
     f04:	0f 85 b5 00 00 00    	jne    fbf <_mi_page_free_collect+0x15f>
     f0a:	48 89 d0             	mov    %rdx,%rax
     f0d:	0f b7 73 14          	movzwl 0x14(%rbx),%esi
     f11:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
     f15:	48 8b 10             	mov    (%rax),%rdx
     f18:	48 85 d2             	test   %rdx,%rdx
     f1b:	74 5e                	je     f7b <_mi_page_free_collect+0x11b>
     f1d:	48 85 f6             	test   %rsi,%rsi
     f20:	75 0b                	jne    f2d <_mi_page_free_collect+0xcd>
     f22:	eb 57                	jmp    f7b <_mi_page_free_collect+0x11b>
     f24:	0f 1f 40 00          	nopl   0x0(%rax)
     f28:	48 85 d2             	test   %rdx,%rdx
     f2b:	74 51                	je     f7e <_mi_page_free_collect+0x11e>
     f2d:	48 83 c1 01          	add    $0x1,%rcx
     f31:	48 89 d7             	mov    %rdx,%rdi
     f34:	48 8b 12             	mov    (%rdx),%rdx
     f37:	48 39 ce             	cmp    %rcx,%rsi
     f3a:	73 ec                	jae    f28 <_mi_page_free_collect+0xc8>
     f3c:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # f43 <_mi_page_free_collect+0xe3>
			f3f: R_X86_64_PC32	.LC0-0x4
     f43:	bf 0e 00 00 00       	mov    $0xe,%edi
     f48:	31 c0                	xor    %eax,%eax
     f4a:	e8 00 00 00 00       	call   f4f <_mi_page_free_collect+0xef>
			f4b: R_X86_64_PLT32	_mi_error_message-0x4
     f4f:	e9 28 ff ff ff       	jmp    e7c <_mi_page_free_collect+0x1c>
     f54:	0f 1f 40 00          	nopl   0x0(%rax)
     f58:	40 84 ed             	test   %bpl,%bpl
     f5b:	0f 84 41 ff ff ff    	je     ea2 <_mi_page_free_collect+0x42>
     f61:	48 89 c1             	mov    %rax,%rcx
     f64:	0f 1f 40 00          	nopl   0x0(%rax)
     f68:	48 89 ce             	mov    %rcx,%rsi
     f6b:	48 8b 09             	mov    (%rcx),%rcx
     f6e:	48 85 c9             	test   %rcx,%rcx
     f71:	75 f5                	jne    f68 <_mi_page_free_collect+0x108>
     f73:	48 89 16             	mov    %rdx,(%rsi)
     f76:	e9 17 ff ff ff       	jmp    e92 <_mi_page_free_collect+0x32>
     f7b:	48 89 c7             	mov    %rax,%rdi
     f7e:	48 39 ce             	cmp    %rcx,%rsi
     f81:	72 b9                	jb     f3c <_mi_page_free_collect+0xdc>
     f83:	8b 73 10             	mov    0x10(%rbx),%esi
     f86:	48 89 f2             	mov    %rsi,%rdx
     f89:	48 39 ce             	cmp    %rcx,%rsi
     f8c:	72 19                	jb     fa7 <_mi_page_free_collect+0x147>
     f8e:	48 8b 73 18          	mov    0x18(%rbx),%rsi
     f92:	29 ca                	sub    %ecx,%edx
     f94:	48 89 37             	mov    %rsi,(%rdi)
     f97:	89 53 10             	mov    %edx,0x10(%rbx)
     f9a:	48 8b 53 08          	mov    0x8(%rbx),%rdx
     f9e:	48 89 43 18          	mov    %rax,0x18(%rbx)
     fa2:	e9 e2 fe ff ff       	jmp    e89 <_mi_page_free_collect+0x29>
     fa7:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # fae <_mi_page_free_collect+0x14e>
			faa: R_X86_64_PC32	.LC1-0x4
     fae:	bf 0e 00 00 00       	mov    $0xe,%edi
     fb3:	31 c0                	xor    %eax,%eax
     fb5:	e8 00 00 00 00       	call   fba <_mi_page_free_collect+0x15a>
			fb6: R_X86_64_PLT32	_mi_error_message-0x4
     fba:	e9 bd fe ff ff       	jmp    e7c <_mi_page_free_collect+0x1c>
     fbf:	48 89 c2             	mov    %rax,%rdx
     fc2:	e9 af fe ff ff       	jmp    e76 <_mi_page_free_collect+0x16>
     fc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     fce:	00 00 

0000000000000fd0 <_mi_page_free_collect_no_unpurge>:
     fd0:	41 54                	push   %r12
     fd2:	55                   	push   %rbp
     fd3:	89 f5                	mov    %esi,%ebp
     fd5:	53                   	push   %rbx
     fd6:	48 8b 07             	mov    (%rdi),%rax
     fd9:	48 89 fb             	mov    %rdi,%rbx
     fdc:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
     fe0:	48 83 f8 04          	cmp    $0x4,%rax
     fe4:	76 42                	jbe    1028 <_mi_page_free_collect_no_unpurge+0x58>
     fe6:	48 8b 47 38          	mov    0x38(%rdi),%rax
     fea:	48 85 c0             	test   %rax,%rax
     fed:	74 30                	je     101f <_mi_page_free_collect_no_unpurge+0x4f>
     fef:	48 8b 50 08          	mov    0x8(%rax),%rdx
     ff3:	48 85 d2             	test   %rdx,%rdx
     ff6:	74 30                	je     1028 <_mi_page_free_collect_no_unpurge+0x58>
     ff8:	4c 8b 20             	mov    (%rax),%r12
     ffb:	4d 85 e4             	test   %r12,%r12
     ffe:	74 1f                	je     101f <_mi_page_free_collect_no_unpurge+0x4f>
    1000:	49 83 3c 24 08       	cmpq   $0x8,(%r12)
    1005:	74 21                	je     1028 <_mi_page_free_collect_no_unpurge+0x58>
    1007:	e8 00 00 00 00       	call   100c <_mi_page_free_collect_no_unpurge+0x3c>
			1008: R_X86_64_PLT32	_mi_thread_id-0x4
    100c:	49 3b 04 24          	cmp    (%r12),%rax
    1010:	74 16                	je     1028 <_mi_page_free_collect_no_unpurge+0x58>
    1012:	49 8b 94 24 48 01 00 	mov    0x148(%r12),%rdx
    1019:	00 
    101a:	48 39 d0             	cmp    %rdx,%rax
    101d:	74 09                	je     1028 <_mi_page_free_collect_no_unpurge+0x58>
    101f:	5b                   	pop    %rbx
    1020:	5d                   	pop    %rbp
    1021:	41 5c                	pop    %r12
    1023:	c3                   	ret
    1024:	0f 1f 40 00          	nopl   0x0(%rax)
    1028:	48 8b 03             	mov    (%rbx),%rax
    102b:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    102f:	48 8d 73 20          	lea    0x20(%rbx),%rsi
    1033:	48 83 fa 01          	cmp    $0x1,%rdx
    1037:	77 27                	ja     1060 <_mi_page_free_collect_no_unpurge+0x90>
    1039:	48 8b 43 18          	mov    0x18(%rbx),%rax
    103d:	48 85 c0             	test   %rax,%rax
    1040:	74 dd                	je     101f <_mi_page_free_collect_no_unpurge+0x4f>
    1042:	48 8b 53 08          	mov    0x8(%rbx),%rdx
    1046:	48 85 d2             	test   %rdx,%rdx
    1049:	75 7d                	jne    10c8 <_mi_page_free_collect_no_unpurge+0xf8>
    104b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    104f:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    1056:	00 
    1057:	c6 43 17 00          	movb   $0x0,0x17(%rbx)
    105b:	5b                   	pop    %rbx
    105c:	5d                   	pop    %rbp
    105d:	41 5c                	pop    %r12
    105f:	c3                   	ret
    1060:	48 89 d1             	mov    %rdx,%rcx
    1063:	48 89 d0             	mov    %rdx,%rax
    1066:	83 e1 01             	and    $0x1,%ecx
    1069:	f0 48 0f b1 0e       	lock cmpxchg %rcx,(%rsi)
    106e:	0f 94 c1             	sete   %cl
    1071:	0f b6 c9             	movzbl %cl,%ecx
    1074:	0f 85 b1 00 00 00    	jne    112b <_mi_page_free_collect_no_unpurge+0x15b>
    107a:	48 89 d0             	mov    %rdx,%rax
    107d:	0f b7 73 14          	movzwl 0x14(%rbx),%esi
    1081:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    1085:	48 8b 10             	mov    (%rax),%rdx
    1088:	48 85 f6             	test   %rsi,%rsi
    108b:	74 5e                	je     10eb <_mi_page_free_collect_no_unpurge+0x11b>
    108d:	48 85 d2             	test   %rdx,%rdx
    1090:	75 0b                	jne    109d <_mi_page_free_collect_no_unpurge+0xcd>
    1092:	eb 57                	jmp    10eb <_mi_page_free_collect_no_unpurge+0x11b>
    1094:	0f 1f 40 00          	nopl   0x0(%rax)
    1098:	48 85 d2             	test   %rdx,%rdx
    109b:	74 51                	je     10ee <_mi_page_free_collect_no_unpurge+0x11e>
    109d:	48 83 c1 01          	add    $0x1,%rcx
    10a1:	48 89 d7             	mov    %rdx,%rdi
    10a4:	48 8b 12             	mov    (%rdx),%rdx
    10a7:	48 39 ce             	cmp    %rcx,%rsi
    10aa:	73 ec                	jae    1098 <_mi_page_free_collect_no_unpurge+0xc8>
    10ac:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 10b3 <_mi_page_free_collect_no_unpurge+0xe3>
			10af: R_X86_64_PC32	.LC0-0x4
    10b3:	bf 0e 00 00 00       	mov    $0xe,%edi
    10b8:	31 c0                	xor    %eax,%eax
    10ba:	e8 00 00 00 00       	call   10bf <_mi_page_free_collect_no_unpurge+0xef>
			10bb: R_X86_64_PLT32	_mi_error_message-0x4
    10bf:	e9 75 ff ff ff       	jmp    1039 <_mi_page_free_collect_no_unpurge+0x69>
    10c4:	0f 1f 40 00          	nopl   0x0(%rax)
    10c8:	40 84 ed             	test   %bpl,%bpl
    10cb:	0f 84 4e ff ff ff    	je     101f <_mi_page_free_collect_no_unpurge+0x4f>
    10d1:	48 89 c1             	mov    %rax,%rcx
    10d4:	0f 1f 40 00          	nopl   0x0(%rax)
    10d8:	48 89 ce             	mov    %rcx,%rsi
    10db:	48 8b 09             	mov    (%rcx),%rcx
    10de:	48 85 c9             	test   %rcx,%rcx
    10e1:	75 f5                	jne    10d8 <_mi_page_free_collect_no_unpurge+0x108>
    10e3:	48 89 16             	mov    %rdx,(%rsi)
    10e6:	e9 60 ff ff ff       	jmp    104b <_mi_page_free_collect_no_unpurge+0x7b>
    10eb:	48 89 c7             	mov    %rax,%rdi
    10ee:	48 39 ce             	cmp    %rcx,%rsi
    10f1:	72 b9                	jb     10ac <_mi_page_free_collect_no_unpurge+0xdc>
    10f3:	8b 73 10             	mov    0x10(%rbx),%esi
    10f6:	48 89 f2             	mov    %rsi,%rdx
    10f9:	48 39 ce             	cmp    %rcx,%rsi
    10fc:	72 15                	jb     1113 <_mi_page_free_collect_no_unpurge+0x143>
    10fe:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    1102:	29 ca                	sub    %ecx,%edx
    1104:	48 89 37             	mov    %rsi,(%rdi)
    1107:	48 89 43 18          	mov    %rax,0x18(%rbx)
    110b:	89 53 10             	mov    %edx,0x10(%rbx)
    110e:	e9 2f ff ff ff       	jmp    1042 <_mi_page_free_collect_no_unpurge+0x72>
    1113:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 111a <_mi_page_free_collect_no_unpurge+0x14a>
			1116: R_X86_64_PC32	.LC1-0x4
    111a:	bf 0e 00 00 00       	mov    $0xe,%edi
    111f:	31 c0                	xor    %eax,%eax
    1121:	e8 00 00 00 00       	call   1126 <_mi_page_free_collect_no_unpurge+0x156>
			1122: R_X86_64_PLT32	_mi_error_message-0x4
    1126:	e9 0e ff ff ff       	jmp    1039 <_mi_page_free_collect_no_unpurge+0x69>
    112b:	48 89 c2             	mov    %rax,%rdx
    112e:	e9 00 ff ff ff       	jmp    1033 <_mi_page_free_collect_no_unpurge+0x63>
    1133:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    113a:	00 00 00 00 
    113e:	66 90                	xchg   %ax,%ax

0000000000001140 <_mi_page_free_collect_partly>:
    1140:	48 85 f6             	test   %rsi,%rsi
    1143:	0f 84 87 00 00 00    	je     11d0 <_mi_page_free_collect_partly+0x90>
    1149:	53                   	push   %rbx
    114a:	48 89 fb             	mov    %rdi,%rbx
    114d:	48 8b 3e             	mov    (%rsi),%rdi
    1150:	48 85 ff             	test   %rdi,%rdi
    1153:	75 0b                	jne    1160 <_mi_page_free_collect_partly+0x20>
    1155:	83 7b 10 01          	cmpl   $0x1,0x10(%rbx)
    1159:	74 65                	je     11c0 <_mi_page_free_collect_partly+0x80>
    115b:	5b                   	pop    %rbx
    115c:	c3                   	ret
    115d:	0f 1f 00             	nopl   (%rax)
    1160:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
    1167:	48 8b 07             	mov    (%rdi),%rax
    116a:	49 89 f8             	mov    %rdi,%r8
    116d:	0f b7 4b 14          	movzwl 0x14(%rbx),%ecx
    1171:	48 85 c0             	test   %rax,%rax
    1174:	74 62                	je     11d8 <_mi_page_free_collect_partly+0x98>
    1176:	48 85 c9             	test   %rcx,%rcx
    1179:	74 5d                	je     11d8 <_mi_page_free_collect_partly+0x98>
    117b:	ba 01 00 00 00       	mov    $0x1,%edx
    1180:	eb 0b                	jmp    118d <_mi_page_free_collect_partly+0x4d>
    1182:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1188:	48 85 c0             	test   %rax,%rax
    118b:	74 53                	je     11e0 <_mi_page_free_collect_partly+0xa0>
    118d:	48 83 c2 01          	add    $0x1,%rdx
    1191:	48 89 c6             	mov    %rax,%rsi
    1194:	48 8b 00             	mov    (%rax),%rax
    1197:	48 39 d1             	cmp    %rdx,%rcx
    119a:	73 ec                	jae    1188 <_mi_page_free_collect_partly+0x48>
    119c:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 11a3 <_mi_page_free_collect_partly+0x63>
			119f: R_X86_64_PC32	.LC0-0x4
    11a3:	bf 0e 00 00 00       	mov    $0xe,%edi
    11a8:	31 c0                	xor    %eax,%eax
    11aa:	e8 00 00 00 00       	call   11af <_mi_page_free_collect_partly+0x6f>
			11ab: R_X86_64_PLT32	_mi_error_message-0x4
    11af:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    11b3:	4d 85 c0             	test   %r8,%r8
    11b6:	74 9d                	je     1155 <_mi_page_free_collect_partly+0x15>
    11b8:	eb 46                	jmp    1200 <_mi_page_free_collect_partly+0xc0>
    11ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    11c0:	48 89 df             	mov    %rbx,%rdi
    11c3:	31 f6                	xor    %esi,%esi
    11c5:	5b                   	pop    %rbx
    11c6:	e9 55 f0 ff ff       	jmp    220 <mi_page_free_collect_ex.constprop.0>
    11cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    11d0:	c3                   	ret
    11d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    11d8:	48 89 fe             	mov    %rdi,%rsi
    11db:	ba 01 00 00 00       	mov    $0x1,%edx
    11e0:	48 39 d1             	cmp    %rdx,%rcx
    11e3:	72 b7                	jb     119c <_mi_page_free_collect_partly+0x5c>
    11e5:	8b 4b 10             	mov    0x10(%rbx),%ecx
    11e8:	48 89 c8             	mov    %rcx,%rax
    11eb:	48 39 d1             	cmp    %rdx,%rcx
    11ee:	72 30                	jb     1220 <_mi_page_free_collect_partly+0xe0>
    11f0:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    11f4:	29 d0                	sub    %edx,%eax
    11f6:	48 89 0e             	mov    %rcx,(%rsi)
    11f9:	48 89 7b 18          	mov    %rdi,0x18(%rbx)
    11fd:	89 43 10             	mov    %eax,0x10(%rbx)
    1200:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    1205:	0f 85 4a ff ff ff    	jne    1155 <_mi_page_free_collect_partly+0x15>
    120b:	4c 89 43 08          	mov    %r8,0x8(%rbx)
    120f:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    1216:	00 
    1217:	c6 43 17 00          	movb   $0x0,0x17(%rbx)
    121b:	e9 35 ff ff ff       	jmp    1155 <_mi_page_free_collect_partly+0x15>
    1220:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 1227 <_mi_page_free_collect_partly+0xe7>
			1223: R_X86_64_PC32	.LC1-0x4
    1227:	bf 0e 00 00 00       	mov    $0xe,%edi
    122c:	31 c0                	xor    %eax,%eax
    122e:	e8 00 00 00 00       	call   1233 <_mi_page_free_collect_partly+0xf3>
			122f: R_X86_64_PLT32	_mi_error_message-0x4
    1233:	e9 77 ff ff ff       	jmp    11af <_mi_page_free_collect_partly+0x6f>
    1238:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    123f:	00 

0000000000001240 <_mi_theap_page_reclaim>:
    1240:	41 54                	push   %r12
    1242:	31 c9                	xor    %ecx,%ecx
    1244:	55                   	push   %rbp
    1245:	48 89 fd             	mov    %rdi,%rbp
    1248:	53                   	push   %rbx
    1249:	48 89 f3             	mov    %rsi,%rbx
    124c:	48 89 7e 38          	mov    %rdi,0x38(%rsi)
    1250:	48 85 ff             	test   %rdi,%rdi
    1253:	74 06                	je     125b <_mi_theap_page_reclaim+0x1b>
    1255:	48 8b 07             	mov    (%rdi),%rax
    1258:	48 8b 08             	mov    (%rax),%rcx
    125b:	48 8b 03             	mov    (%rbx),%rax
    125e:	48 89 c2             	mov    %rax,%rdx
    1261:	83 e2 03             	and    $0x3,%edx
    1264:	48 09 ca             	or     %rcx,%rdx
    1267:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    126c:	41 0f 94 c4          	sete   %r12b
    1270:	45 0f b6 e4          	movzbl %r12b,%r12d
    1274:	4d 85 e4             	test   %r12,%r12
    1277:	74 e5                	je     125e <_mi_theap_page_reclaim+0x1e>
    1279:	31 f6                	xor    %esi,%esi
    127b:	48 89 df             	mov    %rbx,%rdi
    127e:	e8 9d ef ff ff       	call   220 <mi_page_free_collect_ex.constprop.0>
    1283:	48 8b 03             	mov    (%rbx),%rax
    1286:	a8 01                	test   $0x1,%al
    1288:	0f 85 62 01 00 00    	jne    13f0 <_mi_theap_page_reclaim+0x1b0>
    128e:	66 83 7b 36 01       	cmpw   $0x1,0x36(%rbx)
    1293:	48 8b 43 28          	mov    0x28(%rbx),%rax
    1297:	0f 84 fb 00 00 00    	je     1398 <_mi_theap_page_reclaim+0x158>
    129d:	48 83 c0 07          	add    $0x7,%rax
    12a1:	48 89 c2             	mov    %rax,%rdx
    12a4:	48 c1 ea 03          	shr    $0x3,%rdx
    12a8:	48 83 f8 47          	cmp    $0x47,%rax
    12ac:	0f 87 16 03 00 00    	ja     15c8 <_mi_theap_page_reclaim+0x388>
    12b2:	be 40 05 00 00       	mov    $0x540,%esi
    12b7:	48 83 fa 01          	cmp    $0x1,%rdx
    12bb:	76 13                	jbe    12d0 <_mi_theap_page_reclaim+0x90>
    12bd:	48 83 c2 01          	add    $0x1,%rdx
    12c1:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    12c5:	48 8d 72 29          	lea    0x29(%rdx),%rsi
    12c9:	49 89 d4             	mov    %rdx,%r12
    12cc:	48 c1 e6 05          	shl    $0x5,%rsi
    12d0:	4c 89 e0             	mov    %r12,%rax
    12d3:	48 c1 e0 05          	shl    $0x5,%rax
    12d7:	48 8b 8c 05 38 05 00 	mov    0x538(%rbp,%rax,1),%rcx
    12de:	00 
    12df:	48 8b 03             	mov    (%rbx),%rax
    12e2:	48 81 f9 10 00 08 00 	cmp    $0x80010,%rcx
    12e9:	41 0f 94 c0          	sete   %r8b
    12ed:	0f 85 dd 00 00 00    	jne    13d0 <_mi_theap_page_reclaim+0x190>
    12f3:	48 89 c7             	mov    %rax,%rdi
    12f6:	48 89 c2             	mov    %rax,%rdx
    12f9:	48 83 cf 01          	or     $0x1,%rdi
    12fd:	f0 48 0f b1 3b       	lock cmpxchg %rdi,(%rbx)
    1302:	75 ef                	jne    12f3 <_mi_theap_page_reclaim+0xb3>
    1304:	83 e2 01             	and    $0x1,%edx
    1307:	41 38 d0             	cmp    %dl,%r8b
    130a:	74 34                	je     1340 <_mi_theap_page_reclaim+0x100>
    130c:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    1310:	48 85 d2             	test   %rdx,%rdx
    1313:	74 2b                	je     1340 <_mi_theap_page_reclaim+0x100>
    1315:	48 8b ba d0 00 00 00 	mov    0xd0(%rdx),%rdi
    131c:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
    1320:	48 0f af 43 28       	imul   0x28(%rbx),%rax
    1325:	49 89 f8             	mov    %rdi,%r8
    1328:	49 29 c0             	sub    %rax,%r8
    132b:	48 01 f8             	add    %rdi,%rax
    132e:	48 81 f9 10 00 08 00 	cmp    $0x80010,%rcx
    1335:	49 0f 45 c0          	cmovne %r8,%rax
    1339:	48 89 82 d0 00 00 00 	mov    %rax,0xd0(%rdx)
    1340:	4c 89 e0             	mov    %r12,%rax
    1343:	48 c1 e0 05          	shl    $0x5,%rax
    1347:	48 01 e8             	add    %rbp,%rax
    134a:	48 8b 90 28 05 00 00 	mov    0x528(%rax),%rdx
    1351:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
    1358:	00 
    1359:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    135d:	48 85 d2             	test   %rdx,%rdx
    1360:	0f 84 9a 00 00 00    	je     1400 <_mi_theap_page_reclaim+0x1c0>
    1366:	48 89 5a 48          	mov    %rbx,0x48(%rdx)
    136a:	48 83 80 30 05 00 00 	addq   $0x1,0x530(%rax)
    1371:	01 
    1372:	48 89 98 28 05 00 00 	mov    %rbx,0x528(%rax)
    1379:	48 3b 98 20 05 00 00 	cmp    0x520(%rax),%rbx
    1380:	0f 84 9a 00 00 00    	je     1420 <_mi_theap_page_reclaim+0x1e0>
    1386:	48 83 85 b8 00 00 00 	addq   $0x1,0xb8(%rbp)
    138d:	01 
    138e:	5b                   	pop    %rbx
    138f:	5d                   	pop    %rbp
    1390:	41 5c                	pop    %r12
    1392:	c3                   	ret
    1393:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1398:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
    139e:	77 20                	ja     13c0 <_mi_theap_page_reclaim+0x180>
    13a0:	8b 4b 68             	mov    0x68(%rbx),%ecx
    13a3:	8d 51 fd             	lea    -0x3(%rcx),%edx
    13a6:	83 fa 02             	cmp    $0x2,%edx
    13a9:	0f 87 a9 01 00 00    	ja     1558 <_mi_theap_page_reclaim+0x318>
    13af:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
    13b3:	0f 83 9f 01 00 00    	jae    1558 <_mi_theap_page_reclaim+0x318>
    13b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    13c0:	be 40 0e 00 00       	mov    $0xe40,%esi
    13c5:	41 bc 49 00 00 00    	mov    $0x49,%r12d
    13cb:	e9 00 ff ff ff       	jmp    12d0 <_mi_theap_page_reclaim+0x90>
    13d0:	48 89 c7             	mov    %rax,%rdi
    13d3:	48 89 c2             	mov    %rax,%rdx
    13d6:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
    13da:	f0 48 0f b1 3b       	lock cmpxchg %rdi,(%rbx)
    13df:	0f 84 1f ff ff ff    	je     1304 <_mi_theap_page_reclaim+0xc4>
    13e5:	eb e9                	jmp    13d0 <_mi_theap_page_reclaim+0x190>
    13e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    13ee:	00 00 
    13f0:	be 60 0e 00 00       	mov    $0xe60,%esi
    13f5:	41 bc 4a 00 00 00    	mov    $0x4a,%r12d
    13fb:	e9 d0 fe ff ff       	jmp    12d0 <_mi_theap_page_reclaim+0x90>
    1400:	4c 89 e2             	mov    %r12,%rdx
    1403:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    1408:	48 c1 e2 05          	shl    $0x5,%rdx
    140c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    1410:	0f 11 84 2a 20 05 00 	movups %xmm0,0x520(%rdx,%rbp,1)
    1417:	00 
    1418:	48 83 80 30 05 00 00 	addq   $0x1,0x530(%rax)
    141f:	01 
    1420:	49 c1 e4 05          	shl    $0x5,%r12
    1424:	4a 8b bc 25 38 05 00 	mov    0x538(%rbp,%r12,1),%rdi
    142b:	00 
    142c:	48 81 ff 00 04 00 00 	cmp    $0x400,%rdi
    1433:	0f 87 4d ff ff ff    	ja     1386 <_mi_theap_page_reclaim+0x146>
    1439:	48 83 c7 07          	add    $0x7,%rdi
    143d:	4c 8d 85 18 01 00 00 	lea    0x118(%rbp),%r8
    1444:	48 c1 ef 03          	shr    $0x3,%rdi
    1448:	48 39 9c fd 18 01 00 	cmp    %rbx,0x118(%rbp,%rdi,8)
    144f:	00 
    1450:	0f 84 30 ff ff ff    	je     1386 <_mi_theap_page_reclaim+0x146>
    1456:	48 83 ff 01          	cmp    $0x1,%rdi
    145a:	0f 86 80 01 00 00    	jbe    15e0 <_mi_theap_page_reclaim+0x3a0>
    1460:	48 83 ff 08          	cmp    $0x8,%rdi
    1464:	0f 87 81 01 00 00    	ja     15eb <_mi_theap_page_reclaim+0x3ab>
    146a:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    146e:	4d 89 cb             	mov    %r9,%r11
    1471:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
    1475:	48 8d 74 35 e0       	lea    -0x20(%rbp,%rsi,1),%rsi
    147a:	4c 8d 95 20 05 00 00 	lea    0x520(%rbp),%r10
    1481:	eb 1b                	jmp    149e <_mi_theap_page_reclaim+0x25e>
    1483:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1488:	48 8d 50 01          	lea    0x1(%rax),%rdx
    148c:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    1490:	49 39 d3             	cmp    %rdx,%r11
    1493:	75 28                	jne    14bd <_mi_theap_page_reclaim+0x27d>
    1495:	49 39 f2             	cmp    %rsi,%r10
    1498:	73 23                	jae    14bd <_mi_theap_page_reclaim+0x27d>
    149a:	48 83 ee 20          	sub    $0x20,%rsi
    149e:	48 8b 46 18          	mov    0x18(%rsi),%rax
    14a2:	48 8d 50 07          	lea    0x7(%rax),%rdx
    14a6:	48 89 d0             	mov    %rdx,%rax
    14a9:	48 c1 e8 03          	shr    $0x3,%rax
    14ad:	48 83 fa 47          	cmp    $0x47,%rdx
    14b1:	0f 87 e1 00 00 00    	ja     1598 <_mi_theap_page_reclaim+0x358>
    14b7:	48 83 f8 01          	cmp    $0x1,%rax
    14bb:	77 cb                	ja     1488 <_mi_theap_page_reclaim+0x248>
    14bd:	48 83 c0 01          	add    $0x1,%rax
    14c1:	48 39 f8             	cmp    %rdi,%rax
    14c4:	48 0f 47 c7          	cmova  %rdi,%rax
    14c8:	48 8d 50 01          	lea    0x1(%rax),%rdx
    14cc:	4c 89 c9             	mov    %r9,%rcx
    14cf:	be 01 00 00 00       	mov    $0x1,%esi
    14d4:	48 29 c1             	sub    %rax,%rcx
    14d7:	49 39 d1             	cmp    %rdx,%r9
    14da:	48 0f 42 ce          	cmovb  %rsi,%rcx
    14de:	48 39 c7             	cmp    %rax,%rdi
    14e1:	74 5d                	je     1540 <_mi_theap_page_reclaim+0x300>
    14e3:	49 39 d1             	cmp    %rdx,%r9
    14e6:	72 58                	jb     1540 <_mi_theap_page_reclaim+0x300>
    14e8:	48 89 ce             	mov    %rcx,%rsi
    14eb:	48 8d 94 c5 18 01 00 	lea    0x118(%rbp,%rax,8),%rdx
    14f2:	00 
    14f3:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    14f8:	48 d1 ee             	shr    $1,%rsi
    14fb:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    14ff:	48 c1 e6 04          	shl    $0x4,%rsi
    1503:	48 8d 3c 16          	lea    (%rsi,%rdx,1),%rdi
    1507:	83 e6 10             	and    $0x10,%esi
    150a:	74 14                	je     1520 <_mi_theap_page_reclaim+0x2e0>
    150c:	0f 11 02             	movups %xmm0,(%rdx)
    150f:	48 83 c2 10          	add    $0x10,%rdx
    1513:	48 39 fa             	cmp    %rdi,%rdx
    1516:	74 18                	je     1530 <_mi_theap_page_reclaim+0x2f0>
    1518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    151f:	00 
    1520:	0f 11 02             	movups %xmm0,(%rdx)
    1523:	48 83 c2 20          	add    $0x20,%rdx
    1527:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
    152b:	48 39 fa             	cmp    %rdi,%rdx
    152e:	75 f0                	jne    1520 <_mi_theap_page_reclaim+0x2e0>
    1530:	f6 c1 01             	test   $0x1,%cl
    1533:	0f 84 4d fe ff ff    	je     1386 <_mi_theap_page_reclaim+0x146>
    1539:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
    153d:	48 01 c8             	add    %rcx,%rax
    1540:	49 89 1c c0          	mov    %rbx,(%r8,%rax,8)
    1544:	48 83 85 b8 00 00 00 	addq   $0x1,0xb8(%rbp)
    154b:	01 
    154c:	5b                   	pop    %rbx
    154d:	5d                   	pop    %rbp
    154e:	41 5c                	pop    %r12
    1550:	c3                   	ret
    1551:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1558:	48 83 c0 07          	add    $0x7,%rax
    155c:	48 89 c2             	mov    %rax,%rdx
    155f:	48 c1 ea 03          	shr    $0x3,%rdx
    1563:	48 83 f8 47          	cmp    $0x47,%rax
    1567:	0f 86 45 fd ff ff    	jbe    12b2 <_mi_theap_page_reclaim+0x72>
    156d:	0f 1f 00             	nopl   (%rax)
    1570:	48 83 ea 01          	sub    $0x1,%rdx
    1574:	48 0f bd c2          	bsr    %rdx,%rax
    1578:	8d 48 fe             	lea    -0x2(%rax),%ecx
    157b:	48 d3 ea             	shr    %cl,%rdx
    157e:	83 e2 03             	and    $0x3,%edx
    1581:	4c 8d 64 82 fd       	lea    -0x3(%rdx,%rax,4),%r12
    1586:	49 8d 74 24 29       	lea    0x29(%r12),%rsi
    158b:	48 c1 e6 05          	shl    $0x5,%rsi
    158f:	e9 3c fd ff ff       	jmp    12d0 <_mi_theap_page_reclaim+0x90>
    1594:	0f 1f 40 00          	nopl   0x0(%rax)
    1598:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    159e:	0f 87 19 ff ff ff    	ja     14bd <_mi_theap_page_reclaim+0x27d>
    15a4:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    15a8:	4c 0f bd e2          	bsr    %rdx,%r12
    15ac:	41 8d 4c 24 fe       	lea    -0x2(%r12),%ecx
    15b1:	48 d3 ea             	shr    %cl,%rdx
    15b4:	83 e2 03             	and    $0x3,%edx
    15b7:	4a 8d 54 a2 fd       	lea    -0x3(%rdx,%r12,4),%rdx
    15bc:	e9 cf fe ff ff       	jmp    1490 <_mi_theap_page_reclaim+0x250>
    15c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    15c8:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
    15cf:	76 9f                	jbe    1570 <_mi_theap_page_reclaim+0x330>
    15d1:	e9 ea fd ff ff       	jmp    13c0 <_mi_theap_page_reclaim+0x180>
    15d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    15dd:	00 00 00 
    15e0:	31 c0                	xor    %eax,%eax
    15e2:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    15e6:	e9 dd fe ff ff       	jmp    14c8 <_mi_theap_page_reclaim+0x288>
    15eb:	48 8d 47 ff          	lea    -0x1(%rdi),%rax
    15ef:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    15f3:	48 0f bd d0          	bsr    %rax,%rdx
    15f7:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    15fa:	48 d3 e8             	shr    %cl,%rax
    15fd:	83 e0 03             	and    $0x3,%eax
    1600:	4c 8d 5c 90 fd       	lea    -0x3(%rax,%rdx,4),%r11
    1605:	e9 6b fe ff ff       	jmp    1475 <_mi_theap_page_reclaim+0x235>
    160a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000001610 <_mi_page_abandon>:
    1610:	55                   	push   %rbp
    1611:	48 89 f5             	mov    %rsi,%rbp
    1614:	31 f6                	xor    %esi,%esi
    1616:	53                   	push   %rbx
    1617:	48 89 fb             	mov    %rdi,%rbx
    161a:	48 83 ec 08          	sub    $0x8,%rsp
    161e:	e8 00 00 00 00       	call   1623 <_mi_page_abandon+0x13>
			161f: R_X86_64_PLT32	_mi_page_free_collect_no_unpurge-0x4
    1623:	8b 43 10             	mov    0x10(%rbx),%eax
    1626:	85 c0                	test   %eax,%eax
    1628:	75 3e                	jne    1668 <_mi_page_abandon+0x58>
    162a:	f0 48 83 23 fd       	lock andq $0xfffffffffffffffd,(%rbx)
    162f:	48 89 de             	mov    %rbx,%rsi
    1632:	48 89 ef             	mov    %rbp,%rdi
    1635:	e8 a6 ef ff ff       	call   5e0 <mi_page_queue_remove>
    163a:	48 8b 73 38          	mov    0x38(%rbx),%rsi
    163e:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    1645:	00 
    1646:	48 8b 03             	mov    (%rbx),%rax
    1649:	48 89 c2             	mov    %rax,%rdx
    164c:	83 e2 03             	and    $0x3,%edx
    164f:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    1654:	75 f3                	jne    1649 <_mi_page_abandon+0x39>
    1656:	48 83 c4 08          	add    $0x8,%rsp
    165a:	48 89 df             	mov    %rbx,%rdi
    165d:	5b                   	pop    %rbx
    165e:	5d                   	pop    %rbp
    165f:	e9 00 00 00 00       	jmp    1664 <_mi_page_abandon+0x54>
			1660: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    1664:	0f 1f 40 00          	nopl   0x0(%rax)
    1668:	48 89 de             	mov    %rbx,%rsi
    166b:	48 89 ef             	mov    %rbp,%rdi
    166e:	e8 6d ef ff ff       	call   5e0 <mi_page_queue_remove>
    1673:	48 8b 73 38          	mov    0x38(%rbx),%rsi
    1677:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    167e:	00 
    167f:	48 8b 03             	mov    (%rbx),%rax
    1682:	48 89 c2             	mov    %rax,%rdx
    1685:	83 e2 03             	and    $0x3,%edx
    1688:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    168d:	75 f3                	jne    1682 <_mi_page_abandon+0x72>
    168f:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    1693:	48 83 c4 08          	add    $0x8,%rsp
    1697:	48 89 df             	mov    %rbx,%rdi
    169a:	5b                   	pop    %rbx
    169b:	5d                   	pop    %rbp
    169c:	e9 00 00 00 00       	jmp    16a1 <_mi_page_abandon+0x91>
			169d: R_X86_64_PLT32	_mi_arenas_page_abandon-0x4
    16a1:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    16a8:	00 00 00 00 
    16ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000016b0 <mi_page_fresh_alloc>:
    16b0:	41 57                	push   %r15
    16b2:	41 56                	push   %r14
    16b4:	49 89 ce             	mov    %rcx,%r14
    16b7:	41 55                	push   %r13
    16b9:	49 89 f5             	mov    %rsi,%r13
    16bc:	41 54                	push   %r12
    16be:	49 89 d4             	mov    %rdx,%r12
    16c1:	55                   	push   %rbp
    16c2:	48 89 fd             	mov    %rdi,%rbp
    16c5:	53                   	push   %rbx
    16c6:	48 83 ec 28          	sub    $0x28,%rsp
    16ca:	48 85 c9             	test   %rcx,%rcx
    16cd:	0f 85 8d 02 00 00    	jne    1960 <mi_page_fresh_alloc+0x2b0>
    16d3:	48 85 f6             	test   %rsi,%rsi
    16d6:	0f 84 84 02 00 00    	je     1960 <mi_page_fresh_alloc+0x2b0>
    16dc:	48 8d 82 55 ad fe ff 	lea    -0x152ab(%rdx),%rax
    16e3:	48 3d 55 ad 06 00    	cmp    $0x6ad55,%rax
    16e9:	0f 87 71 02 00 00    	ja     1960 <mi_page_fresh_alloc+0x2b0>
    16ef:	48 8b 07             	mov    (%rdi),%rax
    16f2:	8b 80 f4 01 00 00    	mov    0x1f4(%rax),%eax
    16f8:	85 c0                	test   %eax,%eax
    16fa:	0f 84 60 02 00 00    	je     1960 <mi_page_fresh_alloc+0x2b0>
    1700:	48 8d 42 07          	lea    0x7(%rdx),%rax
    1704:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    1708:	48 c1 e8 03          	shr    $0x3,%rax
    170c:	48 83 e8 01          	sub    $0x1,%rax
    1710:	48 0f bd d0          	bsr    %rax,%rdx
    1714:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    1717:	48 d3 e8             	shr    %cl,%rax
    171a:	83 e0 03             	and    $0x3,%eax
    171d:	4c 8d 7c 90 fd       	lea    -0x3(%rax,%rdx,4),%r15
    1722:	49 8d 47 0d          	lea    0xd(%r15),%rax
    1726:	48 8b 04 c6          	mov    (%rsi,%rax,8),%rax
    172a:	48 85 c0             	test   %rax,%rax
    172d:	0f 85 2d 02 00 00    	jne    1960 <mi_page_fresh_alloc+0x2b0>
    1733:	31 d2                	xor    %edx,%edx
    1735:	4c 89 e6             	mov    %r12,%rsi
    1738:	e8 00 00 00 00       	call   173d <mi_page_fresh_alloc+0x8d>
			1739: R_X86_64_PLT32	_mi_large_span_peek_slices-0x4
    173d:	4f 8d 04 24          	lea    (%r12,%r12,1),%r8
    1741:	4c 89 ee             	mov    %r13,%rsi
    1744:	48 89 ef             	mov    %rbp,%rdi
    1747:	48 c1 e0 10          	shl    $0x10,%rax
    174b:	b9 3c 00 00 00       	mov    $0x3c,%ecx
    1750:	4c 8d 4c 24 18       	lea    0x18(%rsp),%r9
    1755:	ba 32 00 00 00       	mov    $0x32,%edx
    175a:	4c 39 c0             	cmp    %r8,%rax
    175d:	4c 0f 43 c0          	cmovae %rax,%r8
    1761:	e8 00 00 00 00       	call   1766 <mi_page_fresh_alloc+0xb6>
			1762: R_X86_64_PLT32	_mi_page_repurpose_find-0x4
    1766:	48 89 c1             	mov    %rax,%rcx
    1769:	48 85 c0             	test   %rax,%rax
    176c:	0f 84 ee 01 00 00    	je     1960 <mi_page_fresh_alloc+0x2b0>
    1772:	48 8d 95 20 05 00 00 	lea    0x520(%rbp),%rdx
    1779:	4c 89 e8             	mov    %r13,%rax
    177c:	48 29 d0             	sub    %rdx,%rax
    177f:	48 c1 f8 05          	sar    $0x5,%rax
    1783:	48 83 e8 32          	sub    $0x32,%rax
    1787:	48 83 f8 0f          	cmp    $0xf,%rax
    178b:	77 0a                	ja     1797 <mi_page_fresh_alloc+0xe7>
    178d:	80 bc 05 a8 1f 00 00 	cmpb   $0x0,0x1fa8(%rbp,%rax,1)
    1794:	00 
    1795:	74 15                	je     17ac <mi_page_fresh_alloc+0xfc>
    1797:	31 d2                	xor    %edx,%edx
    1799:	4c 89 e6             	mov    %r12,%rsi
    179c:	48 89 ef             	mov    %rbp,%rdi
    179f:	48 89 0c 24          	mov    %rcx,(%rsp)
    17a3:	e8 00 00 00 00       	call   17a8 <mi_page_fresh_alloc+0xf8>
			17a4: R_X86_64_PLT32	_mi_large_span_slices-0x4
    17a8:	48 8b 0c 24          	mov    (%rsp),%rcx
    17ac:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    17b0:	48 8b 19             	mov    (%rcx),%rbx
    17b3:	48 89 0c 24          	mov    %rcx,(%rsp)
    17b7:	83 ae f4 01 00 00 01 	subl   $0x1,0x1f4(%rsi)
    17be:	48 89 df             	mov    %rbx,%rdi
    17c1:	e8 00 00 00 00       	call   17c6 <mi_page_fresh_alloc+0x116>
			17c2: R_X86_64_PLT32	_mi_page_unpublish_retired-0x4
    17c6:	48 8b 3c 24          	mov    (%rsp),%rdi
    17ca:	48 89 de             	mov    %rbx,%rsi
    17cd:	e8 0e ee ff ff       	call   5e0 <mi_page_queue_remove>
    17d2:	66 83 7b 36 01       	cmpw   $0x1,0x36(%rbx)
    17d7:	48 8b 43 28          	mov    0x28(%rbx),%rax
    17db:	0f 84 37 02 00 00    	je     1a18 <mi_page_fresh_alloc+0x368>
    17e1:	48 8d 50 07          	lea    0x7(%rax),%rdx
    17e5:	48 89 d0             	mov    %rdx,%rax
    17e8:	48 c1 e8 03          	shr    $0x3,%rax
    17ec:	48 83 fa 47          	cmp    $0x47,%rdx
    17f0:	0f 87 ea 02 00 00    	ja     1ae0 <mi_page_fresh_alloc+0x430>
    17f6:	bf 40 18 00 00       	mov    $0x1840,%edi
    17fb:	48 83 f8 01          	cmp    $0x1,%rax
    17ff:	76 14                	jbe    1815 <mi_page_fresh_alloc+0x165>
    1801:	48 83 c0 01          	add    $0x1,%rax
    1805:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    1809:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    180d:	48 8d 3c c5 28 18 00 	lea    0x1828(,%rax,8),%rdi
    1814:	00 
    1815:	48 01 ef             	add    %rbp,%rdi
    1818:	be 01 00 00 00       	mov    $0x1,%esi
    181d:	e8 00 00 00 00       	call   1822 <mi_page_fresh_alloc+0x172>
			181e: R_X86_64_PLT32	__mi_stat_decrease-0x4
    1822:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    1827:	31 d2                	xor    %edx,%edx
    1829:	8b 73 68             	mov    0x68(%rbx),%esi
    182c:	4c 89 e7             	mov    %r12,%rdi
    182f:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
    1836:	00 
    1837:	49 f7 f4             	div    %r12
    183a:	8b 53 30             	mov    0x30(%rbx),%edx
    183d:	c6 43 6e 00          	movb   $0x0,0x6e(%rbx)
    1841:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    1848:	00 00 00 00 
    184c:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%rbx)
    1853:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    185a:	00 
    185b:	48 c1 e2 04          	shl    $0x4,%rdx
    185f:	48 01 da             	add    %rbx,%rdx
    1862:	48 89 d1             	mov    %rdx,%rcx
    1865:	66 31 c9             	xor    %cx,%cx
    1868:	83 fe 06             	cmp    $0x6,%esi
    186b:	48 0f 45 cb          	cmovne %rbx,%rcx
    186f:	48 29 ca             	sub    %rcx,%rdx
    1872:	0f b7 4b 36          	movzwl 0x36(%rbx),%ecx
    1876:	48 0f af 4b 28       	imul   0x28(%rbx),%rcx
    187b:	4c 89 63 28          	mov    %r12,0x28(%rbx)
    187f:	48 8d 8c 0a ff ff 00 	lea    0xffff(%rdx,%rcx,1),%rcx
    1886:	00 
    1887:	48 c1 e9 10          	shr    $0x10,%rcx
    188b:	48 0f af f8          	imul   %rax,%rdi
    188f:	66 89 43 36          	mov    %ax,0x36(%rbx)
    1893:	48 8d 94 3a ff ff 00 	lea    0xffff(%rdx,%rdi,1),%rdx
    189a:	00 
    189b:	48 c1 ea 10          	shr    $0x10,%rdx
    189f:	66 83 f8 01          	cmp    $0x1,%ax
    18a3:	0f 84 17 02 00 00    	je     1ac0 <mi_page_fresh_alloc+0x410>
    18a9:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
    18ad:	48 8d 3c c5 28 18 00 	lea    0x1828(,%rax,8),%rdi
    18b4:	00 
    18b5:	48 01 ef             	add    %rbp,%rdi
    18b8:	be 01 00 00 00       	mov    $0x1,%esi
    18bd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    18c2:	48 89 0c 24          	mov    %rcx,(%rsp)
    18c6:	e8 00 00 00 00       	call   18cb <mi_page_fresh_alloc+0x21b>
			18c7: R_X86_64_PLT32	__mi_stat_increase-0x4
    18cb:	48 8b 0c 24          	mov    (%rsp),%rcx
    18cf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    18d4:	48 39 ca             	cmp    %rcx,%rdx
    18d7:	73 67                	jae    1940 <mi_page_fresh_alloc+0x290>
    18d9:	48 29 d1             	sub    %rdx,%rcx
    18dc:	48 89 df             	mov    %rbx,%rdi
    18df:	48 89 ce             	mov    %rcx,%rsi
    18e2:	48 c1 e6 10          	shl    $0x10,%rsi
    18e6:	83 7b 68 06          	cmpl   $0x6,0x68(%rbx)
    18ea:	75 0d                	jne    18f9 <mi_page_fresh_alloc+0x249>
    18ec:	8b 7b 30             	mov    0x30(%rbx),%edi
    18ef:	48 c1 e7 04          	shl    $0x4,%rdi
    18f3:	48 01 df             	add    %rbx,%rdi
    18f6:	66 31 ff             	xor    %di,%di
    18f9:	48 c1 e2 10          	shl    $0x10,%rdx
    18fd:	48 01 d7             	add    %rdx,%rdi
    1900:	e8 00 00 00 00       	call   1905 <mi_page_fresh_alloc+0x255>
			1901: R_X86_64_PLT32	_mi_page_map_unregister_range-0x4
    1905:	4c 89 ee             	mov    %r13,%rsi
    1908:	48 89 da             	mov    %rbx,%rdx
    190b:	48 89 ef             	mov    %rbp,%rdi
    190e:	e8 7d ea ff ff       	call   390 <mi_page_queue_push>
    1913:	48 89 df             	mov    %rbx,%rdi
    1916:	e8 00 00 00 00       	call   191b <mi_page_fresh_alloc+0x26b>
			1917: R_X86_64_PLT32	_mi_page_purged_reset-0x4
    191b:	48 89 de             	mov    %rbx,%rsi
    191e:	48 89 ef             	mov    %rbp,%rdi
    1921:	e8 2a e7 ff ff       	call   50 <mi_page_extend_free>
    1926:	84 c0                	test   %al,%al
    1928:	75 70                	jne    199a <mi_page_fresh_alloc+0x2ea>
    192a:	48 89 de             	mov    %rbx,%rsi
    192d:	4c 89 ef             	mov    %r13,%rdi
    1930:	e8 ab ec ff ff       	call   5e0 <mi_page_queue_remove>
    1935:	eb 1a                	jmp    1951 <mi_page_fresh_alloc+0x2a1>
    1937:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    193e:	00 00 
    1940:	48 39 d1             	cmp    %rdx,%rcx
    1943:	73 c0                	jae    1905 <mi_page_fresh_alloc+0x255>
    1945:	48 89 df             	mov    %rbx,%rdi
    1948:	e8 00 00 00 00       	call   194d <mi_page_fresh_alloc+0x29d>
			1949: R_X86_64_PLT32	_mi_page_map_register-0x4
    194d:	84 c0                	test   %al,%al
    194f:	75 b4                	jne    1905 <mi_page_fresh_alloc+0x255>
    1951:	48 89 ee             	mov    %rbp,%rsi
    1954:	48 89 df             	mov    %rbx,%rdi
    1957:	e8 00 00 00 00       	call   195c <mi_page_fresh_alloc+0x2ac>
			1958: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    195c:	0f 1f 40 00          	nopl   0x0(%rax)
    1960:	4c 89 f2             	mov    %r14,%rdx
    1963:	4c 89 e6             	mov    %r12,%rsi
    1966:	48 89 ef             	mov    %rbp,%rdi
    1969:	e8 00 00 00 00       	call   196e <mi_page_fresh_alloc+0x2be>
			196a: R_X86_64_PLT32	_mi_arenas_page_alloc-0x4
    196e:	48 89 c3             	mov    %rax,%rbx
    1971:	48 85 c0             	test   %rax,%rax
    1974:	0f 84 93 00 00 00    	je     1a0d <mi_page_fresh_alloc+0x35d>
    197a:	48 8b 00             	mov    (%rax),%rax
    197d:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
    1981:	48 83 f8 04          	cmp    $0x4,%rax
    1985:	76 29                	jbe    19b0 <mi_page_fresh_alloc+0x300>
    1987:	4d 85 ed             	test   %r13,%r13
    198a:	74 0e                	je     199a <mi_page_fresh_alloc+0x2ea>
    198c:	48 89 da             	mov    %rbx,%rdx
    198f:	4c 89 ee             	mov    %r13,%rsi
    1992:	48 89 ef             	mov    %rbp,%rdi
    1995:	e8 f6 e9 ff ff       	call   390 <mi_page_queue_push>
    199a:	48 83 c4 28          	add    $0x28,%rsp
    199e:	48 89 d8             	mov    %rbx,%rax
    19a1:	5b                   	pop    %rbx
    19a2:	5d                   	pop    %rbp
    19a3:	41 5c                	pop    %r12
    19a5:	41 5d                	pop    %r13
    19a7:	41 5e                	pop    %r14
    19a9:	41 5f                	pop    %r15
    19ab:	c3                   	ret
    19ac:	0f 1f 40 00          	nopl   0x0(%rax)
    19b0:	48 89 de             	mov    %rbx,%rsi
    19b3:	48 89 ef             	mov    %rbp,%rdi
    19b6:	e8 00 00 00 00       	call   19bb <mi_page_fresh_alloc+0x30b>
			19b7: R_X86_64_PLT32	_mi_theap_page_reclaim-0x4
    19bb:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    19c0:	75 d8                	jne    199a <mi_page_fresh_alloc+0x2ea>
    19c2:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
    19c6:	66 39 43 14          	cmp    %ax,0x14(%rbx)
    19ca:	0f 82 b0 00 00 00    	jb     1a80 <mi_page_fresh_alloc+0x3d0>
    19d0:	48 83 7b 70 00       	cmpq   $0x0,0x70(%rbx)
    19d5:	0f 85 c5 00 00 00    	jne    1aa0 <mi_page_fresh_alloc+0x3f0>
    19db:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
    19e0:	0f 85 ba 00 00 00    	jne    1aa0 <mi_page_fresh_alloc+0x3f0>
    19e6:	48 83 bb 80 00 00 00 	cmpq   $0x0,0x80(%rbx)
    19ed:	00 
    19ee:	0f 85 ac 00 00 00    	jne    1aa0 <mi_page_fresh_alloc+0x3f0>
    19f4:	48 83 bb 88 00 00 00 	cmpq   $0x0,0x88(%rbx)
    19fb:	00 
    19fc:	0f 85 9e 00 00 00    	jne    1aa0 <mi_page_fresh_alloc+0x3f0>
    1a02:	4c 89 ee             	mov    %r13,%rsi
    1a05:	48 89 df             	mov    %rbx,%rdi
    1a08:	e8 00 00 00 00       	call   1a0d <mi_page_fresh_alloc+0x35d>
			1a09: R_X86_64_PLT32	_mi_page_abandon-0x4
    1a0d:	31 db                	xor    %ebx,%ebx
    1a0f:	eb 89                	jmp    199a <mi_page_fresh_alloc+0x2ea>
    1a11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1a18:	bf 00 1f 00 00       	mov    $0x1f00,%edi
    1a1d:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
    1a23:	0f 87 ec fd ff ff    	ja     1815 <mi_page_fresh_alloc+0x165>
    1a29:	8b 73 68             	mov    0x68(%rbx),%esi
    1a2c:	8d 56 fd             	lea    -0x3(%rsi),%edx
    1a2f:	83 fa 02             	cmp    $0x2,%edx
    1a32:	77 0a                	ja     1a3e <mi_page_fresh_alloc+0x38e>
    1a34:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
    1a38:	0f 82 d7 fd ff ff    	jb     1815 <mi_page_fresh_alloc+0x165>
    1a3e:	48 8d 50 07          	lea    0x7(%rax),%rdx
    1a42:	48 89 d0             	mov    %rdx,%rax
    1a45:	48 c1 e8 03          	shr    $0x3,%rax
    1a49:	48 83 fa 47          	cmp    $0x47,%rdx
    1a4d:	0f 86 a3 fd ff ff    	jbe    17f6 <mi_page_fresh_alloc+0x146>
    1a53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1a58:	48 83 e8 01          	sub    $0x1,%rax
    1a5c:	48 0f bd d0          	bsr    %rax,%rdx
    1a60:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    1a63:	48 d3 e8             	shr    %cl,%rax
    1a66:	83 e0 03             	and    $0x3,%eax
    1a69:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
    1a6e:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    1a72:	48 8d 3c c5 28 18 00 	lea    0x1828(,%rax,8),%rdi
    1a79:	00 
    1a7a:	e9 96 fd ff ff       	jmp    1815 <mi_page_fresh_alloc+0x165>
    1a7f:	90                   	nop
    1a80:	48 89 de             	mov    %rbx,%rsi
    1a83:	48 89 ef             	mov    %rbp,%rdi
    1a86:	e8 c5 e5 ff ff       	call   50 <mi_page_extend_free>
    1a8b:	84 c0                	test   %al,%al
    1a8d:	0f 85 07 ff ff ff    	jne    199a <mi_page_fresh_alloc+0x2ea>
    1a93:	e9 6a ff ff ff       	jmp    1a02 <mi_page_fresh_alloc+0x352>
    1a98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    1a9f:	00 
    1aa0:	48 89 df             	mov    %rbx,%rdi
    1aa3:	e8 00 00 00 00       	call   1aa8 <mi_page_fresh_alloc+0x3f8>
			1aa4: R_X86_64_PLT32	_mi_page_unpurge_run-0x4
    1aa8:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    1aad:	0f 85 e7 fe ff ff    	jne    199a <mi_page_fresh_alloc+0x2ea>
    1ab3:	e9 4a ff ff ff       	jmp    1a02 <mi_page_fresh_alloc+0x352>
    1ab8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    1abf:	00 
    1ac0:	83 ee 03             	sub    $0x3,%esi
    1ac3:	83 fe 02             	cmp    $0x2,%esi
    1ac6:	0f 87 dd fd ff ff    	ja     18a9 <mi_page_fresh_alloc+0x1f9>
    1acc:	bf 00 1f 00 00       	mov    $0x1f00,%edi
    1ad1:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
    1ad5:	0f 82 da fd ff ff    	jb     18b5 <mi_page_fresh_alloc+0x205>
    1adb:	e9 c9 fd ff ff       	jmp    18a9 <mi_page_fresh_alloc+0x1f9>
    1ae0:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    1ae6:	0f 86 6c ff ff ff    	jbe    1a58 <mi_page_fresh_alloc+0x3a8>
    1aec:	bf 00 1f 00 00       	mov    $0x1f00,%edi
    1af1:	e9 1f fd ff ff       	jmp    1815 <mi_page_fresh_alloc+0x165>
    1af6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    1afd:	00 00 00 

0000000000001b00 <_mi_page_free_or_reserve>:
    1b00:	41 57                	push   %r15
    1b02:	41 56                	push   %r14
    1b04:	41 55                	push   %r13
    1b06:	49 89 fd             	mov    %rdi,%r13
    1b09:	41 54                	push   %r12
    1b0b:	55                   	push   %rbp
    1b0c:	48 89 f5             	mov    %rsi,%rbp
    1b0f:	53                   	push   %rbx
    1b10:	48 89 fb             	mov    %rdi,%rbx
    1b13:	48 83 ec 08          	sub    $0x8,%rsp
    1b17:	f0 48 83 27 fd       	lock andq $0xfffffffffffffffd,(%rdi)
    1b1c:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    1b20:	4c 8b 67 38          	mov    0x38(%rdi),%r12
    1b24:	48 85 d2             	test   %rdx,%rdx
    1b27:	74 08                	je     1b31 <_mi_page_free_or_reserve+0x31>
    1b29:	48 8b 47 48          	mov    0x48(%rdi),%rax
    1b2d:	48 89 42 48          	mov    %rax,0x48(%rdx)
    1b31:	48 8b 43 48          	mov    0x48(%rbx),%rax
    1b35:	48 85 c0             	test   %rax,%rax
    1b38:	74 04                	je     1b3e <_mi_page_free_or_reserve+0x3e>
    1b3a:	48 89 50 50          	mov    %rdx,0x50(%rax)
    1b3e:	48 3b 5d 08          	cmp    0x8(%rbp),%rbx
    1b42:	0f 84 a8 00 00 00    	je     1bf0 <_mi_page_free_or_reserve+0xf0>
    1b48:	48 3b 5d 00          	cmp    0x0(%rbp),%rbx
    1b4c:	0f 84 b0 00 00 00    	je     1c02 <_mi_page_free_or_reserve+0x102>
    1b52:	49 83 ac 24 b8 00 00 	subq   $0x1,0xb8(%r12)
    1b59:	00 01 
    1b5b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    1b5f:	48 83 6d 10 01       	subq   $0x1,0x10(%rbp)
    1b64:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
    1b68:	f0 49 0f ba 75 00 00 	lock btrq $0x0,0x0(%r13)
    1b6f:	73 57                	jae    1bc8 <_mi_page_free_or_reserve+0xc8>
    1b71:	48 8b 6b 38          	mov    0x38(%rbx),%rbp
    1b75:	48 85 ed             	test   %rbp,%rbp
    1b78:	74 10                	je     1b8a <_mi_page_free_or_reserve+0x8a>
    1b7a:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
    1b7e:	48 0f af 43 28       	imul   0x28(%rbx),%rax
    1b83:	48 29 85 d0 00 00 00 	sub    %rax,0xd0(%rbp)
    1b8a:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    1b91:	00 
    1b92:	48 8b 03             	mov    (%rbx),%rax
    1b95:	48 89 c2             	mov    %rax,%rdx
    1b98:	83 e2 03             	and    $0x3,%edx
    1b9b:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    1ba0:	75 f3                	jne    1b95 <_mi_page_free_or_reserve+0x95>
    1ba2:	c6 43 16 00          	movb   $0x0,0x16(%rbx)
    1ba6:	48 89 ee             	mov    %rbp,%rsi
    1ba9:	48 89 df             	mov    %rbx,%rdi
    1bac:	e8 00 00 00 00       	call   1bb1 <_mi_page_free_or_reserve+0xb1>
			1bad: R_X86_64_PLT32	_mi_arenas_page_reserve-0x4
    1bb1:	84 c0                	test   %al,%al
    1bb3:	74 1b                	je     1bd0 <_mi_page_free_or_reserve+0xd0>
    1bb5:	48 83 c4 08          	add    $0x8,%rsp
    1bb9:	5b                   	pop    %rbx
    1bba:	5d                   	pop    %rbp
    1bbb:	41 5c                	pop    %r12
    1bbd:	41 5d                	pop    %r13
    1bbf:	41 5e                	pop    %r14
    1bc1:	41 5f                	pop    %r15
    1bc3:	c3                   	ret
    1bc4:	0f 1f 40 00          	nopl   0x0(%rax)
    1bc8:	48 8b 6b 38          	mov    0x38(%rbx),%rbp
    1bcc:	eb bc                	jmp    1b8a <_mi_page_free_or_reserve+0x8a>
    1bce:	66 90                	xchg   %ax,%ax
    1bd0:	48 83 c4 08          	add    $0x8,%rsp
    1bd4:	48 89 ee             	mov    %rbp,%rsi
    1bd7:	48 89 df             	mov    %rbx,%rdi
    1bda:	5b                   	pop    %rbx
    1bdb:	5d                   	pop    %rbp
    1bdc:	41 5c                	pop    %r12
    1bde:	41 5d                	pop    %r13
    1be0:	41 5e                	pop    %r14
    1be2:	41 5f                	pop    %r15
    1be4:	e9 00 00 00 00       	jmp    1be9 <_mi_page_free_or_reserve+0xe9>
			1be5: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    1be9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1bf0:	48 8b 53 50          	mov    0x50(%rbx),%rdx
    1bf4:	48 89 55 08          	mov    %rdx,0x8(%rbp)
    1bf8:	48 3b 5d 00          	cmp    0x0(%rbp),%rbx
    1bfc:	0f 85 50 ff ff ff    	jne    1b52 <_mi_page_free_or_reserve+0x52>
    1c02:	4c 8b 75 18          	mov    0x18(%rbp),%r14
    1c06:	48 89 45 00          	mov    %rax,0x0(%rbp)
    1c0a:	49 81 fe 00 04 00 00 	cmp    $0x400,%r14
    1c11:	0f 87 3b ff ff ff    	ja     1b52 <_mi_page_free_or_reserve+0x52>
    1c17:	48 85 c0             	test   %rax,%rax
    1c1a:	0f 84 58 01 00 00    	je     1d78 <_mi_page_free_or_reserve+0x278>
    1c20:	49 8d 7e 07          	lea    0x7(%r14),%rdi
    1c24:	4d 8d 84 24 18 01 00 	lea    0x118(%r12),%r8
    1c2b:	00 
    1c2c:	48 c1 ef 03          	shr    $0x3,%rdi
    1c30:	49 39 84 fc 18 01 00 	cmp    %rax,0x118(%r12,%rdi,8)
    1c37:	00 
    1c38:	0f 84 14 ff ff ff    	je     1b52 <_mi_page_free_or_reserve+0x52>
    1c3e:	48 83 ff 01          	cmp    $0x1,%rdi
    1c42:	0f 86 20 01 00 00    	jbe    1d68 <_mi_page_free_or_reserve+0x268>
    1c48:	48 83 ff 08          	cmp    $0x8,%rdi
    1c4c:	0f 87 30 01 00 00    	ja     1d82 <_mi_page_free_or_reserve+0x282>
    1c52:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    1c56:	4d 89 cb             	mov    %r9,%r11
    1c59:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
    1c5d:	48 8d 75 e0          	lea    -0x20(%rbp),%rsi
    1c61:	4d 8d 94 24 20 05 00 	lea    0x520(%r12),%r10
    1c68:	00 
    1c69:	eb 1b                	jmp    1c86 <_mi_page_free_or_reserve+0x186>
    1c6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1c70:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
    1c74:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
    1c78:	49 39 cb             	cmp    %rcx,%r11
    1c7b:	75 28                	jne    1ca5 <_mi_page_free_or_reserve+0x1a5>
    1c7d:	49 39 f2             	cmp    %rsi,%r10
    1c80:	73 23                	jae    1ca5 <_mi_page_free_or_reserve+0x1a5>
    1c82:	48 83 ee 20          	sub    $0x20,%rsi
    1c86:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
    1c8a:	48 83 c1 07          	add    $0x7,%rcx
    1c8e:	48 89 ca             	mov    %rcx,%rdx
    1c91:	48 c1 ea 03          	shr    $0x3,%rdx
    1c95:	48 83 f9 47          	cmp    $0x47,%rcx
    1c99:	0f 87 99 00 00 00    	ja     1d38 <_mi_page_free_or_reserve+0x238>
    1c9f:	48 83 fa 01          	cmp    $0x1,%rdx
    1ca3:	77 cb                	ja     1c70 <_mi_page_free_or_reserve+0x170>
    1ca5:	48 83 c2 01          	add    $0x1,%rdx
    1ca9:	48 39 fa             	cmp    %rdi,%rdx
    1cac:	48 0f 47 d7          	cmova  %rdi,%rdx
    1cb0:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
    1cb4:	4c 89 ce             	mov    %r9,%rsi
    1cb7:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    1cbd:	48 29 d6             	sub    %rdx,%rsi
    1cc0:	49 39 c9             	cmp    %rcx,%r9
    1cc3:	49 0f 42 f2          	cmovb  %r10,%rsi
    1cc7:	48 39 d7             	cmp    %rdx,%rdi
    1cca:	74 5d                	je     1d29 <_mi_page_free_or_reserve+0x229>
    1ccc:	49 39 c9             	cmp    %rcx,%r9
    1ccf:	72 58                	jb     1d29 <_mi_page_free_or_reserve+0x229>
    1cd1:	48 89 f7             	mov    %rsi,%rdi
    1cd4:	49 8d 8c d4 18 01 00 	lea    0x118(%r12,%rdx,8),%rcx
    1cdb:	00 
    1cdc:	66 48 0f 6e c0       	movq   %rax,%xmm0
    1ce1:	48 d1 ef             	shr    $1,%rdi
    1ce4:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    1ce8:	48 c1 e7 04          	shl    $0x4,%rdi
    1cec:	4c 8d 0c 0f          	lea    (%rdi,%rcx,1),%r9
    1cf0:	83 e7 10             	and    $0x10,%edi
    1cf3:	74 13                	je     1d08 <_mi_page_free_or_reserve+0x208>
    1cf5:	0f 11 01             	movups %xmm0,(%rcx)
    1cf8:	48 83 c1 10          	add    $0x10,%rcx
    1cfc:	4c 39 c9             	cmp    %r9,%rcx
    1cff:	74 17                	je     1d18 <_mi_page_free_or_reserve+0x218>
    1d01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1d08:	0f 11 01             	movups %xmm0,(%rcx)
    1d0b:	48 83 c1 20          	add    $0x20,%rcx
    1d0f:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
    1d13:	4c 39 c9             	cmp    %r9,%rcx
    1d16:	75 f0                	jne    1d08 <_mi_page_free_or_reserve+0x208>
    1d18:	40 f6 c6 01          	test   $0x1,%sil
    1d1c:	0f 84 30 fe ff ff    	je     1b52 <_mi_page_free_or_reserve+0x52>
    1d22:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
    1d26:	48 01 f2             	add    %rsi,%rdx
    1d29:	49 89 04 d0          	mov    %rax,(%r8,%rdx,8)
    1d2d:	e9 20 fe ff ff       	jmp    1b52 <_mi_page_free_or_reserve+0x52>
    1d32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1d38:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
    1d3f:	0f 87 60 ff ff ff    	ja     1ca5 <_mi_page_free_or_reserve+0x1a5>
    1d45:	4c 8d 72 ff          	lea    -0x1(%rdx),%r14
    1d49:	4d 0f bd fe          	bsr    %r14,%r15
    1d4d:	41 8d 4f fe          	lea    -0x2(%r15),%ecx
    1d51:	49 d3 ee             	shr    %cl,%r14
    1d54:	41 83 e6 03          	and    $0x3,%r14d
    1d58:	4b 8d 4c be fd       	lea    -0x3(%r14,%r15,4),%rcx
    1d5d:	e9 16 ff ff ff       	jmp    1c78 <_mi_page_free_or_reserve+0x178>
    1d62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1d68:	31 d2                	xor    %edx,%edx
    1d6a:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    1d6e:	e9 3d ff ff ff       	jmp    1cb0 <_mi_page_free_or_reserve+0x1b0>
    1d73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1d78:	e8 00 00 00 00       	call   1d7d <_mi_page_free_or_reserve+0x27d>
			1d79: R_X86_64_PLT32	_mi_page_empty_get-0x4
    1d7d:	e9 9e fe ff ff       	jmp    1c20 <_mi_page_free_or_reserve+0x120>
    1d82:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    1d86:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    1d8a:	48 0f bd f2          	bsr    %rdx,%rsi
    1d8e:	8d 4e fe             	lea    -0x2(%rsi),%ecx
    1d91:	48 d3 ea             	shr    %cl,%rdx
    1d94:	83 e2 03             	and    $0x3,%edx
    1d97:	4c 8d 5c b2 fd       	lea    -0x3(%rdx,%rsi,4),%r11
    1d9c:	e9 bc fe ff ff       	jmp    1c5d <_mi_page_free_or_reserve+0x15d>
    1da1:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    1da8:	00 00 00 00 
    1dac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000001db0 <_mi_page_unfull>:
    1db0:	48 8b 07             	mov    (%rdi),%rax
    1db3:	48 89 fa             	mov    %rdi,%rdx
    1db6:	48 89 fe             	mov    %rdi,%rsi
    1db9:	a8 01                	test   $0x1,%al
    1dbb:	75 03                	jne    1dc0 <_mi_page_unfull+0x10>
    1dbd:	c3                   	ret
    1dbe:	66 90                	xchg   %ax,%ax
    1dc0:	4c 8b 4f 38          	mov    0x38(%rdi),%r9
    1dc4:	4d 8d 81 60 0e 00 00 	lea    0xe60(%r9),%r8
    1dcb:	f0 48 0f ba 37 00    	lock btrq $0x0,(%rdi)
    1dd1:	73 19                	jae    1dec <_mi_page_unfull+0x3c>
    1dd3:	48 8b 47 38          	mov    0x38(%rdi),%rax
    1dd7:	48 85 c0             	test   %rax,%rax
    1dda:	74 10                	je     1dec <_mi_page_unfull+0x3c>
    1ddc:	0f b7 4f 36          	movzwl 0x36(%rdi),%ecx
    1de0:	48 0f af 4f 28       	imul   0x28(%rdi),%rcx
    1de5:	48 29 88 d0 00 00 00 	sub    %rcx,0xd0(%rax)
    1dec:	48 8b 02             	mov    (%rdx),%rax
    1def:	4c 89 c7             	mov    %r8,%rdi
    1df2:	a8 01                	test   $0x1,%al
    1df4:	75 40                	jne    1e36 <_mi_page_unfull+0x86>
    1df6:	66 83 7a 36 01       	cmpw   $0x1,0x36(%rdx)
    1dfb:	48 8b 42 28          	mov    0x28(%rdx),%rax
    1dff:	74 5f                	je     1e60 <_mi_page_unfull+0xb0>
    1e01:	48 8d 48 07          	lea    0x7(%rax),%rcx
    1e05:	48 89 c8             	mov    %rcx,%rax
    1e08:	48 c1 e8 03          	shr    $0x3,%rax
    1e0c:	48 83 f9 47          	cmp    $0x47,%rcx
    1e10:	0f 87 ba 00 00 00    	ja     1ed0 <_mi_page_unfull+0x120>
    1e16:	49 8d b9 40 05 00 00 	lea    0x540(%r9),%rdi
    1e1d:	48 83 f8 01          	cmp    $0x1,%rax
    1e21:	76 13                	jbe    1e36 <_mi_page_unfull+0x86>
    1e23:	48 8d 78 01          	lea    0x1(%rax),%rdi
    1e27:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
    1e2b:	48 83 c7 29          	add    $0x29,%rdi
    1e2f:	48 c1 e7 05          	shl    $0x5,%rdi
    1e33:	4c 01 cf             	add    %r9,%rdi
    1e36:	f0 48 0f ba 2e 00    	lock btsq $0x0,(%rsi)
    1e3c:	72 19                	jb     1e57 <_mi_page_unfull+0xa7>
    1e3e:	48 8b 42 38          	mov    0x38(%rdx),%rax
    1e42:	48 85 c0             	test   %rax,%rax
    1e45:	74 10                	je     1e57 <_mi_page_unfull+0xa7>
    1e47:	0f b7 4a 36          	movzwl 0x36(%rdx),%ecx
    1e4b:	48 0f af 4a 28       	imul   0x28(%rdx),%rcx
    1e50:	48 01 88 d0 00 00 00 	add    %rcx,0xd0(%rax)
    1e57:	4c 89 c6             	mov    %r8,%rsi
    1e5a:	e9 b1 e9 ff ff       	jmp    810 <mi_page_queue_enqueue_from_ex.constprop.0>
    1e5f:	90                   	nop
    1e60:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
    1e66:	77 58                	ja     1ec0 <_mi_page_unfull+0x110>
    1e68:	8b 4a 68             	mov    0x68(%rdx),%ecx
    1e6b:	83 e9 03             	sub    $0x3,%ecx
    1e6e:	83 f9 02             	cmp    $0x2,%ecx
    1e71:	76 3d                	jbe    1eb0 <_mi_page_unfull+0x100>
    1e73:	48 8d 48 07          	lea    0x7(%rax),%rcx
    1e77:	48 89 c8             	mov    %rcx,%rax
    1e7a:	48 c1 e8 03          	shr    $0x3,%rax
    1e7e:	48 83 f9 47          	cmp    $0x47,%rcx
    1e82:	76 92                	jbe    1e16 <_mi_page_unfull+0x66>
    1e84:	0f 1f 40 00          	nopl   0x0(%rax)
    1e88:	48 83 e8 01          	sub    $0x1,%rax
    1e8c:	48 0f bd f8          	bsr    %rax,%rdi
    1e90:	8d 4f fe             	lea    -0x2(%rdi),%ecx
    1e93:	48 d3 e8             	shr    %cl,%rax
    1e96:	83 e0 03             	and    $0x3,%eax
    1e99:	48 8d 7c b8 26       	lea    0x26(%rax,%rdi,4),%rdi
    1e9e:	48 c1 e7 05          	shl    $0x5,%rdi
    1ea2:	4c 01 cf             	add    %r9,%rdi
    1ea5:	eb 8f                	jmp    1e36 <_mi_page_unfull+0x86>
    1ea7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1eae:	00 00 
    1eb0:	48 39 52 58          	cmp    %rdx,0x58(%rdx)
    1eb4:	73 bd                	jae    1e73 <_mi_page_unfull+0xc3>
    1eb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    1ebd:	00 00 00 
    1ec0:	49 8d b9 40 0e 00 00 	lea    0xe40(%r9),%rdi
    1ec7:	e9 6a ff ff ff       	jmp    1e36 <_mi_page_unfull+0x86>
    1ecc:	0f 1f 40 00          	nopl   0x0(%rax)
    1ed0:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    1ed6:	76 b0                	jbe    1e88 <_mi_page_unfull+0xd8>
    1ed8:	eb e6                	jmp    1ec0 <_mi_page_unfull+0x110>
    1eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000001ee0 <_mi_page_free>:
    1ee0:	41 57                	push   %r15
    1ee2:	41 56                	push   %r14
    1ee4:	41 55                	push   %r13
    1ee6:	41 54                	push   %r12
    1ee8:	49 89 fc             	mov    %rdi,%r12
    1eeb:	55                   	push   %rbp
    1eec:	53                   	push   %rbx
    1eed:	48 89 f3             	mov    %rsi,%rbx
    1ef0:	48 83 ec 18          	sub    $0x18,%rsp
    1ef4:	f0 48 83 27 fd       	lock andq $0xfffffffffffffffd,(%rdi)
    1ef9:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    1efd:	48 8b 6f 38          	mov    0x38(%rdi),%rbp
    1f01:	48 85 d2             	test   %rdx,%rdx
    1f04:	74 08                	je     1f0e <_mi_page_free+0x2e>
    1f06:	48 8b 47 48          	mov    0x48(%rdi),%rax
    1f0a:	48 89 42 48          	mov    %rax,0x48(%rdx)
    1f0e:	48 8b 47 48          	mov    0x48(%rdi),%rax
    1f12:	48 85 c0             	test   %rax,%rax
    1f15:	74 04                	je     1f1b <_mi_page_free+0x3b>
    1f17:	48 89 50 50          	mov    %rdx,0x50(%rax)
    1f1b:	48 3b 7b 08          	cmp    0x8(%rbx),%rdi
    1f1f:	74 7f                	je     1fa0 <_mi_page_free+0xc0>
    1f21:	48 3b 3b             	cmp    (%rbx),%rdi
    1f24:	0f 84 87 00 00 00    	je     1fb1 <_mi_page_free+0xd1>
    1f2a:	48 83 ad b8 00 00 00 	subq   $0x1,0xb8(%rbp)
    1f31:	01 
    1f32:	66 0f ef c0          	pxor   %xmm0,%xmm0
    1f36:	48 83 6b 10 01       	subq   $0x1,0x10(%rbx)
    1f3b:	0f 11 47 48          	movups %xmm0,0x48(%rdi)
    1f3f:	f0 49 0f ba 34 24 00 	lock btrq $0x0,(%r12)
    1f46:	73 48                	jae    1f90 <_mi_page_free+0xb0>
    1f48:	48 8b 77 38          	mov    0x38(%rdi),%rsi
    1f4c:	48 85 f6             	test   %rsi,%rsi
    1f4f:	74 10                	je     1f61 <_mi_page_free+0x81>
    1f51:	0f b7 47 36          	movzwl 0x36(%rdi),%eax
    1f55:	48 0f af 47 28       	imul   0x28(%rdi),%rax
    1f5a:	48 29 86 d0 00 00 00 	sub    %rax,0xd0(%rsi)
    1f61:	48 c7 47 38 00 00 00 	movq   $0x0,0x38(%rdi)
    1f68:	00 
    1f69:	48 8b 07             	mov    (%rdi),%rax
    1f6c:	48 89 c2             	mov    %rax,%rdx
    1f6f:	83 e2 03             	and    $0x3,%edx
    1f72:	f0 48 0f b1 17       	lock cmpxchg %rdx,(%rdi)
    1f77:	75 f3                	jne    1f6c <_mi_page_free+0x8c>
    1f79:	48 83 c4 18          	add    $0x18,%rsp
    1f7d:	5b                   	pop    %rbx
    1f7e:	5d                   	pop    %rbp
    1f7f:	41 5c                	pop    %r12
    1f81:	41 5d                	pop    %r13
    1f83:	41 5e                	pop    %r14
    1f85:	41 5f                	pop    %r15
    1f87:	e9 00 00 00 00       	jmp    1f8c <_mi_page_free+0xac>
			1f88: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    1f8c:	0f 1f 40 00          	nopl   0x0(%rax)
    1f90:	48 8b 77 38          	mov    0x38(%rdi),%rsi
    1f94:	eb cb                	jmp    1f61 <_mi_page_free+0x81>
    1f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    1f9d:	00 00 00 
    1fa0:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    1fa4:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    1fa8:	48 3b 3b             	cmp    (%rbx),%rdi
    1fab:	0f 85 79 ff ff ff    	jne    1f2a <_mi_page_free+0x4a>
    1fb1:	4c 8b 6b 18          	mov    0x18(%rbx),%r13
    1fb5:	48 89 03             	mov    %rax,(%rbx)
    1fb8:	49 81 fd 00 04 00 00 	cmp    $0x400,%r13
    1fbf:	0f 87 65 ff ff ff    	ja     1f2a <_mi_page_free+0x4a>
    1fc5:	48 85 c0             	test   %rax,%rax
    1fc8:	0f 84 5a 01 00 00    	je     2128 <_mi_page_free+0x248>
    1fce:	4d 8d 45 07          	lea    0x7(%r13),%r8
    1fd2:	4c 8d 8d 18 01 00 00 	lea    0x118(%rbp),%r9
    1fd9:	49 c1 e8 03          	shr    $0x3,%r8
    1fdd:	4a 39 84 c5 18 01 00 	cmp    %rax,0x118(%rbp,%r8,8)
    1fe4:	00 
    1fe5:	0f 84 3f ff ff ff    	je     1f2a <_mi_page_free+0x4a>
    1feb:	49 83 f8 01          	cmp    $0x1,%r8
    1fef:	0f 86 23 01 00 00    	jbe    2118 <_mi_page_free+0x238>
    1ff5:	49 83 f8 08          	cmp    $0x8,%r8
    1ff9:	0f 87 3d 01 00 00    	ja     213c <_mi_page_free+0x25c>
    1fff:	4d 8d 50 01          	lea    0x1(%r8),%r10
    2003:	4d 89 d5             	mov    %r10,%r13
    2006:	49 83 e5 fe          	and    $0xfffffffffffffffe,%r13
    200a:	48 8d 73 e0          	lea    -0x20(%rbx),%rsi
    200e:	4c 8d 9d 20 05 00 00 	lea    0x520(%rbp),%r11
    2015:	eb 1f                	jmp    2036 <_mi_page_free+0x156>
    2017:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    201e:	00 00 
    2020:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
    2024:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
    2028:	49 39 cd             	cmp    %rcx,%r13
    202b:	75 28                	jne    2055 <_mi_page_free+0x175>
    202d:	49 39 f3             	cmp    %rsi,%r11
    2030:	73 23                	jae    2055 <_mi_page_free+0x175>
    2032:	48 83 ee 20          	sub    $0x20,%rsi
    2036:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
    203a:	48 83 c1 07          	add    $0x7,%rcx
    203e:	48 89 ca             	mov    %rcx,%rdx
    2041:	48 c1 ea 03          	shr    $0x3,%rdx
    2045:	48 83 f9 47          	cmp    $0x47,%rcx
    2049:	0f 87 99 00 00 00    	ja     20e8 <_mi_page_free+0x208>
    204f:	48 83 fa 01          	cmp    $0x1,%rdx
    2053:	77 cb                	ja     2020 <_mi_page_free+0x140>
    2055:	48 83 c2 01          	add    $0x1,%rdx
    2059:	4c 39 c2             	cmp    %r8,%rdx
    205c:	49 0f 47 d0          	cmova  %r8,%rdx
    2060:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
    2064:	4c 89 d6             	mov    %r10,%rsi
    2067:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    206d:	48 29 d6             	sub    %rdx,%rsi
    2070:	49 39 ca             	cmp    %rcx,%r10
    2073:	49 0f 42 f3          	cmovb  %r11,%rsi
    2077:	49 39 d0             	cmp    %rdx,%r8
    207a:	74 5d                	je     20d9 <_mi_page_free+0x1f9>
    207c:	49 39 ca             	cmp    %rcx,%r10
    207f:	72 58                	jb     20d9 <_mi_page_free+0x1f9>
    2081:	49 89 f0             	mov    %rsi,%r8
    2084:	48 8d 8c d5 18 01 00 	lea    0x118(%rbp,%rdx,8),%rcx
    208b:	00 
    208c:	66 48 0f 6e c0       	movq   %rax,%xmm0
    2091:	49 d1 e8             	shr    $1,%r8
    2094:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    2098:	49 c1 e0 04          	shl    $0x4,%r8
    209c:	4d 8d 14 08          	lea    (%r8,%rcx,1),%r10
    20a0:	41 83 e0 10          	and    $0x10,%r8d
    20a4:	74 12                	je     20b8 <_mi_page_free+0x1d8>
    20a6:	0f 11 01             	movups %xmm0,(%rcx)
    20a9:	48 83 c1 10          	add    $0x10,%rcx
    20ad:	4c 39 d1             	cmp    %r10,%rcx
    20b0:	74 16                	je     20c8 <_mi_page_free+0x1e8>
    20b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    20b8:	0f 11 01             	movups %xmm0,(%rcx)
    20bb:	48 83 c1 20          	add    $0x20,%rcx
    20bf:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
    20c3:	4c 39 d1             	cmp    %r10,%rcx
    20c6:	75 f0                	jne    20b8 <_mi_page_free+0x1d8>
    20c8:	40 f6 c6 01          	test   $0x1,%sil
    20cc:	0f 84 58 fe ff ff    	je     1f2a <_mi_page_free+0x4a>
    20d2:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
    20d6:	48 01 f2             	add    %rsi,%rdx
    20d9:	49 89 04 d1          	mov    %rax,(%r9,%rdx,8)
    20dd:	e9 48 fe ff ff       	jmp    1f2a <_mi_page_free+0x4a>
    20e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    20e8:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
    20ef:	0f 87 60 ff ff ff    	ja     2055 <_mi_page_free+0x175>
    20f5:	4c 8d 72 ff          	lea    -0x1(%rdx),%r14
    20f9:	4d 0f bd fe          	bsr    %r14,%r15
    20fd:	41 8d 4f fe          	lea    -0x2(%r15),%ecx
    2101:	49 d3 ee             	shr    %cl,%r14
    2104:	41 83 e6 03          	and    $0x3,%r14d
    2108:	4b 8d 4c be fd       	lea    -0x3(%r14,%r15,4),%rcx
    210d:	e9 16 ff ff ff       	jmp    2028 <_mi_page_free+0x148>
    2112:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2118:	31 d2                	xor    %edx,%edx
    211a:	4d 8d 50 01          	lea    0x1(%r8),%r10
    211e:	e9 3d ff ff ff       	jmp    2060 <_mi_page_free+0x180>
    2123:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2128:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    212d:	e8 00 00 00 00       	call   2132 <_mi_page_free+0x252>
			212e: R_X86_64_PLT32	_mi_page_empty_get-0x4
    2132:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    2137:	e9 92 fe ff ff       	jmp    1fce <_mi_page_free+0xee>
    213c:	49 8d 50 ff          	lea    -0x1(%r8),%rdx
    2140:	4d 8d 50 01          	lea    0x1(%r8),%r10
    2144:	48 0f bd f2          	bsr    %rdx,%rsi
    2148:	8d 4e fe             	lea    -0x2(%rsi),%ecx
    214b:	48 d3 ea             	shr    %cl,%rdx
    214e:	83 e2 03             	and    $0x3,%edx
    2151:	4c 8d 6c b2 fd       	lea    -0x3(%rdx,%rsi,4),%r13
    2156:	e9 af fe ff ff       	jmp    200a <_mi_page_free+0x12a>
    215b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000002160 <_mi_page_retire>:
    2160:	80 7f 16 00          	cmpb   $0x0,0x16(%rdi)
    2164:	74 0a                	je     2170 <_mi_page_retire+0x10>
    2166:	c3                   	ret
    2167:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    216e:	00 00 
    2170:	41 54                	push   %r12
    2172:	55                   	push   %rbp
    2173:	53                   	push   %rbx
    2174:	48 89 fb             	mov    %rdi,%rbx
    2177:	f0 48 83 27 fd       	lock andq $0xfffffffffffffffd,(%rdi)
    217c:	4c 8b 67 38          	mov    0x38(%rdi),%r12
    2180:	48 8b 07             	mov    (%rdi),%rax
    2183:	48 8b 57 28          	mov    0x28(%rdi),%rdx
    2187:	a8 01                	test   $0x1,%al
    2189:	0f 85 a1 00 00 00    	jne    2230 <_mi_page_retire+0xd0>
    218f:	66 83 7f 36 01       	cmpw   $0x1,0x36(%rdi)
    2194:	0f 84 fe 00 00 00    	je     2298 <_mi_page_retire+0x138>
    219a:	48 8d 4a 07          	lea    0x7(%rdx),%rcx
    219e:	48 89 c8             	mov    %rcx,%rax
    21a1:	48 c1 e8 03          	shr    $0x3,%rax
    21a5:	48 83 f9 47          	cmp    $0x47,%rcx
    21a9:	0f 87 61 01 00 00    	ja     2310 <_mi_page_retire+0x1b0>
    21af:	48 83 f8 01          	cmp    $0x1,%rax
    21b3:	76 6b                	jbe    2220 <_mi_page_retire+0xc0>
    21b5:	48 83 c0 01          	add    $0x1,%rax
    21b9:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    21bd:	48 8d 68 29          	lea    0x29(%rax),%rbp
    21c1:	48 c1 e5 05          	shl    $0x5,%rbp
    21c5:	48 c1 e0 05          	shl    $0x5,%rax
    21c9:	4c 01 e5             	add    %r12,%rbp
    21cc:	4c 01 e0             	add    %r12,%rax
    21cf:	48 81 b8 38 05 00 00 	cmpq   $0x80000,0x538(%rax)
    21d6:	00 00 08 00 
    21da:	77 09                	ja     21e5 <_mi_page_retire+0x85>
    21dc:	48 39 98 28 05 00 00 	cmp    %rbx,0x528(%rax)
    21e3:	74 5b                	je     2240 <_mi_page_retire+0xe0>
    21e5:	f0 48 83 23 fd       	lock andq $0xfffffffffffffffd,(%rbx)
    21ea:	48 89 de             	mov    %rbx,%rsi
    21ed:	48 89 ef             	mov    %rbp,%rdi
    21f0:	e8 eb e3 ff ff       	call   5e0 <mi_page_queue_remove>
    21f5:	48 8b 73 38          	mov    0x38(%rbx),%rsi
    21f9:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    2200:	00 
    2201:	48 8b 03             	mov    (%rbx),%rax
    2204:	48 89 c2             	mov    %rax,%rdx
    2207:	83 e2 03             	and    $0x3,%edx
    220a:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    220f:	75 f3                	jne    2204 <_mi_page_retire+0xa4>
    2211:	48 89 df             	mov    %rbx,%rdi
    2214:	5b                   	pop    %rbx
    2215:	5d                   	pop    %rbp
    2216:	41 5c                	pop    %r12
    2218:	e9 00 00 00 00       	jmp    221d <_mi_page_retire+0xbd>
			2219: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    221d:	0f 1f 00             	nopl   (%rax)
    2220:	bd 40 05 00 00       	mov    $0x540,%ebp
    2225:	b8 01 00 00 00       	mov    $0x1,%eax
    222a:	eb 99                	jmp    21c5 <_mi_page_retire+0x65>
    222c:	0f 1f 40 00          	nopl   0x0(%rax)
    2230:	bd 60 0e 00 00       	mov    $0xe60,%ebp
    2235:	b8 4a 00 00 00       	mov    $0x4a,%eax
    223a:	eb 89                	jmp    21c5 <_mi_page_retire+0x65>
    223c:	0f 1f 40 00          	nopl   0x0(%rax)
    2240:	48 39 98 20 05 00 00 	cmp    %rbx,0x520(%rax)
    2247:	75 9c                	jne    21e5 <_mi_page_retire+0x85>
    2249:	48 81 fa 00 28 00 00 	cmp    $0x2800,%rdx
    2250:	0f 87 ca 00 00 00    	ja     2320 <_mi_page_retire+0x1c0>
    2256:	c6 43 16 10          	movb   $0x10,0x16(%rbx)
    225a:	49 8d 84 24 20 05 00 	lea    0x520(%r12),%rax
    2261:	00 
    2262:	48 29 c5             	sub    %rax,%rbp
    2265:	48 c1 fd 05          	sar    $0x5,%rbp
    2269:	49 3b ac 24 c0 00 00 	cmp    0xc0(%r12),%rbp
    2270:	00 
    2271:	73 08                	jae    227b <_mi_page_retire+0x11b>
    2273:	49 89 ac 24 c0 00 00 	mov    %rbp,0xc0(%r12)
    227a:	00 
    227b:	49 39 ac 24 c8 00 00 	cmp    %rbp,0xc8(%r12)
    2282:	00 
    2283:	73 08                	jae    228d <_mi_page_retire+0x12d>
    2285:	49 89 ac 24 c8 00 00 	mov    %rbp,0xc8(%r12)
    228c:	00 
    228d:	5b                   	pop    %rbx
    228e:	5d                   	pop    %rbp
    228f:	41 5c                	pop    %r12
    2291:	c3                   	ret
    2292:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2298:	48 81 fa 00 00 08 00 	cmp    $0x80000,%rdx
    229f:	77 5f                	ja     2300 <_mi_page_retire+0x1a0>
    22a1:	8b 47 68             	mov    0x68(%rdi),%eax
    22a4:	83 e8 03             	sub    $0x3,%eax
    22a7:	83 f8 02             	cmp    $0x2,%eax
    22aa:	76 44                	jbe    22f0 <_mi_page_retire+0x190>
    22ac:	48 8d 4a 07          	lea    0x7(%rdx),%rcx
    22b0:	48 89 c8             	mov    %rcx,%rax
    22b3:	48 c1 e8 03          	shr    $0x3,%rax
    22b7:	48 83 f9 47          	cmp    $0x47,%rcx
    22bb:	0f 86 ee fe ff ff    	jbe    21af <_mi_page_retire+0x4f>
    22c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    22c8:	48 83 e8 01          	sub    $0x1,%rax
    22cc:	48 0f bd f0          	bsr    %rax,%rsi
    22d0:	8d 4e fe             	lea    -0x2(%rsi),%ecx
    22d3:	48 d3 e8             	shr    %cl,%rax
    22d6:	83 e0 03             	and    $0x3,%eax
    22d9:	48 8d 44 b0 fd       	lea    -0x3(%rax,%rsi,4),%rax
    22de:	48 8d 68 29          	lea    0x29(%rax),%rbp
    22e2:	48 c1 e5 05          	shl    $0x5,%rbp
    22e6:	e9 da fe ff ff       	jmp    21c5 <_mi_page_retire+0x65>
    22eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    22f0:	48 39 7f 58          	cmp    %rdi,0x58(%rdi)
    22f4:	73 b6                	jae    22ac <_mi_page_retire+0x14c>
    22f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    22fd:	00 00 00 
    2300:	bd 40 0e 00 00       	mov    $0xe40,%ebp
    2305:	b8 49 00 00 00       	mov    $0x49,%eax
    230a:	e9 b6 fe ff ff       	jmp    21c5 <_mi_page_retire+0x65>
    230f:	90                   	nop
    2310:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    2316:	76 b0                	jbe    22c8 <_mi_page_retire+0x168>
    2318:	eb e6                	jmp    2300 <_mi_page_retire+0x1a0>
    231a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2320:	c6 43 16 04          	movb   $0x4,0x16(%rbx)
    2324:	48 81 fa aa 52 01 00 	cmp    $0x152aa,%rdx
    232b:	0f 86 29 ff ff ff    	jbe    225a <_mi_page_retire+0xfa>
    2331:	48 89 df             	mov    %rbx,%rdi
    2334:	e8 00 00 00 00       	call   2339 <_mi_page_retire+0x1d9>
			2335: R_X86_64_PLT32	_mi_page_publish_retired-0x4
    2339:	e9 1c ff ff ff       	jmp    225a <_mi_page_retire+0xfa>
    233e:	66 90                	xchg   %ax,%ax

0000000000002340 <_mi_theap_collect_retired>:
    2340:	41 57                	push   %r15
    2342:	41 56                	push   %r14
    2344:	41 55                	push   %r13
    2346:	49 89 fd             	mov    %rdi,%r13
    2349:	41 54                	push   %r12
    234b:	55                   	push   %rbp
    234c:	53                   	push   %rbx
    234d:	48 83 ec 18          	sub    $0x18,%rsp
    2351:	4c 8b a7 c0 00 00 00 	mov    0xc0(%rdi),%r12
    2358:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    235f:	40 88 74 24 0f       	mov    %sil,0xf(%rsp)
    2364:	4c 39 e2             	cmp    %r12,%rdx
    2367:	0f 82 ab 02 00 00    	jb     2618 <_mi_theap_collect_retired+0x2d8>
    236d:	49 8d 6c 24 29       	lea    0x29(%r12),%rbp
    2372:	45 31 f6             	xor    %r14d,%r14d
    2375:	41 bf 4a 00 00 00    	mov    $0x4a,%r15d
    237b:	48 c1 e5 05          	shl    $0x5,%rbp
    237f:	48 01 fd             	add    %rdi,%rbp
    2382:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2388:	48 8b 5d 00          	mov    0x0(%rbp),%rbx
    238c:	48 85 db             	test   %rbx,%rbx
    238f:	0f 84 bb 00 00 00    	je     2450 <_mi_theap_collect_retired+0x110>
    2395:	0f b6 43 16          	movzbl 0x16(%rbx),%eax
    2399:	84 c0                	test   %al,%al
    239b:	0f 84 af 00 00 00    	je     2450 <_mi_theap_collect_retired+0x110>
    23a1:	8b 4b 10             	mov    0x10(%rbx),%ecx
    23a4:	85 c9                	test   %ecx,%ecx
    23a6:	0f 85 c4 00 00 00    	jne    2470 <_mi_theap_collect_retired+0x130>
    23ac:	83 e8 01             	sub    $0x1,%eax
    23af:	88 43 16             	mov    %al,0x16(%rbx)
    23b2:	84 c0                	test   %al,%al
    23b4:	74 5a                	je     2410 <_mi_theap_collect_retired+0xd0>
    23b6:	80 7c 24 0f 00       	cmpb   $0x0,0xf(%rsp)
    23bb:	75 53                	jne    2410 <_mi_theap_collect_retired+0xd0>
    23bd:	4d 39 e7             	cmp    %r12,%r15
    23c0:	4d 0f 47 fc          	cmova  %r12,%r15
    23c4:	4d 39 e6             	cmp    %r12,%r14
    23c7:	4d 0f 42 f4          	cmovb  %r12,%r14
    23cb:	49 83 c4 01          	add    $0x1,%r12
    23cf:	48 83 c5 20          	add    $0x20,%rbp
    23d3:	4c 39 e2             	cmp    %r12,%rdx
    23d6:	73 b0                	jae    2388 <_mi_theap_collect_retired+0x48>
    23d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    23df:	00 
    23e0:	41 80 bd 11 01 00 00 	cmpb   $0x0,0x111(%r13)
    23e7:	00 
    23e8:	4d 89 bd c0 00 00 00 	mov    %r15,0xc0(%r13)
    23ef:	4d 89 b5 c8 00 00 00 	mov    %r14,0xc8(%r13)
    23f6:	0f 84 84 00 00 00    	je     2480 <_mi_theap_collect_retired+0x140>
    23fc:	48 83 c4 18          	add    $0x18,%rsp
    2400:	5b                   	pop    %rbx
    2401:	5d                   	pop    %rbp
    2402:	41 5c                	pop    %r12
    2404:	41 5d                	pop    %r13
    2406:	41 5e                	pop    %r14
    2408:	41 5f                	pop    %r15
    240a:	c3                   	ret
    240b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2410:	f0 48 83 23 fd       	lock andq $0xfffffffffffffffd,(%rbx)
    2415:	48 89 de             	mov    %rbx,%rsi
    2418:	48 89 ef             	mov    %rbp,%rdi
    241b:	e8 c0 e1 ff ff       	call   5e0 <mi_page_queue_remove>
    2420:	48 8b 73 38          	mov    0x38(%rbx),%rsi
    2424:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    242b:	00 
    242c:	48 8b 03             	mov    (%rbx),%rax
    242f:	48 89 c2             	mov    %rax,%rdx
    2432:	83 e2 03             	and    $0x3,%edx
    2435:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    243a:	75 f3                	jne    242f <_mi_theap_collect_retired+0xef>
    243c:	48 89 df             	mov    %rbx,%rdi
    243f:	e8 00 00 00 00       	call   2444 <_mi_theap_collect_retired+0x104>
			2440: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    2444:	49 8b 95 c8 00 00 00 	mov    0xc8(%r13),%rdx
    244b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2450:	49 83 c4 01          	add    $0x1,%r12
    2454:	48 83 c5 20          	add    $0x20,%rbp
    2458:	4c 39 e2             	cmp    %r12,%rdx
    245b:	0f 83 27 ff ff ff    	jae    2388 <_mi_theap_collect_retired+0x48>
    2461:	e9 7a ff ff ff       	jmp    23e0 <_mi_theap_collect_retired+0xa0>
    2466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    246d:	00 00 00 
    2470:	c6 43 16 00          	movb   $0x0,0x16(%rbx)
    2474:	eb da                	jmp    2450 <_mi_theap_collect_retired+0x110>
    2476:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    247d:	00 00 00 
    2480:	4d 8b a5 60 0e 00 00 	mov    0xe60(%r13),%r12
    2487:	49 8d 9d 60 0e 00 00 	lea    0xe60(%r13),%rbx
    248e:	66 90                	xchg   %ax,%ax
    2490:	4d 85 e4             	test   %r12,%r12
    2493:	0f 84 63 ff ff ff    	je     23fc <_mi_theap_collect_retired+0xbc>
    2499:	4c 89 e5             	mov    %r12,%rbp
    249c:	31 f6                	xor    %esi,%esi
    249e:	4d 8b 64 24 48       	mov    0x48(%r12),%r12
    24a3:	48 89 ef             	mov    %rbp,%rdi
    24a6:	e8 75 dd ff ff       	call   220 <mi_page_free_collect_ex.constprop.0>
    24ab:	8b 45 10             	mov    0x10(%rbp),%eax
    24ae:	0f b7 55 36          	movzwl 0x36(%rbp),%edx
    24b2:	39 c2                	cmp    %eax,%edx
    24b4:	74 da                	je     2490 <_mi_theap_collect_retired+0x150>
    24b6:	85 c0                	test   %eax,%eax
    24b8:	75 46                	jne    2500 <_mi_theap_collect_retired+0x1c0>
    24ba:	f0 48 83 65 00 fd    	lock andq $0xfffffffffffffffd,0x0(%rbp)
    24c0:	48 89 ee             	mov    %rbp,%rsi
    24c3:	48 89 df             	mov    %rbx,%rdi
    24c6:	e8 15 e1 ff ff       	call   5e0 <mi_page_queue_remove>
    24cb:	48 8b 75 38          	mov    0x38(%rbp),%rsi
    24cf:	48 c7 45 38 00 00 00 	movq   $0x0,0x38(%rbp)
    24d6:	00 
    24d7:	48 8b 45 00          	mov    0x0(%rbp),%rax
    24db:	48 89 c2             	mov    %rax,%rdx
    24de:	83 e2 03             	and    $0x3,%edx
    24e1:	f0 48 0f b1 55 00    	lock cmpxchg %rdx,0x0(%rbp)
    24e7:	75 f2                	jne    24db <_mi_theap_collect_retired+0x19b>
    24e9:	48 89 ef             	mov    %rbp,%rdi
    24ec:	e8 00 00 00 00       	call   24f1 <_mi_theap_collect_retired+0x1b1>
			24ed: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    24f1:	4d 85 e4             	test   %r12,%r12
    24f4:	75 a3                	jne    2499 <_mi_theap_collect_retired+0x159>
    24f6:	e9 01 ff ff ff       	jmp    23fc <_mi_theap_collect_retired+0xbc>
    24fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2500:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2504:	48 89 ea             	mov    %rbp,%rdx
    2507:	a8 01                	test   $0x1,%al
    2509:	74 85                	je     2490 <_mi_theap_collect_retired+0x150>
    250b:	4c 8b 45 38          	mov    0x38(%rbp),%r8
    250f:	49 8d b0 60 0e 00 00 	lea    0xe60(%r8),%rsi
    2516:	f0 48 0f ba 75 00 00 	lock btrq $0x0,0x0(%rbp)
    251d:	73 19                	jae    2538 <_mi_theap_collect_retired+0x1f8>
    251f:	48 8b 45 38          	mov    0x38(%rbp),%rax
    2523:	48 85 c0             	test   %rax,%rax
    2526:	74 10                	je     2538 <_mi_theap_collect_retired+0x1f8>
    2528:	0f b7 4d 36          	movzwl 0x36(%rbp),%ecx
    252c:	48 0f af 4d 28       	imul   0x28(%rbp),%rcx
    2531:	48 29 88 d0 00 00 00 	sub    %rcx,0xd0(%rax)
    2538:	48 8b 45 00          	mov    0x0(%rbp),%rax
    253c:	48 89 f7             	mov    %rsi,%rdi
    253f:	a8 01                	test   $0x1,%al
    2541:	75 43                	jne    2586 <_mi_theap_collect_retired+0x246>
    2543:	66 83 7d 36 01       	cmpw   $0x1,0x36(%rbp)
    2548:	48 8b 45 28          	mov    0x28(%rbp),%rax
    254c:	74 6a                	je     25b8 <_mi_theap_collect_retired+0x278>
    254e:	48 8d 48 07          	lea    0x7(%rax),%rcx
    2552:	48 89 c8             	mov    %rcx,%rax
    2555:	48 c1 e8 03          	shr    $0x3,%rax
    2559:	48 83 f9 47          	cmp    $0x47,%rcx
    255d:	0f 87 9e 00 00 00    	ja     2601 <_mi_theap_collect_retired+0x2c1>
    2563:	49 8d b8 40 05 00 00 	lea    0x540(%r8),%rdi
    256a:	48 83 f8 01          	cmp    $0x1,%rax
    256e:	76 16                	jbe    2586 <_mi_theap_collect_retired+0x246>
    2570:	48 8d 78 01          	lea    0x1(%rax),%rdi
    2574:	48 89 f8             	mov    %rdi,%rax
    2577:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    257b:	48 8d 78 29          	lea    0x29(%rax),%rdi
    257f:	48 c1 e7 05          	shl    $0x5,%rdi
    2583:	4c 01 c7             	add    %r8,%rdi
    2586:	f0 48 0f ba 2a 00    	lock btsq $0x0,(%rdx)
    258c:	72 19                	jb     25a7 <_mi_theap_collect_retired+0x267>
    258e:	48 8b 45 38          	mov    0x38(%rbp),%rax
    2592:	48 85 c0             	test   %rax,%rax
    2595:	74 10                	je     25a7 <_mi_theap_collect_retired+0x267>
    2597:	0f b7 55 36          	movzwl 0x36(%rbp),%edx
    259b:	48 0f af 55 28       	imul   0x28(%rbp),%rdx
    25a0:	48 01 90 d0 00 00 00 	add    %rdx,0xd0(%rax)
    25a7:	48 89 ea             	mov    %rbp,%rdx
    25aa:	e8 61 e2 ff ff       	call   810 <mi_page_queue_enqueue_from_ex.constprop.0>
    25af:	e9 dc fe ff ff       	jmp    2490 <_mi_theap_collect_retired+0x150>
    25b4:	0f 1f 40 00          	nopl   0x0(%rax)
    25b8:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
    25be:	77 49                	ja     2609 <_mi_theap_collect_retired+0x2c9>
    25c0:	8b 4d 68             	mov    0x68(%rbp),%ecx
    25c3:	83 e9 03             	sub    $0x3,%ecx
    25c6:	83 f9 02             	cmp    $0x2,%ecx
    25c9:	77 06                	ja     25d1 <_mi_theap_collect_retired+0x291>
    25cb:	48 39 6d 58          	cmp    %rbp,0x58(%rbp)
    25cf:	72 38                	jb     2609 <_mi_theap_collect_retired+0x2c9>
    25d1:	48 8d 48 07          	lea    0x7(%rax),%rcx
    25d5:	48 89 c8             	mov    %rcx,%rax
    25d8:	48 c1 e8 03          	shr    $0x3,%rax
    25dc:	48 83 f9 47          	cmp    $0x47,%rcx
    25e0:	76 81                	jbe    2563 <_mi_theap_collect_retired+0x223>
    25e2:	48 83 e8 01          	sub    $0x1,%rax
    25e6:	48 0f bd f8          	bsr    %rax,%rdi
    25ea:	8d 4f fe             	lea    -0x2(%rdi),%ecx
    25ed:	48 d3 e8             	shr    %cl,%rax
    25f0:	83 e0 03             	and    $0x3,%eax
    25f3:	48 8d 7c b8 26       	lea    0x26(%rax,%rdi,4),%rdi
    25f8:	48 c1 e7 05          	shl    $0x5,%rdi
    25fc:	4c 01 c7             	add    %r8,%rdi
    25ff:	eb 85                	jmp    2586 <_mi_theap_collect_retired+0x246>
    2601:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    2607:	76 d9                	jbe    25e2 <_mi_theap_collect_retired+0x2a2>
    2609:	49 8d b8 40 0e 00 00 	lea    0xe40(%r8),%rdi
    2610:	e9 71 ff ff ff       	jmp    2586 <_mi_theap_collect_retired+0x246>
    2615:	0f 1f 00             	nopl   (%rax)
    2618:	45 31 f6             	xor    %r14d,%r14d
    261b:	41 bf 4a 00 00 00    	mov    $0x4a,%r15d
    2621:	e9 ba fd ff ff       	jmp    23e0 <_mi_theap_collect_retired+0xa0>
    2626:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    262d:	00 00 00 

0000000000002630 <mi_page_queue_find_free_ex>:
    2630:	41 57                	push   %r15
    2632:	41 56                	push   %r14
    2634:	41 55                	push   %r13
    2636:	41 54                	push   %r12
    2638:	55                   	push   %rbp
    2639:	53                   	push   %rbx
    263a:	48 83 ec 28          	sub    $0x28,%rsp
    263e:	48 81 7e 18 00 28 00 	cmpq   $0x2800,0x18(%rsi)
    2645:	00 
    2646:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
    264b:	48 89 34 24          	mov    %rsi,(%rsp)
    264f:	89 54 24 1c          	mov    %edx,0x1c(%rsp)
    2653:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    265a:	00 00 
    265c:	77 0c                	ja     266a <mi_page_queue_find_free_ex+0x3a>
    265e:	48 8b 87 08 01 00 00 	mov    0x108(%rdi),%rax
    2665:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    266a:	48 8b 04 24          	mov    (%rsp),%rax
    266e:	4c 8b 28             	mov    (%rax),%r13
    2671:	4d 85 ed             	test   %r13,%r13
    2674:	0f 84 2e 03 00 00    	je     29a8 <mi_page_queue_find_free_ex+0x378>
    267a:	31 ed                	xor    %ebp,%ebp
    267c:	45 31 f6             	xor    %r14d,%r14d
    267f:	45 31 ff             	xor    %r15d,%r15d
    2682:	eb 37                	jmp    26bb <mi_page_queue_find_free_ex+0x8b>
    2684:	0f 1f 40 00          	nopl   0x0(%rax)
    2688:	8b 73 10             	mov    0x10(%rbx),%esi
    268b:	39 c6                	cmp    %eax,%esi
    268d:	72 15                	jb     26a4 <mi_page_queue_find_free_ex+0x74>
    268f:	0f b7 7b 36          	movzwl 0x36(%rbx),%edi
    2693:	89 f8                	mov    %edi,%eax
    2695:	29 f7                	sub    %esi,%edi
    2697:	66 c1 e8 03          	shr    $0x3,%ax
    269b:	0f b7 c0             	movzwl %ax,%eax
    269e:	39 f8                	cmp    %edi,%eax
    26a0:	48 0f 42 eb          	cmovb  %rbx,%rbp
    26a4:	4d 85 f6             	test   %r14,%r14
    26a7:	0f 8e 83 00 00 00    	jle    2730 <mi_page_queue_find_free_ex+0x100>
    26ad:	45 84 e4             	test   %r12b,%r12b
    26b0:	75 7e                	jne    2730 <mi_page_queue_find_free_ex+0x100>
    26b2:	4d 85 ed             	test   %r13,%r13
    26b5:	0f 84 85 01 00 00    	je     2840 <mi_page_queue_find_free_ex+0x210>
    26bb:	4c 89 eb             	mov    %r13,%rbx
    26be:	49 83 c7 01          	add    $0x1,%r15
    26c2:	49 83 ee 01          	sub    $0x1,%r14
    26c6:	4d 8b 6d 48          	mov    0x48(%r13),%r13
    26ca:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    26cf:	0f 84 cb 00 00 00    	je     27a0 <mi_page_queue_find_free_ex+0x170>
    26d5:	41 bc 01 00 00 00    	mov    $0x1,%r12d
    26db:	48 85 ed             	test   %rbp,%rbp
    26de:	0f 84 20 02 00 00    	je     2904 <mi_page_queue_find_free_ex+0x2d4>
    26e4:	8b 45 10             	mov    0x10(%rbp),%eax
    26e7:	85 c0                	test   %eax,%eax
    26e9:	75 9d                	jne    2688 <mi_page_queue_find_free_ex+0x58>
    26eb:	f0 48 83 65 00 fd    	lock andq $0xfffffffffffffffd,0x0(%rbp)
    26f1:	48 8b 3c 24          	mov    (%rsp),%rdi
    26f5:	48 89 ee             	mov    %rbp,%rsi
    26f8:	e8 e3 de ff ff       	call   5e0 <mi_page_queue_remove>
    26fd:	48 8b 75 38          	mov    0x38(%rbp),%rsi
    2701:	48 c7 45 38 00 00 00 	movq   $0x0,0x38(%rbp)
    2708:	00 
    2709:	48 8b 45 00          	mov    0x0(%rbp),%rax
    270d:	48 89 c7             	mov    %rax,%rdi
    2710:	83 e7 03             	and    $0x3,%edi
    2713:	f0 48 0f b1 7d 00    	lock cmpxchg %rdi,0x0(%rbp)
    2719:	75 f2                	jne    270d <mi_page_queue_find_free_ex+0xdd>
    271b:	48 89 ef             	mov    %rbp,%rdi
    271e:	48 89 dd             	mov    %rbx,%rbp
    2721:	e8 00 00 00 00       	call   2726 <mi_page_queue_find_free_ex+0xf6>
			2722: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    2726:	4d 85 f6             	test   %r14,%r14
    2729:	7f 82                	jg     26ad <mi_page_queue_find_free_ex+0x7d>
    272b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2730:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    2735:	4c 89 fe             	mov    %r15,%rsi
    2738:	48 8d bb f0 0f 00 00 	lea    0xff0(%rbx),%rdi
    273f:	e8 00 00 00 00       	call   2744 <mi_page_queue_find_free_ex+0x114>
			2740: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    2744:	48 8d bb f8 0f 00 00 	lea    0xff8(%rbx),%rdi
    274b:	be 01 00 00 00       	mov    $0x1,%esi
    2750:	e8 00 00 00 00       	call   2755 <mi_page_queue_find_free_ex+0x125>
			2751: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    2755:	48 83 7d 08 00       	cmpq   $0x0,0x8(%rbp)
    275a:	0f 84 f8 01 00 00    	je     2958 <mi_page_queue_find_free_ex+0x328>
    2760:	48 8b 1c 24          	mov    (%rsp),%rbx
    2764:	48 3b 2b             	cmp    (%rbx),%rbp
    2767:	74 1b                	je     2784 <mi_page_queue_find_free_ex+0x154>
    2769:	48 89 ee             	mov    %rbp,%rsi
    276c:	48 89 df             	mov    %rbx,%rdi
    276f:	e8 6c de ff ff       	call   5e0 <mi_page_queue_remove>
    2774:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2779:	48 89 ea             	mov    %rbp,%rdx
    277c:	48 89 de             	mov    %rbx,%rsi
    277f:	e8 0c dc ff ff       	call   390 <mi_page_queue_push>
    2784:	c6 45 16 00          	movb   $0x0,0x16(%rbp)
    2788:	48 83 c4 28          	add    $0x28,%rsp
    278c:	48 89 e8             	mov    %rbp,%rax
    278f:	5b                   	pop    %rbx
    2790:	5d                   	pop    %rbp
    2791:	41 5c                	pop    %r12
    2793:	41 5d                	pop    %r13
    2795:	41 5e                	pop    %r14
    2797:	41 5f                	pop    %r15
    2799:	c3                   	ret
    279a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    27a0:	31 f6                	xor    %esi,%esi
    27a2:	48 89 df             	mov    %rbx,%rdi
    27a5:	e8 76 da ff ff       	call   220 <mi_page_free_collect_ex.constprop.0>
    27aa:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    27af:	0f 85 20 ff ff ff    	jne    26d5 <mi_page_queue_find_free_ex+0xa5>
    27b5:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
    27b9:	66 39 43 14          	cmp    %ax,0x14(%rbx)
    27bd:	0f 82 35 01 00 00    	jb     28f8 <mi_page_queue_find_free_ex+0x2c8>
    27c3:	48 83 6c 24 08 01    	subq   $0x1,0x8(%rsp)
    27c9:	0f 89 e3 fe ff ff    	jns    26b2 <mi_page_queue_find_free_ex+0x82>
    27cf:	4c 8b 63 38          	mov    0x38(%rbx),%r12
    27d3:	48 89 de             	mov    %rbx,%rsi
    27d6:	4c 89 e7             	mov    %r12,%rdi
    27d9:	e8 00 00 00 00       	call   27de <mi_page_queue_find_free_ex+0x1ae>
			27da: R_X86_64_PLT32	_mi_large_span_on_full-0x4
    27de:	41 80 bc 24 11 01 00 	cmpb   $0x0,0x111(%r12)
    27e5:	00 00 
    27e7:	0f 84 33 01 00 00    	je     2920 <mi_page_queue_find_free_ex+0x2f0>
    27ed:	31 f6                	xor    %esi,%esi
    27ef:	48 89 df             	mov    %rbx,%rdi
    27f2:	e8 00 00 00 00       	call   27f7 <mi_page_queue_find_free_ex+0x1c7>
			27f3: R_X86_64_PLT32	_mi_page_free_collect_no_unpurge-0x4
    27f7:	8b 43 10             	mov    0x10(%rbx),%eax
    27fa:	85 c0                	test   %eax,%eax
    27fc:	0f 84 76 01 00 00    	je     2978 <mi_page_queue_find_free_ex+0x348>
    2802:	48 8b 3c 24          	mov    (%rsp),%rdi
    2806:	48 89 de             	mov    %rbx,%rsi
    2809:	e8 d2 dd ff ff       	call   5e0 <mi_page_queue_remove>
    280e:	48 8b 73 38          	mov    0x38(%rbx),%rsi
    2812:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    2819:	00 
    281a:	48 8b 03             	mov    (%rbx),%rax
    281d:	48 89 c2             	mov    %rax,%rdx
    2820:	83 e2 03             	and    $0x3,%edx
    2823:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    2828:	75 f3                	jne    281d <mi_page_queue_find_free_ex+0x1ed>
    282a:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    282e:	48 89 df             	mov    %rbx,%rdi
    2831:	e8 00 00 00 00       	call   2836 <mi_page_queue_find_free_ex+0x206>
			2832: R_X86_64_PLT32	_mi_arenas_page_abandon-0x4
    2836:	4d 85 ed             	test   %r13,%r13
    2839:	0f 85 7c fe ff ff    	jne    26bb <mi_page_queue_find_free_ex+0x8b>
    283f:	90                   	nop
    2840:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    2845:	4c 89 fe             	mov    %r15,%rsi
    2848:	48 8d bb f0 0f 00 00 	lea    0xff0(%rbx),%rdi
    284f:	e8 00 00 00 00       	call   2854 <mi_page_queue_find_free_ex+0x224>
			2850: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    2854:	48 8d bb f8 0f 00 00 	lea    0xff8(%rbx),%rdi
    285b:	be 01 00 00 00       	mov    $0x1,%esi
    2860:	e8 00 00 00 00       	call   2865 <mi_page_queue_find_free_ex+0x235>
			2861: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    2865:	48 85 ed             	test   %rbp,%rbp
    2868:	0f 85 e7 fe ff ff    	jne    2755 <mi_page_queue_find_free_ex+0x125>
    286e:	66 90                	xchg   %ax,%ax
    2870:	48 8b 04 24          	mov    (%rsp),%rax
    2874:	48 8b 50 18          	mov    0x18(%rax),%rdx
    2878:	48 8d 82 55 ad fe ff 	lea    -0x152ab(%rdx),%rax
    287f:	48 3d 55 ad 06 00    	cmp    $0x6ad55,%rax
    2885:	0f 87 04 01 00 00    	ja     298f <mi_page_queue_find_free_ex+0x35f>
    288b:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    2890:	48 8b 01             	mov    (%rcx),%rax
    2893:	48 8b 89 d8 00 00 00 	mov    0xd8(%rcx),%rcx
    289a:	89 ce                	mov    %ecx,%esi
    289c:	2b b0 f0 01 00 00    	sub    0x1f0(%rax),%esi
    28a2:	83 fe 03             	cmp    $0x3,%esi
    28a5:	0f 87 de 00 00 00    	ja     2989 <mi_page_queue_find_free_ex+0x359>
    28ab:	4c 8b 3c 24          	mov    (%rsp),%r15
    28af:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    28b4:	31 c9                	xor    %ecx,%ecx
    28b6:	4c 89 fe             	mov    %r15,%rsi
    28b9:	48 89 df             	mov    %rbx,%rdi
    28bc:	e8 ef ed ff ff       	call   16b0 <mi_page_fresh_alloc>
    28c1:	48 89 c5             	mov    %rax,%rbp
    28c4:	48 85 c0             	test   %rax,%rax
    28c7:	0f 85 bb fe ff ff    	jne    2788 <mi_page_queue_find_free_ex+0x158>
    28cd:	80 7c 24 1c 00       	cmpb   $0x0,0x1c(%rsp)
    28d2:	0f 84 b0 fe ff ff    	je     2788 <mi_page_queue_find_free_ex+0x158>
    28d8:	48 83 c4 28          	add    $0x28,%rsp
    28dc:	4c 89 fe             	mov    %r15,%rsi
    28df:	48 89 df             	mov    %rbx,%rdi
    28e2:	31 d2                	xor    %edx,%edx
    28e4:	5b                   	pop    %rbx
    28e5:	5d                   	pop    %rbp
    28e6:	41 5c                	pop    %r12
    28e8:	41 5d                	pop    %r13
    28ea:	41 5e                	pop    %r14
    28ec:	41 5f                	pop    %r15
    28ee:	e9 3d fd ff ff       	jmp    2630 <mi_page_queue_find_free_ex>
    28f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    28f8:	45 31 e4             	xor    %r12d,%r12d
    28fb:	48 85 ed             	test   %rbp,%rbp
    28fe:	0f 85 e0 fd ff ff    	jne    26e4 <mi_page_queue_find_free_ex+0xb4>
    2904:	bf 25 00 00 00       	mov    $0x25,%edi
    2909:	48 89 dd             	mov    %rbx,%rbp
    290c:	e8 00 00 00 00       	call   2911 <mi_page_queue_find_free_ex+0x2e1>
			290d: R_X86_64_PLT32	_mi_option_get_fast-0x4
    2911:	49 89 c6             	mov    %rax,%r14
    2914:	e9 8b fd ff ff       	jmp    26a4 <mi_page_queue_find_free_ex+0x74>
    2919:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2920:	48 8b 03             	mov    (%rbx),%rax
    2923:	a8 01                	test   $0x1,%al
    2925:	0f 85 87 fd ff ff    	jne    26b2 <mi_page_queue_find_free_ex+0x82>
    292b:	48 8b 43 38          	mov    0x38(%rbx),%rax
    292f:	48 8b 34 24          	mov    (%rsp),%rsi
    2933:	48 89 da             	mov    %rbx,%rdx
    2936:	48 8d b8 60 0e 00 00 	lea    0xe60(%rax),%rdi
    293d:	e8 ce de ff ff       	call   810 <mi_page_queue_enqueue_from_ex.constprop.0>
    2942:	31 f6                	xor    %esi,%esi
    2944:	48 89 df             	mov    %rbx,%rdi
    2947:	e8 d4 d8 ff ff       	call   220 <mi_page_free_collect_ex.constprop.0>
    294c:	e9 61 fd ff ff       	jmp    26b2 <mi_page_queue_find_free_ex+0x82>
    2951:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2958:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    295d:	48 89 ee             	mov    %rbp,%rsi
    2960:	e8 eb d6 ff ff       	call   50 <mi_page_extend_free>
    2965:	84 c0                	test   %al,%al
    2967:	0f 85 f3 fd ff ff    	jne    2760 <mi_page_queue_find_free_ex+0x130>
    296d:	e9 fe fe ff ff       	jmp    2870 <mi_page_queue_find_free_ex+0x240>
    2972:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2978:	48 8b 34 24          	mov    (%rsp),%rsi
    297c:	48 89 df             	mov    %rbx,%rdi
    297f:	e8 00 00 00 00       	call   2984 <mi_page_queue_find_free_ex+0x354>
			2980: R_X86_64_PLT32	_mi_page_free-0x4
    2984:	e9 29 fd ff ff       	jmp    26b2 <mi_page_queue_find_free_ex+0x82>
    2989:	89 88 f0 01 00 00    	mov    %ecx,0x1f0(%rax)
    298f:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    2994:	31 f6                	xor    %esi,%esi
    2996:	e8 00 00 00 00       	call   299b <mi_page_queue_find_free_ex+0x36b>
			2997: R_X86_64_PLT32	_mi_theap_collect_retired-0x4
    299b:	48 8b 04 24          	mov    (%rsp),%rax
    299f:	48 8b 50 18          	mov    0x18(%rax),%rdx
    29a3:	e9 03 ff ff ff       	jmp    28ab <mi_page_queue_find_free_ex+0x27b>
    29a8:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    29ad:	31 f6                	xor    %esi,%esi
    29af:	48 8d bb f0 0f 00 00 	lea    0xff0(%rbx),%rdi
    29b6:	e8 00 00 00 00       	call   29bb <mi_page_queue_find_free_ex+0x38b>
			29b7: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    29bb:	48 8d bb f8 0f 00 00 	lea    0xff8(%rbx),%rdi
    29c2:	be 01 00 00 00       	mov    $0x1,%esi
    29c7:	e8 00 00 00 00       	call   29cc <mi_page_queue_find_free_ex+0x39c>
			29c8: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    29cc:	e9 9f fe ff ff       	jmp    2870 <mi_page_queue_find_free_ex+0x240>
    29d1:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    29d8:	00 00 00 00 
    29dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000029e0 <mi_find_page>:
    29e0:	41 54                	push   %r12
    29e2:	55                   	push   %rbp
    29e3:	53                   	push   %rbx
    29e4:	48 89 fb             	mov    %rdi,%rbx
    29e7:	48 89 f7             	mov    %rsi,%rdi
    29ea:	48 83 ec 10          	sub    $0x10,%rsp
    29ee:	48 85 f6             	test   %rsi,%rsi
    29f1:	0f 88 a9 00 00 00    	js     2aa0 <mi_find_page+0xc0>
    29f7:	49 89 d4             	mov    %rdx,%r12
    29fa:	48 85 d2             	test   %rdx,%rdx
    29fd:	74 59                	je     2a58 <mi_find_page+0x78>
    29ff:	be 40 0e 00 00       	mov    $0xe40,%esi
    2a04:	b8 49 00 00 00       	mov    $0x49,%eax
    2a09:	48 89 c2             	mov    %rax,%rdx
    2a0c:	48 8d 2c 33          	lea    (%rbx,%rsi,1),%rbp
    2a10:	48 c1 e2 05          	shl    $0x5,%rdx
    2a14:	48 81 bc 13 38 05 00 	cmpq   $0x80008,0x538(%rbx,%rdx,1)
    2a1b:	00 08 00 08 00 
    2a20:	0f 84 ba 00 00 00    	je     2ae0 <mi_find_page+0x100>
    2a26:	48 c1 e0 05          	shl    $0x5,%rax
    2a2a:	48 8b 84 18 20 05 00 	mov    0x520(%rax,%rbx,1),%rax
    2a31:	00 
    2a32:	48 85 c0             	test   %rax,%rax
    2a35:	0f 84 8d 00 00 00    	je     2ac8 <mi_find_page+0xe8>
    2a3b:	48 83 78 08 00       	cmpq   $0x0,0x8(%rax)
    2a40:	0f 84 ea 00 00 00    	je     2b30 <mi_find_page+0x150>
    2a46:	c6 40 16 00          	movb   $0x0,0x16(%rax)
    2a4a:	48 83 c4 10          	add    $0x10,%rsp
    2a4e:	5b                   	pop    %rbx
    2a4f:	5d                   	pop    %rbp
    2a50:	41 5c                	pop    %r12
    2a52:	c3                   	ret
    2a53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2a58:	48 8d 56 07          	lea    0x7(%rsi),%rdx
    2a5c:	48 89 d0             	mov    %rdx,%rax
    2a5f:	48 c1 e8 03          	shr    $0x3,%rax
    2a63:	48 83 fa 47          	cmp    $0x47,%rdx
    2a67:	0f 87 e1 00 00 00    	ja     2b4e <mi_find_page+0x16e>
    2a6d:	48 83 f8 01          	cmp    $0x1,%rax
    2a71:	76 15                	jbe    2a88 <mi_find_page+0xa8>
    2a73:	48 83 c0 01          	add    $0x1,%rax
    2a77:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    2a7b:	48 8d 70 29          	lea    0x29(%rax),%rsi
    2a7f:	48 c1 e6 05          	shl    $0x5,%rsi
    2a83:	eb 84                	jmp    2a09 <mi_find_page+0x29>
    2a85:	0f 1f 00             	nopl   (%rax)
    2a88:	be 40 05 00 00       	mov    $0x540,%esi
    2a8d:	b8 01 00 00 00       	mov    $0x1,%eax
    2a92:	e9 72 ff ff ff       	jmp    2a09 <mi_find_page+0x29>
    2a97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2a9e:	00 00 
    2aa0:	48 89 f2             	mov    %rsi,%rdx
    2aa3:	31 c0                	xor    %eax,%eax
    2aa5:	bf 4b 00 00 00       	mov    $0x4b,%edi
    2aaa:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 2ab1 <mi_find_page+0xd1>
			2aad: R_X86_64_PC32	.LC2-0x4
    2ab1:	e8 00 00 00 00       	call   2ab6 <mi_find_page+0xd6>
			2ab2: R_X86_64_PLT32	_mi_error_message-0x4
    2ab6:	48 83 c4 10          	add    $0x10,%rsp
    2aba:	31 c0                	xor    %eax,%eax
    2abc:	5b                   	pop    %rbx
    2abd:	5d                   	pop    %rbp
    2abe:	41 5c                	pop    %r12
    2ac0:	c3                   	ret
    2ac1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2ac8:	48 83 c4 10          	add    $0x10,%rsp
    2acc:	48 89 ee             	mov    %rbp,%rsi
    2acf:	48 89 df             	mov    %rbx,%rdi
    2ad2:	ba 01 00 00 00       	mov    $0x1,%edx
    2ad7:	5b                   	pop    %rbx
    2ad8:	5d                   	pop    %rbp
    2ad9:	41 5c                	pop    %r12
    2adb:	e9 50 fb ff ff       	jmp    2630 <mi_page_queue_find_free_ex>
    2ae0:	e8 00 00 00 00       	call   2ae5 <mi_find_page+0x105>
			2ae1: R_X86_64_PLT32	_mi_os_good_alloc_size-0x4
    2ae5:	4c 89 e1             	mov    %r12,%rcx
    2ae8:	48 89 ee             	mov    %rbp,%rsi
    2aeb:	48 89 df             	mov    %rbx,%rdi
    2aee:	48 89 c2             	mov    %rax,%rdx
    2af1:	e8 ba eb ff ff       	call   16b0 <mi_page_fresh_alloc>
    2af6:	48 85 c0             	test   %rax,%rax
    2af9:	0f 84 4b ff ff ff    	je     2a4a <mi_find_page+0x6a>
    2aff:	48 8b 70 28          	mov    0x28(%rax),%rsi
    2b03:	48 8d bb 60 0f 00 00 	lea    0xf60(%rbx),%rdi
    2b0a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    2b0f:	e8 00 00 00 00       	call   2b14 <mi_find_page+0x134>
			2b10: R_X86_64_PLT32	__mi_stat_increase-0x4
    2b14:	48 8d bb c0 0f 00 00 	lea    0xfc0(%rbx),%rdi
    2b1b:	be 01 00 00 00       	mov    $0x1,%esi
    2b20:	e8 00 00 00 00       	call   2b25 <mi_find_page+0x145>
			2b21: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    2b25:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2b2a:	e9 1b ff ff ff       	jmp    2a4a <mi_find_page+0x6a>
    2b2f:	90                   	nop
    2b30:	48 8b 50 18          	mov    0x18(%rax),%rdx
    2b34:	48 85 d2             	test   %rdx,%rdx
    2b37:	74 8f                	je     2ac8 <mi_find_page+0xe8>
    2b39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    2b3d:	48 c7 40 18 00 00 00 	movq   $0x0,0x18(%rax)
    2b44:	00 
    2b45:	c6 40 17 00          	movb   $0x0,0x17(%rax)
    2b49:	e9 f8 fe ff ff       	jmp    2a46 <mi_find_page+0x66>
    2b4e:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    2b54:	0f 87 a5 fe ff ff    	ja     29ff <mi_find_page+0x1f>
    2b5a:	48 83 e8 01          	sub    $0x1,%rax
    2b5e:	48 0f bd d0          	bsr    %rax,%rdx
    2b62:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    2b65:	48 d3 e8             	shr    %cl,%rax
    2b68:	83 e0 03             	and    $0x3,%eax
    2b6b:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
    2b70:	48 8d 70 29          	lea    0x29(%rax),%rsi
    2b74:	48 c1 e6 05          	shl    $0x5,%rsi
    2b78:	e9 8c fe ff ff       	jmp    2a09 <mi_find_page+0x29>
    2b7d:	0f 1f 00             	nopl   (%rax)

0000000000002b80 <mi_malloc_generic_fallback>:
    2b80:	41 57                	push   %r15
    2b82:	49 89 cf             	mov    %rcx,%r15
    2b85:	41 56                	push   %r14
    2b87:	49 89 f6             	mov    %rsi,%r14
    2b8a:	41 55                	push   %r13
    2b8c:	4d 89 c5             	mov    %r8,%r13
    2b8f:	41 54                	push   %r12
    2b91:	41 89 d4             	mov    %edx,%r12d
    2b94:	55                   	push   %rbp
    2b95:	53                   	push   %rbx
    2b96:	48 83 ec 08          	sub    $0x8,%rsp
    2b9a:	48 85 ff             	test   %rdi,%rdi
    2b9d:	0f 84 89 00 00 00    	je     2c2c <mi_malloc_generic_fallback+0xac>
    2ba3:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ba7:	48 89 fb             	mov    %rdi,%rbx
    2baa:	48 85 c0             	test   %rax,%rax
    2bad:	74 71                	je     2c20 <mi_malloc_generic_fallback+0xa0>
    2baf:	48 8b 83 d8 00 00 00 	mov    0xd8(%rbx),%rax
    2bb6:	48 3d e7 03 00 00    	cmp    $0x3e7,%rax
    2bbc:	0f 8f 26 01 00 00    	jg     2ce8 <mi_malloc_generic_fallback+0x168>
    2bc2:	4c 89 fa             	mov    %r15,%rdx
    2bc5:	4c 89 f6             	mov    %r14,%rsi
    2bc8:	48 89 df             	mov    %rbx,%rdi
    2bcb:	e8 10 fe ff ff       	call   29e0 <mi_find_page>
    2bd0:	48 89 c5             	mov    %rax,%rbp
    2bd3:	48 85 c0             	test   %rax,%rax
    2bd6:	0f 84 84 01 00 00    	je     2d60 <mi_malloc_generic_fallback+0x1e0>
    2bdc:	4d 85 ed             	test   %r13,%r13
    2bdf:	74 04                	je     2be5 <mi_malloc_generic_fallback+0x65>
    2be1:	49 89 6d 00          	mov    %rbp,0x0(%r13)
    2be5:	48 89 df             	mov    %rbx,%rdi
    2be8:	41 0f b6 cc          	movzbl %r12b,%ecx
    2bec:	4c 89 f2             	mov    %r14,%rdx
    2bef:	48 89 ee             	mov    %rbp,%rsi
    2bf2:	e8 00 00 00 00       	call   2bf7 <mi_malloc_generic_fallback+0x77>
			2bf3: R_X86_64_PLT32	_mi_page_malloc_zero-0x4
    2bf7:	48 81 7d 28 00 28 00 	cmpq   $0x2800,0x28(%rbp)
    2bfe:	00 
    2bff:	48 89 c3             	mov    %rax,%rbx
    2c02:	76 09                	jbe    2c0d <mi_malloc_generic_fallback+0x8d>
    2c04:	0f b7 45 36          	movzwl 0x36(%rbp),%eax
    2c08:	3b 45 10             	cmp    0x10(%rbp),%eax
    2c0b:	74 43                	je     2c50 <mi_malloc_generic_fallback+0xd0>
    2c0d:	48 83 c4 08          	add    $0x8,%rsp
    2c11:	48 89 d8             	mov    %rbx,%rax
    2c14:	5b                   	pop    %rbx
    2c15:	5d                   	pop    %rbp
    2c16:	41 5c                	pop    %r12
    2c18:	41 5d                	pop    %r13
    2c1a:	41 5e                	pop    %r14
    2c1c:	41 5f                	pop    %r15
    2c1e:	c3                   	ret
    2c1f:	90                   	nop
    2c20:	48 8d 05 00 00 00 00 	lea    0x0(%rip),%rax        # 2c27 <mi_malloc_generic_fallback+0xa7>
			2c23: R_X86_64_PC32	_mi_theap_empty_wrong-0x4
    2c27:	48 39 c7             	cmp    %rax,%rdi
    2c2a:	74 1a                	je     2c46 <mi_malloc_generic_fallback+0xc6>
    2c2c:	e8 00 00 00 00       	call   2c31 <mi_malloc_generic_fallback+0xb1>
			2c2d: R_X86_64_PLT32	_mi_thread_init-0x4
    2c31:	48 89 c3             	mov    %rax,%rbx
    2c34:	48 85 c0             	test   %rax,%rax
    2c37:	74 0d                	je     2c46 <mi_malloc_generic_fallback+0xc6>
    2c39:	48 8b 40 08          	mov    0x8(%rax),%rax
    2c3d:	48 85 c0             	test   %rax,%rax
    2c40:	0f 85 69 ff ff ff    	jne    2baf <mi_malloc_generic_fallback+0x2f>
    2c46:	31 db                	xor    %ebx,%ebx
    2c48:	eb c3                	jmp    2c0d <mi_malloc_generic_fallback+0x8d>
    2c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2c50:	4c 8b 6d 38          	mov    0x38(%rbp),%r13
    2c54:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    2c58:	b8 60 0e 00 00       	mov    $0xe60,%eax
    2c5d:	83 e2 01             	and    $0x1,%edx
    2c60:	75 3f                	jne    2ca1 <mi_malloc_generic_fallback+0x121>
    2c62:	66 83 7d 36 01       	cmpw   $0x1,0x36(%rbp)
    2c67:	48 8b 55 28          	mov    0x28(%rbp),%rdx
    2c6b:	0f 84 8f 01 00 00    	je     2e00 <mi_malloc_generic_fallback+0x280>
    2c71:	48 83 c2 07          	add    $0x7,%rdx
    2c75:	48 89 d1             	mov    %rdx,%rcx
    2c78:	48 c1 e9 03          	shr    $0x3,%rcx
    2c7c:	48 83 fa 47          	cmp    $0x47,%rdx
    2c80:	0f 87 5b 02 00 00    	ja     2ee1 <mi_malloc_generic_fallback+0x361>
    2c86:	b8 40 05 00 00       	mov    $0x540,%eax
    2c8b:	48 83 f9 01          	cmp    $0x1,%rcx
    2c8f:	76 10                	jbe    2ca1 <mi_malloc_generic_fallback+0x121>
    2c91:	48 83 c1 01          	add    $0x1,%rcx
    2c95:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
    2c99:	48 8d 41 29          	lea    0x29(%rcx),%rax
    2c9d:	48 c1 e0 05          	shl    $0x5,%rax
    2ca1:	48 89 ee             	mov    %rbp,%rsi
    2ca4:	4c 89 ef             	mov    %r13,%rdi
    2ca7:	4d 8d 64 05 00       	lea    0x0(%r13,%rax,1),%r12
    2cac:	e8 00 00 00 00       	call   2cb1 <mi_malloc_generic_fallback+0x131>
			2cad: R_X86_64_PLT32	_mi_large_span_on_full-0x4
    2cb1:	41 80 bd 11 01 00 00 	cmpb   $0x0,0x111(%r13)
    2cb8:	00 
    2cb9:	0f 84 09 01 00 00    	je     2dc8 <mi_malloc_generic_fallback+0x248>
    2cbf:	31 f6                	xor    %esi,%esi
    2cc1:	48 89 ef             	mov    %rbp,%rdi
    2cc4:	e8 00 00 00 00       	call   2cc9 <mi_malloc_generic_fallback+0x149>
			2cc5: R_X86_64_PLT32	_mi_page_free_collect_no_unpurge-0x4
    2cc9:	8b 45 10             	mov    0x10(%rbp),%eax
    2ccc:	85 c0                	test   %eax,%eax
    2cce:	0f 85 8c 01 00 00    	jne    2e60 <mi_malloc_generic_fallback+0x2e0>
    2cd4:	4c 89 e6             	mov    %r12,%rsi
    2cd7:	48 89 ef             	mov    %rbp,%rdi
    2cda:	e8 00 00 00 00       	call   2cdf <mi_malloc_generic_fallback+0x15f>
			2cdb: R_X86_64_PLT32	_mi_page_free-0x4
    2cdf:	e9 29 ff ff ff       	jmp    2c0d <mi_malloc_generic_fallback+0x8d>
    2ce4:	0f 1f 40 00          	nopl   0x0(%rax)
    2ce8:	ba 40 42 0f 00       	mov    $0xf4240,%edx
    2ced:	be 01 00 00 00       	mov    $0x1,%esi
    2cf2:	bf 22 00 00 00       	mov    $0x22,%edi
    2cf7:	48 01 83 e0 00 00 00 	add    %rax,0xe0(%rbx)
    2cfe:	48 c7 83 d8 00 00 00 	movq   $0x0,0xd8(%rbx)
    2d05:	00 00 00 00 
    2d09:	e8 00 00 00 00       	call   2d0e <mi_malloc_generic_fallback+0x18e>
			2d0a: R_X86_64_PLT32	mi_option_get_clamp-0x4
    2d0e:	48 3b 83 e0 00 00 00 	cmp    0xe0(%rbx),%rax
    2d15:	0f 8e 8d 00 00 00    	jle    2da8 <mi_malloc_generic_fallback+0x228>
    2d1b:	48 8b 03             	mov    (%rbx),%rax
    2d1e:	48 85 c0             	test   %rax,%rax
    2d21:	74 11                	je     2d34 <mi_malloc_generic_fallback+0x1b4>
    2d23:	48 8b 28             	mov    (%rax),%rbp
    2d26:	e8 00 00 00 00       	call   2d2b <mi_malloc_generic_fallback+0x1ab>
			2d27: R_X86_64_PLT32	_mi_thread_id-0x4
    2d2b:	48 39 c5             	cmp    %rax,%rbp
    2d2e:	0f 84 6c 01 00 00    	je     2ea0 <mi_malloc_generic_fallback+0x320>
    2d34:	31 f6                	xor    %esi,%esi
    2d36:	48 89 df             	mov    %rbx,%rdi
    2d39:	e8 00 00 00 00       	call   2d3e <mi_malloc_generic_fallback+0x1be>
			2d3a: R_X86_64_PLT32	_mi_theap_collect_retired-0x4
    2d3e:	48 8b 03             	mov    (%rbx),%rax
    2d41:	48 89 df             	mov    %rbx,%rdi
    2d44:	c7 80 f4 01 00 00 00 	movl   $0x400,0x1f4(%rax)
    2d4b:	04 00 00 
    2d4e:	e8 00 00 00 00       	call   2d53 <mi_malloc_generic_fallback+0x1d3>
			2d4f: R_X86_64_PLT32	_mi_theap_purge_large_holes-0x4
    2d53:	e9 6a fe ff ff       	jmp    2bc2 <mi_malloc_generic_fallback+0x42>
    2d58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    2d5f:	00 
    2d60:	be 01 00 00 00       	mov    $0x1,%esi
    2d65:	48 89 df             	mov    %rbx,%rdi
    2d68:	e8 00 00 00 00       	call   2d6d <mi_malloc_generic_fallback+0x1ed>
			2d69: R_X86_64_PLT32	mi_theap_collect-0x4
    2d6d:	4c 89 fa             	mov    %r15,%rdx
    2d70:	4c 89 f6             	mov    %r14,%rsi
    2d73:	48 89 df             	mov    %rbx,%rdi
    2d76:	e8 65 fc ff ff       	call   29e0 <mi_find_page>
    2d7b:	48 89 c5             	mov    %rax,%rbp
    2d7e:	48 85 c0             	test   %rax,%rax
    2d81:	0f 85 55 fe ff ff    	jne    2bdc <mi_malloc_generic_fallback+0x5c>
    2d87:	4c 89 f2             	mov    %r14,%rdx
    2d8a:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 2d91 <mi_malloc_generic_fallback+0x211>
			2d8d: R_X86_64_PC32	.LC3-0x4
    2d91:	31 c0                	xor    %eax,%eax
    2d93:	31 db                	xor    %ebx,%ebx
    2d95:	bf 0c 00 00 00       	mov    $0xc,%edi
    2d9a:	e8 00 00 00 00       	call   2d9f <mi_malloc_generic_fallback+0x21f>
			2d9b: R_X86_64_PLT32	_mi_error_message-0x4
    2d9f:	e9 69 fe ff ff       	jmp    2c0d <mi_malloc_generic_fallback+0x8d>
    2da4:	0f 1f 40 00          	nopl   0x0(%rax)
    2da8:	48 c7 83 e0 00 00 00 	movq   $0x0,0xe0(%rbx)
    2daf:	00 00 00 00 
    2db3:	31 f6                	xor    %esi,%esi
    2db5:	48 89 df             	mov    %rbx,%rdi
    2db8:	e8 00 00 00 00       	call   2dbd <mi_malloc_generic_fallback+0x23d>
			2db9: R_X86_64_PLT32	mi_theap_collect-0x4
    2dbd:	e9 7c ff ff ff       	jmp    2d3e <mi_malloc_generic_fallback+0x1be>
    2dc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2dc8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2dcc:	a8 01                	test   $0x1,%al
    2dce:	0f 85 39 fe ff ff    	jne    2c0d <mi_malloc_generic_fallback+0x8d>
    2dd4:	48 8b 45 38          	mov    0x38(%rbp),%rax
    2dd8:	4c 89 e6             	mov    %r12,%rsi
    2ddb:	48 89 ea             	mov    %rbp,%rdx
    2dde:	48 8d b8 60 0e 00 00 	lea    0xe60(%rax),%rdi
    2de5:	e8 26 da ff ff       	call   810 <mi_page_queue_enqueue_from_ex.constprop.0>
    2dea:	31 f6                	xor    %esi,%esi
    2dec:	48 89 ef             	mov    %rbp,%rdi
    2def:	e8 2c d4 ff ff       	call   220 <mi_page_free_collect_ex.constprop.0>
    2df4:	e9 14 fe ff ff       	jmp    2c0d <mi_malloc_generic_fallback+0x8d>
    2df9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2e00:	b8 40 0e 00 00       	mov    $0xe40,%eax
    2e05:	48 81 fa 00 00 08 00 	cmp    $0x80000,%rdx
    2e0c:	0f 87 8f fe ff ff    	ja     2ca1 <mi_malloc_generic_fallback+0x121>
    2e12:	8b 7d 68             	mov    0x68(%rbp),%edi
    2e15:	8d 4f fd             	lea    -0x3(%rdi),%ecx
    2e18:	83 f9 02             	cmp    $0x2,%ecx
    2e1b:	77 0a                	ja     2e27 <mi_malloc_generic_fallback+0x2a7>
    2e1d:	48 39 6d 58          	cmp    %rbp,0x58(%rbp)
    2e21:	0f 82 7a fe ff ff    	jb     2ca1 <mi_malloc_generic_fallback+0x121>
    2e27:	48 83 c2 07          	add    $0x7,%rdx
    2e2b:	48 89 d1             	mov    %rdx,%rcx
    2e2e:	48 c1 e9 03          	shr    $0x3,%rcx
    2e32:	48 83 fa 47          	cmp    $0x47,%rdx
    2e36:	0f 86 4a fe ff ff    	jbe    2c86 <mi_malloc_generic_fallback+0x106>
    2e3c:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
    2e40:	48 0f bd d0          	bsr    %rax,%rdx
    2e44:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    2e47:	48 d3 e8             	shr    %cl,%rax
    2e4a:	83 e0 03             	and    $0x3,%eax
    2e4d:	48 8d 44 90 26       	lea    0x26(%rax,%rdx,4),%rax
    2e52:	48 c1 e0 05          	shl    $0x5,%rax
    2e56:	e9 46 fe ff ff       	jmp    2ca1 <mi_malloc_generic_fallback+0x121>
    2e5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2e60:	48 89 ee             	mov    %rbp,%rsi
    2e63:	4c 89 e7             	mov    %r12,%rdi
    2e66:	e8 75 d7 ff ff       	call   5e0 <mi_page_queue_remove>
    2e6b:	48 8b 75 38          	mov    0x38(%rbp),%rsi
    2e6f:	48 c7 45 38 00 00 00 	movq   $0x0,0x38(%rbp)
    2e76:	00 
    2e77:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2e7b:	48 89 c2             	mov    %rax,%rdx
    2e7e:	83 e2 03             	and    $0x3,%edx
    2e81:	f0 48 0f b1 55 00    	lock cmpxchg %rdx,0x0(%rbp)
    2e87:	75 f2                	jne    2e7b <mi_malloc_generic_fallback+0x2fb>
    2e89:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    2e8d:	48 89 ef             	mov    %rbp,%rdi
    2e90:	e8 00 00 00 00       	call   2e95 <mi_malloc_generic_fallback+0x315>
			2e91: R_X86_64_PLT32	_mi_arenas_page_abandon-0x4
    2e95:	e9 73 fd ff ff       	jmp    2c0d <mi_malloc_generic_fallback+0x8d>
    2e9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2ea0:	48 83 43 20 01       	addq   $0x1,0x20(%rbx)
    2ea5:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 2eac <mi_malloc_generic_fallback+0x32c>
			2ea8: R_X86_64_PC32	.bss+0x4
    2eac:	48 85 c0             	test   %rax,%rax
    2eaf:	0f 84 7f fe ff ff    	je     2d34 <mi_malloc_generic_fallback+0x1b4>
    2eb5:	48 8b 13             	mov    (%rbx),%rdx
    2eb8:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    2ebc:	0f 85 72 fe ff ff    	jne    2d34 <mi_malloc_generic_fallback+0x1b4>
    2ec2:	c6 42 50 01          	movb   $0x1,0x50(%rdx)
    2ec6:	48 8b 15 00 00 00 00 	mov    0x0(%rip),%rdx        # 2ecd <mi_malloc_generic_fallback+0x34d>
			2ec9: R_X86_64_PC32	.bss-0x4
    2ecd:	31 ff                	xor    %edi,%edi
    2ecf:	48 8b 73 20          	mov    0x20(%rbx),%rsi
    2ed3:	ff d0                	call   *%rax
    2ed5:	48 8b 03             	mov    (%rbx),%rax
    2ed8:	c6 40 50 00          	movb   $0x0,0x50(%rax)
    2edc:	e9 53 fe ff ff       	jmp    2d34 <mi_malloc_generic_fallback+0x1b4>
    2ee1:	48 81 f9 00 00 01 00 	cmp    $0x10000,%rcx
    2ee8:	0f 86 4e ff ff ff    	jbe    2e3c <mi_malloc_generic_fallback+0x2bc>
    2eee:	b8 40 0e 00 00       	mov    $0xe40,%eax
    2ef3:	e9 a9 fd ff ff       	jmp    2ca1 <mi_malloc_generic_fallback+0x121>
    2ef8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    2eff:	00 

0000000000002f00 <_mi_page_init>:
    2f00:	41 57                	push   %r15
    2f02:	41 56                	push   %r14
    2f04:	41 55                	push   %r13
    2f06:	41 54                	push   %r12
    2f08:	49 89 fc             	mov    %rdi,%r12
    2f0b:	48 89 f7             	mov    %rsi,%rdi
    2f0e:	55                   	push   %rbp
    2f0f:	53                   	push   %rbx
    2f10:	48 89 f3             	mov    %rsi,%rbx
    2f13:	48 83 ec 08          	sub    $0x8,%rsp
    2f17:	e8 00 00 00 00       	call   2f1c <_mi_page_init+0x1c>
			2f18: R_X86_64_PLT32	_mi_page_purged_reset-0x4
    2f1c:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    2f21:	74 1d                	je     2f40 <_mi_page_init+0x40>
    2f23:	b8 01 00 00 00       	mov    $0x1,%eax
    2f28:	48 83 c4 08          	add    $0x8,%rsp
    2f2c:	5b                   	pop    %rbx
    2f2d:	5d                   	pop    %rbp
    2f2e:	41 5c                	pop    %r12
    2f30:	41 5d                	pop    %r13
    2f32:	41 5e                	pop    %r14
    2f34:	41 5f                	pop    %r15
    2f36:	c3                   	ret
    2f37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2f3e:	00 00 
    2f40:	0f b7 43 14          	movzwl 0x14(%rbx),%eax
    2f44:	0f b7 6b 36          	movzwl 0x36(%rbx),%ebp
    2f48:	66 39 e8             	cmp    %bp,%ax
    2f4b:	73 d6                	jae    2f23 <_mi_page_init+0x23>
    2f4d:	48 83 bb a0 00 00 00 	cmpq   $0x0,0xa0(%rbx)
    2f54:	00 
    2f55:	74 14                	je     2f6b <_mi_page_init+0x6b>
    2f57:	49 8b 34 24          	mov    (%r12),%rsi
    2f5b:	48 89 df             	mov    %rbx,%rdi
    2f5e:	e8 00 00 00 00       	call   2f63 <_mi_page_init+0x63>
			2f5f: R_X86_64_PLT32	_mi_page_unpublish_retired-0x4
    2f63:	0f b7 6b 36          	movzwl 0x36(%rbx),%ebp
    2f67:	0f b7 43 14          	movzwl 0x14(%rbx),%eax
    2f6b:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
    2f6f:	48 29 c5             	sub    %rax,%rbp
    2f72:	b8 01 00 00 00       	mov    $0x1,%eax
    2f77:	49 81 fd ff 0f 00 00 	cmp    $0xfff,%r13
    2f7e:	0f 86 14 01 00 00    	jbe    3098 <_mi_page_init+0x198>
    2f84:	48 39 c5             	cmp    %rax,%rbp
    2f87:	44 0f b7 7b 34       	movzwl 0x34(%rbx),%r15d
    2f8c:	48 0f 47 e8          	cmova  %rax,%rbp
    2f90:	e8 00 00 00 00       	call   2f95 <_mi_page_init+0x95>
			2f91: R_X86_64_PLT32	_mi_os_page_size-0x4
    2f95:	4c 0f af f8          	imul   %rax,%r15
    2f99:	4d 85 ff             	test   %r15,%r15
    2f9c:	0f 84 ba 00 00 00    	je     305c <_mi_page_init+0x15c>
    2fa2:	4c 89 e8             	mov    %r13,%rax
    2fa5:	48 0f af c5          	imul   %rbp,%rax
    2fa9:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    2faf:	76 19                	jbe    2fca <_mi_page_init+0xca>
    2fb1:	bd 00 00 01 00       	mov    $0x10000,%ebp
    2fb6:	4d 85 ed             	test   %r13,%r13
    2fb9:	74 0f                	je     2fca <_mi_page_init+0xca>
    2fbb:	49 8d 85 ff ff 00 00 	lea    0xffff(%r13),%rax
    2fc2:	31 d2                	xor    %edx,%edx
    2fc4:	49 f7 f5             	div    %r13
    2fc7:	48 89 c5             	mov    %rax,%rbp
    2fca:	44 0f b7 73 14       	movzwl 0x14(%rbx),%r14d
    2fcf:	e8 00 00 00 00       	call   2fd4 <_mi_page_init+0xd4>
			2fd0: R_X86_64_PLT32	_mi_os_page_size-0x4
    2fd4:	8b 73 30             	mov    0x30(%rbx),%esi
    2fd7:	49 89 d8             	mov    %rbx,%r8
    2fda:	48 89 c1             	mov    %rax,%rcx
    2fdd:	49 01 ee             	add    %rbp,%r14
    2fe0:	b8 00 40 00 00       	mov    $0x4000,%eax
    2fe5:	4d 0f af f5          	imul   %r13,%r14
    2fe9:	48 39 c1             	cmp    %rax,%rcx
    2fec:	48 0f 42 c8          	cmovb  %rax,%rcx
    2ff0:	48 c1 e6 04          	shl    $0x4,%rsi
    2ff4:	48 01 de             	add    %rbx,%rsi
    2ff7:	83 7b 68 06          	cmpl   $0x6,0x68(%rbx)
    2ffb:	0f 84 bf 00 00 00    	je     30c0 <_mi_page_init+0x1c0>
    3001:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
    3005:	48 89 f7             	mov    %rsi,%rdi
    3008:	4c 29 c7             	sub    %r8,%rdi
    300b:	49 01 c6             	add    %rax,%r14
    300e:	49 01 fe             	add    %rdi,%r14
    3011:	48 85 c1             	test   %rax,%rcx
    3014:	0f 84 96 00 00 00    	je     30b0 <_mi_page_init+0x1b0>
    301a:	4c 89 f0             	mov    %r14,%rax
    301d:	31 d2                	xor    %edx,%edx
    301f:	48 f7 f1             	div    %rcx
    3022:	49 29 d6             	sub    %rdx,%r14
    3025:	4d 39 f7             	cmp    %r14,%r15
    3028:	73 3c                	jae    3066 <_mi_page_init+0x166>
    302a:	4c 89 f2             	mov    %r14,%rdx
    302d:	49 8b 7c 24 10       	mov    0x10(%r12),%rdi
    3032:	31 c9                	xor    %ecx,%ecx
    3034:	4b 8d 34 38          	lea    (%r8,%r15,1),%rsi
    3038:	4c 29 fa             	sub    %r15,%rdx
    303b:	e8 00 00 00 00       	call   3040 <_mi_page_init+0x140>
			303c: R_X86_64_PLT32	_mi_os_commit-0x4
    3040:	84 c0                	test   %al,%al
    3042:	0f 84 e0 fe ff ff    	je     2f28 <_mi_page_init+0x28>
    3048:	e8 00 00 00 00       	call   304d <_mi_page_init+0x14d>
			3049: R_X86_64_PLT32	_mi_os_page_size-0x4
    304d:	31 d2                	xor    %edx,%edx
    304f:	48 89 c1             	mov    %rax,%rcx
    3052:	4c 89 f0             	mov    %r14,%rax
    3055:	48 f7 f1             	div    %rcx
    3058:	66 89 43 34          	mov    %ax,0x34(%rbx)
    305c:	8b 73 30             	mov    0x30(%rbx),%esi
    305f:	48 c1 e6 04          	shl    $0x4,%rsi
    3063:	48 01 de             	add    %rbx,%rsi
    3066:	0f b7 43 14          	movzwl 0x14(%rbx),%eax
    306a:	48 89 df             	mov    %rbx,%rdi
    306d:	48 01 e8             	add    %rbp,%rax
    3070:	49 0f af c5          	imul   %r13,%rax
    3074:	48 01 c6             	add    %rax,%rsi
    3077:	e8 00 00 00 00       	call   307c <_mi_page_init+0x17c>
			3078: R_X86_64_PLT32	_mi_page_unpurge_unformed_upto-0x4
    307c:	48 89 ea             	mov    %rbp,%rdx
    307f:	4c 89 ee             	mov    %r13,%rsi
    3082:	48 89 df             	mov    %rbx,%rdi
    3085:	e8 76 cf ff ff       	call   0 <mi_page_free_list_extend>
    308a:	66 01 6b 14          	add    %bp,0x14(%rbx)
    308e:	e9 90 fe ff ff       	jmp    2f23 <_mi_page_init+0x23>
    3093:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3098:	b8 00 10 00 00       	mov    $0x1000,%eax
    309d:	31 d2                	xor    %edx,%edx
    309f:	49 f7 f5             	div    %r13
    30a2:	e9 dd fe ff ff       	jmp    2f84 <_mi_page_init+0x84>
    30a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    30ae:	00 00 
    30b0:	48 f7 d9             	neg    %rcx
    30b3:	49 21 ce             	and    %rcx,%r14
    30b6:	e9 6a ff ff ff       	jmp    3025 <_mi_page_init+0x125>
    30bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    30c0:	49 89 f0             	mov    %rsi,%r8
    30c3:	66 45 31 c0          	xor    %r8w,%r8w
    30c7:	e9 35 ff ff ff       	jmp    3001 <_mi_page_init+0x101>
    30cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000030d0 <_mi_deferred_free>:
    30d0:	48 8b 07             	mov    (%rdi),%rax
    30d3:	48 85 c0             	test   %rax,%rax
    30d6:	74 58                	je     3130 <_mi_deferred_free+0x60>
    30d8:	41 54                	push   %r12
    30da:	55                   	push   %rbp
    30db:	89 f5                	mov    %esi,%ebp
    30dd:	53                   	push   %rbx
    30de:	4c 8b 20             	mov    (%rax),%r12
    30e1:	48 89 fb             	mov    %rdi,%rbx
    30e4:	e8 00 00 00 00       	call   30e9 <_mi_deferred_free+0x19>
			30e5: R_X86_64_PLT32	_mi_thread_id-0x4
    30e9:	49 39 c4             	cmp    %rax,%r12
    30ec:	74 0a                	je     30f8 <_mi_deferred_free+0x28>
    30ee:	5b                   	pop    %rbx
    30ef:	5d                   	pop    %rbp
    30f0:	41 5c                	pop    %r12
    30f2:	c3                   	ret
    30f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    30f8:	48 83 43 20 01       	addq   $0x1,0x20(%rbx)
    30fd:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 3104 <_mi_deferred_free+0x34>
			3100: R_X86_64_PC32	.bss+0x4
    3104:	48 85 c0             	test   %rax,%rax
    3107:	74 e5                	je     30ee <_mi_deferred_free+0x1e>
    3109:	48 8b 13             	mov    (%rbx),%rdx
    310c:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3110:	75 dc                	jne    30ee <_mi_deferred_free+0x1e>
    3112:	c6 42 50 01          	movb   $0x1,0x50(%rdx)
    3116:	48 8b 15 00 00 00 00 	mov    0x0(%rip),%rdx        # 311d <_mi_deferred_free+0x4d>
			3119: R_X86_64_PC32	.bss-0x4
    311d:	40 0f b6 fd          	movzbl %bpl,%edi
    3121:	48 8b 73 20          	mov    0x20(%rbx),%rsi
    3125:	ff d0                	call   *%rax
    3127:	48 8b 03             	mov    (%rbx),%rax
    312a:	c6 40 50 00          	movb   $0x0,0x50(%rax)
    312e:	eb be                	jmp    30ee <_mi_deferred_free+0x1e>
    3130:	c3                   	ret
    3131:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3138:	00 00 00 00 
    313c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003140 <mi_register_deferred_free>:
    3140:	48 89 35 00 00 00 00 	mov    %rsi,0x0(%rip)        # 3147 <mi_register_deferred_free+0x7>
			3143: R_X86_64_PC32	.bss-0x4
    3147:	48 89 3d 00 00 00 00 	mov    %rdi,0x0(%rip)        # 314e <mi_register_deferred_free+0xe>
			314a: R_X86_64_PC32	.bss+0x4
    314e:	c3                   	ret
    314f:	90                   	nop

0000000000003150 <_mi_malloc_generic>:
    3150:	41 56                	push   %r14
    3152:	49 89 c8             	mov    %rcx,%r8
    3155:	48 89 d1             	mov    %rdx,%rcx
    3158:	41 55                	push   %r13
    315a:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
    315e:	41 54                	push   %r12
    3160:	41 89 d4             	mov    %edx,%r12d
    3163:	55                   	push   %rbp
    3164:	41 83 e4 01          	and    $0x1,%r12d
    3168:	48 89 f5             	mov    %rsi,%rbp
    316b:	53                   	push   %rbx
    316c:	48 89 fb             	mov    %rdi,%rbx
    316f:	48 83 ec 10          	sub    $0x10,%rsp
    3173:	48 85 ff             	test   %rdi,%rdi
    3176:	74 3f                	je     31b7 <_mi_malloc_generic+0x67>
    3178:	4c 8b 37             	mov    (%rdi),%r14
    317b:	4d 85 f6             	test   %r14,%r14
    317e:	0f 85 cc 00 00 00    	jne    3250 <_mi_malloc_generic+0x100>
    3184:	48 8b 43 08          	mov    0x8(%rbx),%rax
    3188:	48 85 c0             	test   %rax,%rax
    318b:	74 2a                	je     31b7 <_mi_malloc_generic+0x67>
    318d:	48 8b 83 d8 00 00 00 	mov    0xd8(%rbx),%rax
    3194:	48 83 c0 01          	add    $0x1,%rax
    3198:	48 89 83 d8 00 00 00 	mov    %rax,0xd8(%rbx)
    319f:	48 3d e7 03 00 00    	cmp    $0x3e7,%rax
    31a5:	7f 10                	jg     31b7 <_mi_malloc_generic+0x67>
    31a7:	48 85 c9             	test   %rcx,%rcx
    31aa:	75 0b                	jne    31b7 <_mi_malloc_generic+0x67>
    31ac:	48 81 fd ff 27 00 00 	cmp    $0x27ff,%rbp
    31b3:	76 23                	jbe    31d8 <_mi_malloc_generic+0x88>
    31b5:	31 c9                	xor    %ecx,%ecx
    31b7:	48 83 c4 10          	add    $0x10,%rsp
    31bb:	41 0f b6 d4          	movzbl %r12b,%edx
    31bf:	48 89 ee             	mov    %rbp,%rsi
    31c2:	48 89 df             	mov    %rbx,%rdi
    31c5:	5b                   	pop    %rbx
    31c6:	5d                   	pop    %rbp
    31c7:	41 5c                	pop    %r12
    31c9:	41 5d                	pop    %r13
    31cb:	41 5e                	pop    %r14
    31cd:	e9 ae f9 ff ff       	jmp    2b80 <mi_malloc_generic_fallback>
    31d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    31d8:	48 8d 55 07          	lea    0x7(%rbp),%rdx
    31dc:	48 89 d0             	mov    %rdx,%rax
    31df:	48 c1 e8 03          	shr    $0x3,%rax
    31e3:	48 83 fa 47          	cmp    $0x47,%rdx
    31e7:	0f 87 ee 00 00 00    	ja     32db <_mi_malloc_generic+0x18b>
    31ed:	48 83 f8 01          	cmp    $0x1,%rax
    31f1:	0f 86 a9 00 00 00    	jbe    32a0 <_mi_malloc_generic+0x150>
    31f7:	48 83 c0 01          	add    $0x1,%rax
    31fb:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    31ff:	48 83 c0 29          	add    $0x29,%rax
    3203:	48 89 c2             	mov    %rax,%rdx
    3206:	48 c1 e2 05          	shl    $0x5,%rdx
    320a:	48 c1 e0 05          	shl    $0x5,%rax
    320e:	48 8b 34 03          	mov    (%rbx,%rax,1),%rsi
    3212:	48 85 f6             	test   %rsi,%rsi
    3215:	0f 84 94 00 00 00    	je     32af <_mi_malloc_generic+0x15f>
    321b:	48 83 7e 08 00       	cmpq   $0x0,0x8(%rsi)
    3220:	0f 84 d7 00 00 00    	je     32fd <_mi_malloc_generic+0x1ad>
    3226:	c6 46 16 00          	movb   $0x0,0x16(%rsi)
    322a:	4d 85 c0             	test   %r8,%r8
    322d:	74 03                	je     3232 <_mi_malloc_generic+0xe2>
    322f:	49 89 30             	mov    %rsi,(%r8)
    3232:	48 83 c4 10          	add    $0x10,%rsp
    3236:	41 0f b6 cc          	movzbl %r12b,%ecx
    323a:	48 89 ea             	mov    %rbp,%rdx
    323d:	48 89 df             	mov    %rbx,%rdi
    3240:	5b                   	pop    %rbx
    3241:	5d                   	pop    %rbp
    3242:	41 5c                	pop    %r12
    3244:	41 5d                	pop    %r13
    3246:	41 5e                	pop    %r14
    3248:	e9 00 00 00 00       	jmp    324d <_mi_malloc_generic+0xfd>
			3249: R_X86_64_PLT32	_mi_page_malloc_zero-0x4
    324d:	0f 1f 00             	nopl   (%rax)
    3250:	49 8b 86 e8 00 00 00 	mov    0xe8(%r14),%rax
    3257:	48 85 c0             	test   %rax,%rax
    325a:	0f 84 24 ff ff ff    	je     3184 <_mi_malloc_generic+0x34>
    3260:	4d 8b 2e             	mov    (%r14),%r13
    3263:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    3268:	48 89 0c 24          	mov    %rcx,(%rsp)
    326c:	e8 00 00 00 00       	call   3271 <_mi_malloc_generic+0x121>
			326d: R_X86_64_PLT32	_mi_thread_id-0x4
    3271:	48 8b 0c 24          	mov    (%rsp),%rcx
    3275:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    327a:	49 39 c5             	cmp    %rax,%r13
    327d:	0f 85 01 ff ff ff    	jne    3184 <_mi_malloc_generic+0x34>
    3283:	4c 89 f7             	mov    %r14,%rdi
    3286:	e8 00 00 00 00       	call   328b <_mi_malloc_generic+0x13b>
			3287: R_X86_64_PLT32	_mi_park_leave-0x4
    328b:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    3290:	48 8b 0c 24          	mov    (%rsp),%rcx
    3294:	e9 eb fe ff ff       	jmp    3184 <_mi_malloc_generic+0x34>
    3299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    32a0:	ba 40 05 00 00       	mov    $0x540,%edx
    32a5:	b8 2a 00 00 00       	mov    $0x2a,%eax
    32aa:	e9 5b ff ff ff       	jmp    320a <_mi_malloc_generic+0xba>
    32af:	48 8d 34 13          	lea    (%rbx,%rdx,1),%rsi
    32b3:	48 89 df             	mov    %rbx,%rdi
    32b6:	ba 01 00 00 00       	mov    $0x1,%edx
    32bb:	4c 89 04 24          	mov    %r8,(%rsp)
    32bf:	e8 6c f3 ff ff       	call   2630 <mi_page_queue_find_free_ex>
    32c4:	4c 8b 04 24          	mov    (%rsp),%r8
    32c8:	48 85 c0             	test   %rax,%rax
    32cb:	48 89 c6             	mov    %rax,%rsi
    32ce:	0f 85 56 ff ff ff    	jne    322a <_mi_malloc_generic+0xda>
    32d4:	31 c9                	xor    %ecx,%ecx
    32d6:	e9 dc fe ff ff       	jmp    31b7 <_mi_malloc_generic+0x67>
    32db:	48 83 e8 01          	sub    $0x1,%rax
    32df:	48 0f bd d0          	bsr    %rax,%rdx
    32e3:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    32e6:	48 d3 e8             	shr    %cl,%rax
    32e9:	83 e0 03             	and    $0x3,%eax
    32ec:	48 8d 44 90 26       	lea    0x26(%rax,%rdx,4),%rax
    32f1:	48 89 c2             	mov    %rax,%rdx
    32f4:	48 c1 e2 05          	shl    $0x5,%rdx
    32f8:	e9 0d ff ff ff       	jmp    320a <_mi_malloc_generic+0xba>
    32fd:	48 8b 46 18          	mov    0x18(%rsi),%rax
    3301:	48 85 c0             	test   %rax,%rax
    3304:	74 a9                	je     32af <_mi_malloc_generic+0x15f>
    3306:	48 89 46 08          	mov    %rax,0x8(%rsi)
    330a:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    3311:	00 
    3312:	c6 46 17 00          	movb   $0x0,0x17(%rsi)
    3316:	e9 0b ff ff ff       	jmp    3226 <_mi_malloc_generic+0xd6>
