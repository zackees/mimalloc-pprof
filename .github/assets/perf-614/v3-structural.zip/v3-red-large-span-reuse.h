/* Demand accounting for an already selected retired page (#614). */
#ifndef MI_LARGE_SPAN_REUSE_H
#define MI_LARGE_SPAN_REUSE_H

#if MI_LARGE_REPURPOSE
static inline void mi_large_span_account_repurpose(mi_theap_t* theap, size_t block_size, size_t index) {
  MI_UNUSED(index);
  (void)_mi_large_span_slices(theap, block_size, 0);
}
#endif

#endif
