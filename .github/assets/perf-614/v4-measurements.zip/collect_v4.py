"""Collect original V4 evidence. Never dispatch or retry a workflow."""
from pathlib import Path
import json
import subprocess
import sys
import zipfile
import hashlib
import time

ROOT = Path('/tmp/mimalloc-614-campaign')
REPO = 'zackees/mimalloc-pprof'
WT = '/home/niteris/.clud/worktrees/mimalloc-pprof-wt-614'
FIELDS = 'conclusion,createdAt,databaseId,event,headSha,jobs,status,updatedAt,url'
manifest = json.loads((ROOT / 'v4-dispatch-manifest.json').read_text())


def gh(*args):
    return subprocess.check_output(['gh', *map(str,args)])


def collect(run_id, dest):
    # Fresh API records: gh run view retained an obsolete queued state for an
    # already executing cohort. The nonce changes observation only, never a run.
    nonce = str(time.time_ns())
    api = json.loads(gh('api', f'repos/{REPO}/actions/runs/{run_id}?observation={nonce}'))
    dest.mkdir(parents=True, exist_ok=True)
    (dest / 'api-run.json').write_text(json.dumps(api, indent=2) + '\n')
    jobs=[]
    page=1
    while True:
        batch=json.loads(gh('api', f'repos/{REPO}/actions/runs/{run_id}/jobs?filter=all&per_page=100&page={page}&observation={nonce}'))
        (dest / f'api-jobs-{page}.json').write_text(json.dumps(batch, indent=2) + '\n')
        jobs.extend(batch['jobs'])
        if len(jobs) >= batch['total_count']:
            break
        assert batch['jobs'], 'Missing job page'
        page += 1
    data={'conclusion':api['conclusion'], 'createdAt':api['created_at'],
          'databaseId':api['id'], 'event':api['event'], 'headSha':api['head_sha'],
          'jobs':jobs, 'status':api['status'], 'updatedAt':api['updated_at'], 'url':api['html_url']}
    raw=json.dumps(data, indent=2).encode()
    assert data['headSha'] == manifest['candidate'], (run_id, 'unexpected source')
    dest.mkdir(parents=True, exist_ok=True)
    if data['status'] != 'completed':
        (dest / 'live-status.json').write_bytes(raw)
        print(run_id, data['status'], flush=True)
        return None
    (dest / 'run.json').write_bytes(raw)
    logs = dest / 'logs.zip'
    if not logs.exists():
        content = gh('api', f'repos/{REPO}/actions/runs/{run_id}/logs')
        # Validate bytes before recording an immutable original download.
        import io
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            assert z.testzip() is None
        logs.write_bytes(content)
    with zipfile.ZipFile(logs) as z:
        assert z.testzip() is None
    print(run_id, data['conclusion'], flush=True)
    return data


if '--platform' in sys.argv:
    runs = json.loads((ROOT / 'v4-platform-manifest.json').read_text())['runs']
    records=[]
    for name,run_id in runs.items():
        dest=ROOT/'v4-platform-gates'/name
        data=collect(run_id,dest)
        if data:
            records.append({'workflow':name,'run_id':run_id,'conclusion':data['conclusion'],
                'job_count':len(data['jobs']),
                'metadata_sha256':hashlib.sha256((dest/'run.json').read_bytes()).hexdigest(),
                'logs_sha256':hashlib.sha256((dest/'logs.zip').read_bytes()).hexdigest()})
    (ROOT/'v4-platform-gates'/'collected.json').write_text(json.dumps(records,indent=2)+'\n')
else:
    for row in manifest['runs']:
        run_id=row['response']['workflow_run_id']
        dest=ROOT/'v4-downloads'/str(run_id)
        data=collect(run_id,dest)
        if not data:
            continue
        artifacts=json.loads(gh('api',f'repos/{REPO}/actions/runs/{run_id}/artifacts'))
        (dest/'artifact-metadata.json').write_text(json.dumps(artifacts,indent=2)+'\n')
        names={a['name'] for a in artifacts['artifacts']}
        for name,subdir in [('perf-ab-samples','samples'),('perf-ab-builds','builds')]:
            marker=dest/subdir/('.download-complete')
            if name not in names:
                print(run_id,'MISSING',name,flush=True)
                continue
            if not marker.exists():
                subprocess.run(['gh','run','download',str(run_id),'--repo',REPO,
                                '--name',name,'--dir',str(dest/subdir)],check=True)
                marker.write_text('original artifact downloaded\n')
        if all((dest/d/'.download-complete').exists() for d in ['samples','builds']):
            result=subprocess.run([sys.executable,'-B',str(ROOT/'verify_perf.py'),str(dest),
                '--repo',WT,'--baseline',manifest['baseline'],'--candidate',manifest['candidate'],
                '--workload',row['workload']],capture_output=True)
            (dest/'verification-output.log').write_bytes(result.stdout+result.stderr)
            result.check_returncode()
            ledger=json.loads(result.stdout)
            (dest/'verified-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
            print(run_id, 'verified', ledger.get('verdict'), ledger.get('counts'), flush=True)
