
/tmp/mimalloc-614-campaign/v2-codegen/CMakeFiles/mimalloc-static.dir/src/large-span.c.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000360 <_mi_large_span_account_repurpose>:
 360:	48 85 ff             	test   %rdi,%rdi
 363:	0f 84 97 00 00 00    	je     400 <_mi_large_span_account_repurpose+0xa0>
 369:	41 54                	push   %r12
 36b:	55                   	push   %rbp
 36c:	48 89 f5             	mov    %rsi,%rbp
 36f:	53                   	push   %rbx
 370:	48 89 fb             	mov    %rdi,%rbx
 373:	bf 3f 00 00 00       	mov    $0x3f,%edi
 378:	e8 00 00 00 00       	call   37d <_mi_large_span_account_repurpose+0x1d>
			379: R_X86_64_PLT32	mi_option_is_enabled-0x4
 37d:	48 83 fd 0f          	cmp    $0xf,%rbp
 381:	77 72                	ja     3f5 <_mi_large_span_account_repurpose+0x95>
 383:	3c 01                	cmp    $0x1,%al
 385:	75 6e                	jne    3f5 <_mi_large_span_account_repurpose+0x95>
 387:	44 0f b6 a4 2b a8 1f 	movzbl 0x1fa8(%rbx,%rbp,1),%r12d
 38e:	00 00 
 390:	bf 40 00 00 00       	mov    $0x40,%edi
 395:	e8 00 00 00 00       	call   39a <_mi_large_span_account_repurpose+0x3a>
			396: R_X86_64_PLT32	mi_option_get-0x4
 39a:	48 85 c0             	test   %rax,%rax
 39d:	0f 8e b5 00 00 00    	jle    458 <_mi_large_span_account_repurpose+0xf8>
 3a3:	48 c1 e0 0a          	shl    $0xa,%rax
 3a7:	ba 10 00 00 00       	mov    $0x10,%edx
 3ac:	48 05 ff ff 00 00    	add    $0xffff,%rax
 3b2:	48 c1 e8 10          	shr    $0x10,%rax
 3b6:	48 39 d0             	cmp    %rdx,%rax
 3b9:	48 0f 42 c2          	cmovb  %rdx,%rax
 3bd:	ba 40 00 00 00       	mov    $0x40,%edx
 3c2:	48 39 d0             	cmp    %rdx,%rax
 3c5:	48 0f 47 c2          	cmova  %rdx,%rax
 3c9:	44 89 e2             	mov    %r12d,%edx
 3cc:	44 89 e1             	mov    %r12d,%ecx
 3cf:	41 83 e4 08          	and    $0x8,%r12d
 3d3:	c0 ea 04             	shr    $0x4,%dl
 3d6:	83 e1 07             	and    $0x7,%ecx
 3d9:	0f b6 f2             	movzbl %dl,%esi
 3dc:	80 fa 07             	cmp    $0x7,%dl
 3df:	76 27                	jbe    408 <_mi_large_span_account_repurpose+0xa8>
 3e1:	45 84 e4             	test   %r12b,%r12b
 3e4:	74 3a                	je     420 <_mi_large_span_account_repurpose+0xc0>
 3e6:	83 ea 0f             	sub    $0xf,%edx
 3e9:	c1 e2 04             	shl    $0x4,%edx
 3ec:	09 d1                	or     %edx,%ecx
 3ee:	88 8c 2b a8 1f 00 00 	mov    %cl,0x1fa8(%rbx,%rbp,1)
 3f5:	5b                   	pop    %rbx
 3f6:	5d                   	pop    %rbp
 3f7:	41 5c                	pop    %r12
 3f9:	c3                   	ret
 3fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 400:	c3                   	ret
 401:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 408:	45 84 e4             	test   %r12b,%r12b
 40b:	75 2b                	jne    438 <_mi_large_span_account_repurpose+0xd8>
 40d:	84 c9                	test   %cl,%cl
 40f:	74 67                	je     478 <_mi_large_span_account_repurpose+0x118>
 411:	83 ea 01             	sub    $0x1,%edx
 414:	c1 e2 04             	shl    $0x4,%edx
 417:	09 d1                	or     %edx,%ecx
 419:	eb d3                	jmp    3ee <_mi_large_span_account_repurpose+0x8e>
 41b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 420:	84 c9                	test   %cl,%cl
 422:	74 44                	je     468 <_mi_large_span_account_repurpose+0x108>
 424:	48 83 ee 11          	sub    $0x11,%rsi
 428:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
 42c:	7d 62                	jge    490 <_mi_large_span_account_repurpose+0x130>
 42e:	83 e9 01             	sub    $0x1,%ecx
 431:	eb bb                	jmp    3ee <_mi_large_span_account_repurpose+0x8e>
 433:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 438:	84 d2                	test   %dl,%dl
 43a:	74 4c                	je     488 <_mi_large_span_account_repurpose+0x128>
 43c:	ba 10 00 00 00       	mov    $0x10,%edx
 441:	48 d3 e2             	shl    %cl,%rdx
 444:	48 39 c2             	cmp    %rax,%rdx
 447:	73 a5                	jae    3ee <_mi_large_span_account_repurpose+0x8e>
 449:	80 f9 07             	cmp    $0x7,%cl
 44c:	0f 95 c0             	setne  %al
 44f:	01 c1                	add    %eax,%ecx
 451:	eb 9b                	jmp    3ee <_mi_large_span_account_repurpose+0x8e>
 453:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 458:	b8 40 00 00 00       	mov    $0x40,%eax
 45d:	e9 67 ff ff ff       	jmp    3c9 <_mi_large_span_account_repurpose+0x69>
 462:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 468:	89 d1                	mov    %edx,%ecx
 46a:	c1 e1 04             	shl    $0x4,%ecx
 46d:	e9 7c ff ff ff       	jmp    3ee <_mi_large_span_account_repurpose+0x8e>
 472:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 478:	8d 42 ff             	lea    -0x1(%rdx),%eax
 47b:	c1 e0 04             	shl    $0x4,%eax
 47e:	84 d2                	test   %dl,%dl
 480:	0f 45 c8             	cmovne %eax,%ecx
 483:	e9 66 ff ff ff       	jmp    3ee <_mi_large_span_account_repurpose+0x8e>
 488:	83 c9 10             	or     $0x10,%ecx
 48b:	e9 5e ff ff ff       	jmp    3ee <_mi_large_span_account_repurpose+0x8e>
 490:	83 ea 11             	sub    $0x11,%edx
 493:	c1 e2 04             	shl    $0x4,%edx
 496:	09 d1                	or     %edx,%ecx
 498:	e9 51 ff ff ff       	jmp    3ee <_mi_large_span_account_repurpose+0x8e>
