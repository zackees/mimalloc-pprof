
/tmp/mimalloc-614-campaign/v2-codegen/CMakeFiles/mimalloc-static.dir/src/large-span.c.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000220 <_mi_large_span_slices>:
 220:	48 85 ff             	test   %rdi,%rdi
 223:	0f 84 87 00 00 00    	je     2b0 <_mi_large_span_slices+0x90>
 229:	41 55                	push   %r13
 22b:	41 54                	push   %r12
 22d:	49 89 d4             	mov    %rdx,%r12
 230:	55                   	push   %rbp
 231:	48 89 f5             	mov    %rsi,%rbp
 234:	53                   	push   %rbx
 235:	48 89 fb             	mov    %rdi,%rbx
 238:	bf 3f 00 00 00       	mov    $0x3f,%edi
 23d:	48 83 ec 08          	sub    $0x8,%rsp
 241:	e8 00 00 00 00       	call   246 <_mi_large_span_slices+0x26>
			242: R_X86_64_PLT32	mi_option_is_enabled-0x4
 246:	84 c0                	test   %al,%al
 248:	74 56                	je     2a0 <_mi_large_span_slices+0x80>
 24a:	48 8d 85 55 ad fe ff 	lea    -0x152ab(%rbp),%rax
 251:	48 3d 55 ad 06 00    	cmp    $0x6ad55,%rax
 257:	77 47                	ja     2a0 <_mi_large_span_slices+0x80>
 259:	bf ab 52 01 00       	mov    $0x152ab,%edi
 25e:	e8 00 00 00 00       	call   263 <_mi_large_span_slices+0x43>
			25f: R_X86_64_PLT32	_mi_bin-0x4
 263:	48 89 ef             	mov    %rbp,%rdi
 266:	49 89 c5             	mov    %rax,%r13
 269:	e8 00 00 00 00       	call   26e <_mi_large_span_slices+0x4e>
			26a: R_X86_64_PLT32	_mi_bin-0x4
 26e:	4c 29 e8             	sub    %r13,%rax
 271:	48 83 f8 0f          	cmp    $0xf,%rax
 275:	77 29                	ja     2a0 <_mi_large_span_slices+0x80>
 277:	0f b6 bc 03 a8 1f 00 	movzbl 0x1fa8(%rbx,%rax,1),%edi
 27e:	00 
 27f:	48 83 c4 08          	add    $0x8,%rsp
 283:	4c 89 e2             	mov    %r12,%rdx
 286:	48 89 ee             	mov    %rbp,%rsi
 289:	48 8d 8c 03 a8 1f 00 	lea    0x1fa8(%rbx,%rax,1),%rcx
 290:	00 
 291:	5b                   	pop    %rbx
 292:	5d                   	pop    %rbp
 293:	41 5c                	pop    %r12
 295:	41 5d                	pop    %r13
 297:	e9 64 fd ff ff       	jmp    0 <mi_large_span_request>
 29c:	0f 1f 40 00          	nopl   0x0(%rax)
 2a0:	48 83 c4 08          	add    $0x8,%rsp
 2a4:	b8 40 00 00 00       	mov    $0x40,%eax
 2a9:	5b                   	pop    %rbx
 2aa:	5d                   	pop    %rbp
 2ab:	41 5c                	pop    %r12
 2ad:	41 5d                	pop    %r13
 2af:	c3                   	ret
 2b0:	b8 40 00 00 00       	mov    $0x40,%eax
 2b5:	c3                   	ret
