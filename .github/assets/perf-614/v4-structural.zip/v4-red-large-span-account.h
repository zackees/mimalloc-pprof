/* Internal implementation included by large-span.c after its private helpers. */
#ifndef MI_LARGE_SPAN_ACCOUNT_H
#define MI_LARGE_SPAN_ACCOUNT_H

void _mi_large_span_account_repurpose(mi_theap_t* theap, size_t index) {
  #if MI_LARGE_SPAN
  if (theap == NULL || index >= MI_LARGE_SPAN_BINS) return;
  const size_t bin_lo = _mi_bin(MI_MEDIUM_MAX_OBJ_SIZE + 1);
  (void)_mi_large_span_slices(theap, _mi_bin_size(bin_lo + index), 0);
  #else
  MI_UNUSED(theap); MI_UNUSED(index);
  #endif
}

#endif
