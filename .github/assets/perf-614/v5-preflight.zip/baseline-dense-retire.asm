 Percent |	Source code & Disassembly of perf_ab for cpu/cycles/P (243 samples, percent: local period)
----------------------------------------------------------------------------------------------------------
         :
         :
         :
         : 3     Disassembly of section .text:
         :
         : 5     0000000000020b90 <_mi_page_retire>:
         : 6     mi_assert_internal(page != NULL);
         : 7     mi_assert_expensive(_mi_page_is_valid(page));
         : 8     mi_assert_internal(mi_page_all_free(page));
         : 9     MI_GATE_ASSERT_HELD(mi_page_theap(page));   // #366: owner-private leaf (docs/purge-all-implementation.md §5.2)
         :
         : 11    if (page->retire_expire!=0) return;  // already retired, just keep it retired
    2.87 :   20b90:  cmpb   $0x0,0x16(%rdi)
    3.59 :   20b94:  je     20ba0 <_mi_page_retire+0x10>
    0.00 :   20b96:  ret
    0.00 :   20b97:  nopw   0x0(%rax,%rax,1)
         : 16    void _mi_page_retire(mi_page_t* page) mi_attr_noexcept {
    2.47 :   20ba0:  push   %rbp
    6.68 :   20ba1:  mov    %rsp,%rbp
    4.63 :   20ba4:  push   %r13
    5.45 :   20ba6:  push   %r12
    4.68 :   20ba8:  push   %rbx
    2.90 :   20ba9:  mov    %rdi,%rbx
    9.15 :   20bac:  sub    $0x8,%rsp
         : 24    }
         :
         : 26    static inline bool mi_page_flags_set(mi_page_t* page, bool set, mi_page_flags_t newflag) {
         : 27    mi_page_flags_t old;
         : 28    if (set) { old = mi_atomic_or_relaxed(&page->xthread_id, newflag); }
         : 29    else { old = mi_atomic_and_relaxed(&page->xthread_id, ~newflag); }
    0.35 :   20bb0:  lock andq $0xfffffffffffffffd,(%rdi)
         :
         :
         : 33    static inline mi_theap_t* mi_page_theap(const mi_page_t* page) {
         : 34    mi_assert_internal(!mi_page_is_abandoned(page));
         : 35    mi_assert_internal(page->theap != NULL && page->theap != &_mi_theap_empty);
         : 36    return page->theap;
    2.85 :   20bb5:  mov    0x38(%rdi),%r13
         : 38    return mi_atomic_load_relaxed(&((mi_page_t*)page)->xthread_id);
    0.73 :   20bb9:  mov    (%rdi),%rax
         : 40    (page->block_size > MI_LARGE_MAX_OBJ_SIZE ||
    2.14 :   20bbc:  mov    0x28(%rdi),%rdx
         : 42    mi_assert_internal(pq->count == count);
         : 43    return true;
         : 44    }
         :
         : 46    static size_t mi_page_bin(const mi_page_t* page) {
         : 47    const size_t bin = (mi_page_is_in_full(page) ? MI_BIN_FULL : (mi_page_is_huge(page) ? MI_BIN_HUGE : mi_bin(mi_page_block_size(page))));
    1.07 :   20bc0:  test   $0x1,%al
    0.47 :   20bc2:  jne    20c70 <_mi_page_retire+0xe0>
         : 50    return (mi_page_is_singleton(page) &&
    0.00 :   20bc8:  cmpw   $0x1,0x36(%rdi)
    0.00 :   20bcd:  je     20cd8 <_mi_page_retire+0x148>
         : 53    return (size + sizeof(uintptr_t) - 1) / sizeof(uintptr_t);
    0.00 :   20bd3:  lea    0x7(%rdx),%rcx
    0.00 :   20bd7:  mov    %rcx,%rax
    0.00 :   20bda:  shr    $0x3,%rax
         : 57    if mi_likely(wsize <= 8) {
    0.00 :   20bde:  cmp    $0x47,%rcx
    0.00 :   20be2:  ja     20d50 <_mi_page_retire+0x1c0>
         : 60    return (wsize <= 1 ? 1 : (wsize+1)&~1); // round to double word sizes
    0.00 :   20be8:  cmp    $0x1,%rax
    0.00 :   20bec:  jbe    20c60 <_mi_page_retire+0xd0>
    0.00 :   20bee:  add    $0x1,%rax
    0.00 :   20bf2:  and    $0xfffffffffffffffe,%rax
    0.00 :   20bf6:  lea    0x29(%rax),%r12
    0.00 :   20bfa:  shl    $0x5,%r12
         : 67    return (pq->block_size > MI_LARGE_MAX_OBJ_SIZE);
    0.94 :   20bfe:  shl    $0x5,%rax
         : 69    }
         :
         : 71    static mi_page_queue_t* mi_theap_page_queue_of(mi_theap_t* theap, const mi_page_t* page) {
         : 72    mi_assert_internal(theap!=NULL);
         : 73    const size_t bin = mi_page_bin(page);
         : 74    mi_page_queue_t* pq = &theap->pages[bin];
    2.34 :   20c02:  add    %r13,%r12
         : 76    return (pq->block_size > MI_LARGE_MAX_OBJ_SIZE);
    0.35 :   20c05:  add    %r13,%rax
         : 78    // how to check this efficiently though...
         : 79    // for now, we don't retire if it is the only page left of this size class.
         : 80    mi_page_queue_t* pq = mi_page_queue_of(page);
         : 81    #if MI_RETIRE_CYCLES > 0
         : 82    const size_t bsize = mi_page_block_size(page);
         : 83    if mi_likely( /* bsize < MI_MAX_RETIRE_SIZE && */ !mi_page_queue_is_special(pq)) {  // not full or huge queue?
    0.37 :   20c08:  cmpq   $0x80000,0x538(%rax)
    1.37 :   20c13:  ja     20c1e <_mi_page_retire+0x8e>
         : 86    if (pq->last==page && pq->first==page) { // the only page in the queue?
    1.28 :   20c15:  cmp    %rbx,0x528(%rax)
    0.47 :   20c1c:  je     20c80 <_mi_page_retire+0xf0>
         : 89    else { old = mi_atomic_and_relaxed(&page->xthread_id, ~newflag); }
    0.00 :   20c1e:  lock andq $0xfffffffffffffffd,(%rbx)
         : 91    mi_page_queue_remove(pq, page);
    0.00 :   20c23:  mov    %rbx,%rsi
    0.00 :   20c26:  mov    %r12,%rdi
    0.00 :   20c29:  call   1efb0 <mi_page_queue_remove>
         : 95    return page->theap;
    0.00 :   20c2e:  mov    0x38(%rbx),%rsi
         : 97    page->theap = theap;
    0.00 :   20c32:  movq   $0x0,0x38(%rbx)
         : 99    return mi_atomic_load_relaxed(&((mi_page_t*)page)->xthread_id);
    0.00 :   20c3a:  mov    (%rbx),%rax
         : 101   xtid = tid | (xtid_old & MI_PAGE_FLAG_MASK);
    0.00 :   20c3d:  mov    %rax,%rdx
    0.00 :   20c40:  and    $0x3,%edx
         : 104   } while (!mi_atomic_cas_weak_release(&page->xthread_id, &xtid_old, xtid));
    0.00 :   20c43:  lock cmpxchg %rdx,(%rbx)
    0.00 :   20c48:  jne    20c3d <_mi_page_retire+0xad>
         : 107   }
         : 108   }
         : 109   #endif
         : 110   MI_EVENT_IF(mi_page_block_size(page) > MI_MEDIUM_MAX_OBJ_SIZE && mi_page_block_size(page) <= MI_LARGE_MAX_OBJ_SIZE, MI_EVENT_LARGE_EMPTY_FREED);   // (#575)
         : 111   _mi_page_free(page, pq);
         : 112   }
    0.00 :   20c4a:  add    $0x8,%rsp
         : 114   _mi_arenas_page_free(page, theap);
    0.00 :   20c4e:  mov    %rbx,%rdi
         : 116   }
    0.00 :   20c51:  pop    %rbx
    0.00 :   20c52:  pop    %r12
    0.00 :   20c54:  pop    %r13
    0.00 :   20c56:  pop    %rbp
         : 121   _mi_arenas_page_free(page, theap);
    0.00 :   20c57:  jmp    f6a0 <_mi_arenas_page_free>
    0.00 :   20c5c:  nopl   0x0(%rax)
    0.00 :   20c60:  mov    $0x540,%r12d
         : 125   return (wsize <= 1 ? 1 : (wsize+1)&~1); // round to double word sizes
    0.00 :   20c66:  mov    $0x1,%eax
    0.00 :   20c6b:  jmp    20bfe <_mi_page_retire+0x6e>
    0.00 :   20c6d:  nopl   (%rax)
         : 129   (page->block_size > MI_LARGE_MAX_OBJ_SIZE ||
    0.00 :   20c70:  mov    $0xe60,%r12d
         : 131   const size_t bin = (mi_page_is_in_full(page) ? MI_BIN_FULL : (mi_page_is_huge(page) ? MI_BIN_HUGE : mi_bin(mi_page_block_size(page))));
    0.00 :   20c76:  mov    $0x4a,%eax
    0.00 :   20c7b:  jmp    20bfe <_mi_page_retire+0x6e>
    0.00 :   20c7d:  nopl   (%rax)
         : 135   if (pq->last==page && pq->first==page) { // the only page in the queue?
    0.00 :   20c80:  cmp    %rbx,0x520(%rax)
    0.00 :   20c87:  jne    20c1e <_mi_page_retire+0x8e>
         : 138   page->retire_expire = (bsize <= MI_SMALL_MAX_OBJ_SIZE ? MI_RETIRE_CYCLES : MI_RETIRE_CYCLES/4);
    1.66 :   20c89:  cmp    $0x2800,%rdx
    0.00 :   20c90:  ja     20d60 <_mi_page_retire+0x1d0>
    0.00 :   20c96:  movb   $0x10,0x16(%rbx)
         : 142   const size_t index = pq - theap->pages;
    0.67 :   20c9a:  lea    0x520(%r13),%rax
    0.00 :   20ca1:  sub    %rax,%r12
    0.88 :   20ca4:  sar    $0x5,%r12
         : 146   if (index < theap->page_retired_min) theap->page_retired_min = index;
    0.00 :   20ca8:  cmp    0xc0(%r13),%r12
    0.46 :   20caf:  jae    20cb8 <_mi_page_retire+0x128>
    1.18 :   20cb1:  mov    %r12,0xc0(%r13)
         : 150   if (index > theap->page_retired_max) theap->page_retired_max = index;
    0.71 :   20cb8:  cmp    %r12,0xc8(%r13)
    0.43 :   20cbf:  jae    20cc8 <_mi_page_retire+0x138>
    0.42 :   20cc1:  mov    %r12,0xc8(%r13)
         : 154   }
    0.51 :   20cc8:  add    $0x8,%rsp
    0.00 :   20ccc:  pop    %rbx
    1.31 :   20ccd:  pop    %r12
    0.46 :   20ccf:  pop    %r13
    0.00 :   20cd1:  pop    %rbp
    1.19 :   20cd2:  ret
    0.00 :   20cd3:  nopl   0x0(%rax,%rax,1)
         : 162   return (mi_page_is_singleton(page) &&
    0.00 :   20cd8:  cmp    $0x80000,%rdx
    0.00 :   20cdf:  ja     20d40 <_mi_page_retire+0x1b0>
         : 165   MI_MEM_ARENA,     // allocated from an arena (the usual case) (`arena.c`)
         : 166   MI_MEM_MALLOC     // allocated with mi_malloc
         : 167   } mi_memkind_t;
         :
         : 169   static inline bool mi_memkind_is_os(mi_memkind_t memkind) {
         : 170   return (memkind >= MI_MEM_OS && memkind <= MI_MEM_OS_REMAP);
    0.00 :   20ce1:  mov    0x68(%rdi),%eax
    0.00 :   20ce4:  sub    $0x3,%eax
         : 173   (page->block_size > MI_LARGE_MAX_OBJ_SIZE ||
    0.00 :   20ce7:  cmp    $0x2,%eax
    0.00 :   20cea:  jbe    20d30 <_mi_page_retire+0x1a0>
         : 176   return (size + sizeof(uintptr_t) - 1) / sizeof(uintptr_t);
    0.00 :   20cec:  lea    0x7(%rdx),%rcx
    0.00 :   20cf0:  mov    %rcx,%rax
    0.00 :   20cf3:  shr    $0x3,%rax
         : 180   if mi_likely(wsize <= 8) {
    0.00 :   20cf7:  cmp    $0x47,%rcx
    0.00 :   20cfb:  jbe    20be8 <_mi_page_retire+0x58>
    0.00 :   20d01:  nopl   0x0(%rax)
         : 184   wsize--;
    0.42 :   20d08:  sub    $0x1,%rax
         : 186   const size_t b = (MI_SIZE_BITS - 1 - mi_clz(wsize));  // note: wsize != 0
    9.16 :   20d0c:  bsr    %rax,%rsi
         : 188   const size_t bin = ((b << 2) + ((wsize >> (b - 2)) & 0x03)) - 3;
    0.90 :   20d10:  lea    -0x2(%rsi),%ecx
    0.83 :   20d13:  shr    %cl,%rax
    0.00 :   20d16:  and    $0x3,%eax
    2.41 :   20d19:  lea    -0x3(%rax,%rsi,4),%rax
         : 193   return bin;
    0.34 :   20d1e:  lea    0x29(%rax),%r12
    0.88 :   20d22:  shl    $0x5,%r12
    0.87 :   20d26:  jmp    20bfe <_mi_page_retire+0x6e>
    0.00 :   20d2b:  nopl   0x0(%rax,%rax,1)
         : 198   (mi_memkind_is_os(page->memid.memkind) && page->memid.mem.os.base < (void*)page)));
    0.00 :   20d30:  cmp    %rdi,0x58(%rdi)
    0.00 :   20d34:  jae    20cec <_mi_page_retire+0x15c>
    0.00 :   20d36:  cs nopw 0x0(%rax,%rax,1)
    0.00 :   20d40:  mov    $0xe40,%r12d
         : 203   const size_t bin = (mi_page_is_in_full(page) ? MI_BIN_FULL : (mi_page_is_huge(page) ? MI_BIN_HUGE : mi_bin(mi_page_block_size(page))));
    0.00 :   20d46:  mov    $0x49,%eax
    0.00 :   20d4b:  jmp    20bfe <_mi_page_retire+0x6e>
         : 206   else if mi_unlikely(wsize > MI_LARGE_MAX_OBJ_WSIZE) {
    1.26 :   20d50:  cmp    $0x10000,%rax
    0.00 :   20d56:  jbe    20d08 <_mi_page_retire+0x178>
    0.00 :   20d58:  jmp    20d40 <_mi_page_retire+0x1b0>
    0.00 :   20d5a:  nopw   0x0(%rax,%rax,1)
         : 211   page->retire_expire = (bsize <= MI_SMALL_MAX_OBJ_SIZE ? MI_RETIRE_CYCLES : MI_RETIRE_CYCLES/4);
    3.44 :   20d60:  movb   $0x4,0x16(%rbx)
         : 213   if (bsize > MI_MEDIUM_MAX_OBJ_SIZE) { _mi_page_publish_retired(page); }   // #483: so an idle owner cannot pin it
    2.20 :   20d64:  cmp    $0x152aa,%rdx
    1.13 :   20d6b:  jbe    20c9a <_mi_page_retire+0x10a>
    2.59 :   20d71:  mov    %rbx,%rdi
    6.54 :   20d74:  call   26640 <_mi_page_publish_retired>
    0.00 :   20d79:  jmp    20c9a <_mi_page_retire+0x10a>
