"""Focused local x86-64 code-generation check, not a portable CI gate."""
from pathlib import Path
import re
import sys
text = Path(sys.argv[1]).read_text()
lines = text.splitlines()
refs = [i for i, line in enumerate(lines) if 'R_X86_64_PLT32' in line and '_mi_page_publish_retired-' in line]
assert len(refs) == 1, 'expected one publication transfer in _mi_page_retire'
transfer = lines[refs[0] - 1]
print('Publication transfer:', transfer, flush=True)
assert re.search(r'\bjmp\b', transfer), 'publication has a returning call; owner bookkeeping keeps state live across it'
print('PASS: publication is a tail transfer')
