
/tmp/mimalloc-614-campaign/retire-order-baseline.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000002130 <_mi_page_retire>:
    2130:	80 7f 16 00          	cmpb   $0x0,0x16(%rdi)
    2134:	74 0a                	je     2140 <_mi_page_retire+0x10>
    2136:	c3                   	ret
    2137:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    213e:	00 00 
    2140:	41 54                	push   %r12
    2142:	55                   	push   %rbp
    2143:	53                   	push   %rbx
    2144:	48 89 fb             	mov    %rdi,%rbx
    2147:	f0 48 83 27 fd       	lock andq $0xfffffffffffffffd,(%rdi)
    214c:	4c 8b 67 38          	mov    0x38(%rdi),%r12
    2150:	48 8b 07             	mov    (%rdi),%rax
    2153:	48 8b 57 28          	mov    0x28(%rdi),%rdx
    2157:	a8 01                	test   $0x1,%al
    2159:	0f 85 a1 00 00 00    	jne    2200 <_mi_page_retire+0xd0>
    215f:	66 83 7f 36 01       	cmpw   $0x1,0x36(%rdi)
    2164:	0f 84 fe 00 00 00    	je     2268 <_mi_page_retire+0x138>
    216a:	48 8d 4a 07          	lea    0x7(%rdx),%rcx
    216e:	48 89 c8             	mov    %rcx,%rax
    2171:	48 c1 e8 03          	shr    $0x3,%rax
    2175:	48 83 f9 47          	cmp    $0x47,%rcx
    2179:	0f 87 61 01 00 00    	ja     22e0 <_mi_page_retire+0x1b0>
    217f:	48 83 f8 01          	cmp    $0x1,%rax
    2183:	76 6b                	jbe    21f0 <_mi_page_retire+0xc0>
    2185:	48 83 c0 01          	add    $0x1,%rax
    2189:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    218d:	48 8d 68 29          	lea    0x29(%rax),%rbp
    2191:	48 c1 e5 05          	shl    $0x5,%rbp
    2195:	48 c1 e0 05          	shl    $0x5,%rax
    2199:	4c 01 e5             	add    %r12,%rbp
    219c:	4c 01 e0             	add    %r12,%rax
    219f:	48 81 b8 38 05 00 00 	cmpq   $0x80000,0x538(%rax)
    21a6:	00 00 08 00 
    21aa:	77 09                	ja     21b5 <_mi_page_retire+0x85>
    21ac:	48 39 98 28 05 00 00 	cmp    %rbx,0x528(%rax)
    21b3:	74 5b                	je     2210 <_mi_page_retire+0xe0>
    21b5:	f0 48 83 23 fd       	lock andq $0xfffffffffffffffd,(%rbx)
    21ba:	48 89 de             	mov    %rbx,%rsi
    21bd:	48 89 ef             	mov    %rbp,%rdi
    21c0:	e8 1b e4 ff ff       	call   5e0 <mi_page_queue_remove>
    21c5:	48 8b 73 38          	mov    0x38(%rbx),%rsi
    21c9:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    21d0:	00 
    21d1:	48 8b 03             	mov    (%rbx),%rax
    21d4:	48 89 c2             	mov    %rax,%rdx
    21d7:	83 e2 03             	and    $0x3,%edx
    21da:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    21df:	75 f3                	jne    21d4 <_mi_page_retire+0xa4>
    21e1:	48 89 df             	mov    %rbx,%rdi
    21e4:	5b                   	pop    %rbx
    21e5:	5d                   	pop    %rbp
    21e6:	41 5c                	pop    %r12
    21e8:	e9 00 00 00 00       	jmp    21ed <_mi_page_retire+0xbd>
			21e9: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    21ed:	0f 1f 00             	nopl   (%rax)
    21f0:	bd 40 05 00 00       	mov    $0x540,%ebp
    21f5:	b8 01 00 00 00       	mov    $0x1,%eax
    21fa:	eb 99                	jmp    2195 <_mi_page_retire+0x65>
    21fc:	0f 1f 40 00          	nopl   0x0(%rax)
    2200:	bd 60 0e 00 00       	mov    $0xe60,%ebp
    2205:	b8 4a 00 00 00       	mov    $0x4a,%eax
    220a:	eb 89                	jmp    2195 <_mi_page_retire+0x65>
    220c:	0f 1f 40 00          	nopl   0x0(%rax)
    2210:	48 39 98 20 05 00 00 	cmp    %rbx,0x520(%rax)
    2217:	75 9c                	jne    21b5 <_mi_page_retire+0x85>
    2219:	48 81 fa 00 28 00 00 	cmp    $0x2800,%rdx
    2220:	0f 87 ca 00 00 00    	ja     22f0 <_mi_page_retire+0x1c0>
    2226:	c6 43 16 10          	movb   $0x10,0x16(%rbx)
    222a:	49 8d 84 24 20 05 00 	lea    0x520(%r12),%rax
    2231:	00 
    2232:	48 29 c5             	sub    %rax,%rbp
    2235:	48 c1 fd 05          	sar    $0x5,%rbp
    2239:	49 3b ac 24 c0 00 00 	cmp    0xc0(%r12),%rbp
    2240:	00 
    2241:	73 08                	jae    224b <_mi_page_retire+0x11b>
    2243:	49 89 ac 24 c0 00 00 	mov    %rbp,0xc0(%r12)
    224a:	00 
    224b:	49 39 ac 24 c8 00 00 	cmp    %rbp,0xc8(%r12)
    2252:	00 
    2253:	73 08                	jae    225d <_mi_page_retire+0x12d>
    2255:	49 89 ac 24 c8 00 00 	mov    %rbp,0xc8(%r12)
    225c:	00 
    225d:	5b                   	pop    %rbx
    225e:	5d                   	pop    %rbp
    225f:	41 5c                	pop    %r12
    2261:	c3                   	ret
    2262:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2268:	48 81 fa 00 00 08 00 	cmp    $0x80000,%rdx
    226f:	77 5f                	ja     22d0 <_mi_page_retire+0x1a0>
    2271:	8b 47 68             	mov    0x68(%rdi),%eax
    2274:	83 e8 03             	sub    $0x3,%eax
    2277:	83 f8 02             	cmp    $0x2,%eax
    227a:	76 44                	jbe    22c0 <_mi_page_retire+0x190>
    227c:	48 8d 4a 07          	lea    0x7(%rdx),%rcx
    2280:	48 89 c8             	mov    %rcx,%rax
    2283:	48 c1 e8 03          	shr    $0x3,%rax
    2287:	48 83 f9 47          	cmp    $0x47,%rcx
    228b:	0f 86 ee fe ff ff    	jbe    217f <_mi_page_retire+0x4f>
    2291:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2298:	48 83 e8 01          	sub    $0x1,%rax
    229c:	48 0f bd f0          	bsr    %rax,%rsi
    22a0:	8d 4e fe             	lea    -0x2(%rsi),%ecx
    22a3:	48 d3 e8             	shr    %cl,%rax
    22a6:	83 e0 03             	and    $0x3,%eax
    22a9:	48 8d 44 b0 fd       	lea    -0x3(%rax,%rsi,4),%rax
    22ae:	48 8d 68 29          	lea    0x29(%rax),%rbp
    22b2:	48 c1 e5 05          	shl    $0x5,%rbp
    22b6:	e9 da fe ff ff       	jmp    2195 <_mi_page_retire+0x65>
    22bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    22c0:	48 39 7f 58          	cmp    %rdi,0x58(%rdi)
    22c4:	73 b6                	jae    227c <_mi_page_retire+0x14c>
    22c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    22cd:	00 00 00 
    22d0:	bd 40 0e 00 00       	mov    $0xe40,%ebp
    22d5:	b8 49 00 00 00       	mov    $0x49,%eax
    22da:	e9 b6 fe ff ff       	jmp    2195 <_mi_page_retire+0x65>
    22df:	90                   	nop
    22e0:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    22e6:	76 b0                	jbe    2298 <_mi_page_retire+0x168>
    22e8:	eb e6                	jmp    22d0 <_mi_page_retire+0x1a0>
    22ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    22f0:	c6 43 16 04          	movb   $0x4,0x16(%rbx)
    22f4:	48 81 fa aa 52 01 00 	cmp    $0x152aa,%rdx
    22fb:	0f 86 29 ff ff ff    	jbe    222a <_mi_page_retire+0xfa>
    2301:	48 89 df             	mov    %rbx,%rdi
    2304:	e8 00 00 00 00       	call   2309 <_mi_page_retire+0x1d9>
			2305: R_X86_64_PLT32	_mi_page_publish_retired-0x4
    2309:	e9 1c ff ff ff       	jmp    222a <_mi_page_retire+0xfa>
