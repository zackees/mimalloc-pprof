
/tmp/mimalloc-614-campaign/retire-order-reordered.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000002130 <_mi_page_retire>:
    2130:	80 7f 16 00          	cmpb   $0x0,0x16(%rdi)
    2134:	74 0a                	je     2140 <_mi_page_retire+0x10>
    2136:	c3                   	ret
    2137:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    213e:	00 00 
    2140:	53                   	push   %rbx
    2141:	48 89 fb             	mov    %rdi,%rbx
    2144:	f0 48 83 27 fd       	lock andq $0xfffffffffffffffd,(%rdi)
    2149:	48 8b 57 38          	mov    0x38(%rdi),%rdx
    214d:	48 8b 07             	mov    (%rdi),%rax
    2150:	48 8b 77 28          	mov    0x28(%rdi),%rsi
    2154:	a8 01                	test   $0x1,%al
    2156:	0f 85 9c 00 00 00    	jne    21f8 <_mi_page_retire+0xc8>
    215c:	66 83 7f 36 01       	cmpw   $0x1,0x36(%rdi)
    2161:	0f 84 f9 00 00 00    	je     2260 <_mi_page_retire+0x130>
    2167:	48 8d 4e 07          	lea    0x7(%rsi),%rcx
    216b:	48 89 c8             	mov    %rcx,%rax
    216e:	48 c1 e8 03          	shr    $0x3,%rax
    2172:	48 83 f9 47          	cmp    $0x47,%rcx
    2176:	0f 87 54 01 00 00    	ja     22d0 <_mi_page_retire+0x1a0>
    217c:	48 83 f8 01          	cmp    $0x1,%rax
    2180:	76 66                	jbe    21e8 <_mi_page_retire+0xb8>
    2182:	48 83 c0 01          	add    $0x1,%rax
    2186:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    218a:	48 8d 78 29          	lea    0x29(%rax),%rdi
    218e:	48 c1 e7 05          	shl    $0x5,%rdi
    2192:	48 c1 e0 05          	shl    $0x5,%rax
    2196:	48 01 d7             	add    %rdx,%rdi
    2199:	48 01 d0             	add    %rdx,%rax
    219c:	48 81 b8 38 05 00 00 	cmpq   $0x80000,0x538(%rax)
    21a3:	00 00 08 00 
    21a7:	77 09                	ja     21b2 <_mi_page_retire+0x82>
    21a9:	48 39 98 28 05 00 00 	cmp    %rbx,0x528(%rax)
    21b0:	74 56                	je     2208 <_mi_page_retire+0xd8>
    21b2:	f0 48 83 23 fd       	lock andq $0xfffffffffffffffd,(%rbx)
    21b7:	48 89 de             	mov    %rbx,%rsi
    21ba:	e8 21 e4 ff ff       	call   5e0 <mi_page_queue_remove>
    21bf:	48 8b 73 38          	mov    0x38(%rbx),%rsi
    21c3:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    21ca:	00 
    21cb:	48 8b 03             	mov    (%rbx),%rax
    21ce:	48 89 c2             	mov    %rax,%rdx
    21d1:	83 e2 03             	and    $0x3,%edx
    21d4:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    21d9:	75 f3                	jne    21ce <_mi_page_retire+0x9e>
    21db:	48 89 df             	mov    %rbx,%rdi
    21de:	5b                   	pop    %rbx
    21df:	e9 00 00 00 00       	jmp    21e4 <_mi_page_retire+0xb4>
			21e0: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    21e4:	0f 1f 40 00          	nopl   0x0(%rax)
    21e8:	bf 40 05 00 00       	mov    $0x540,%edi
    21ed:	b8 01 00 00 00       	mov    $0x1,%eax
    21f2:	eb 9e                	jmp    2192 <_mi_page_retire+0x62>
    21f4:	0f 1f 40 00          	nopl   0x0(%rax)
    21f8:	bf 60 0e 00 00       	mov    $0xe60,%edi
    21fd:	b8 4a 00 00 00       	mov    $0x4a,%eax
    2202:	eb 8e                	jmp    2192 <_mi_page_retire+0x62>
    2204:	0f 1f 40 00          	nopl   0x0(%rax)
    2208:	48 39 98 20 05 00 00 	cmp    %rbx,0x520(%rax)
    220f:	75 a1                	jne    21b2 <_mi_page_retire+0x82>
    2211:	48 81 fe 01 28 00 00 	cmp    $0x2801,%rsi
    2218:	19 c0                	sbb    %eax,%eax
    221a:	83 e0 0c             	and    $0xc,%eax
    221d:	83 c0 04             	add    $0x4,%eax
    2220:	88 43 16             	mov    %al,0x16(%rbx)
    2223:	48 8d 82 20 05 00 00 	lea    0x520(%rdx),%rax
    222a:	48 29 c7             	sub    %rax,%rdi
    222d:	48 c1 ff 05          	sar    $0x5,%rdi
    2231:	48 3b ba c0 00 00 00 	cmp    0xc0(%rdx),%rdi
    2238:	73 07                	jae    2241 <_mi_page_retire+0x111>
    223a:	48 89 ba c0 00 00 00 	mov    %rdi,0xc0(%rdx)
    2241:	48 39 ba c8 00 00 00 	cmp    %rdi,0xc8(%rdx)
    2248:	73 07                	jae    2251 <_mi_page_retire+0x121>
    224a:	48 89 ba c8 00 00 00 	mov    %rdi,0xc8(%rdx)
    2251:	48 81 fe aa 52 01 00 	cmp    $0x152aa,%rsi
    2258:	0f 87 7c 00 00 00    	ja     22da <_mi_page_retire+0x1aa>
    225e:	5b                   	pop    %rbx
    225f:	c3                   	ret
    2260:	48 81 fe 00 00 08 00 	cmp    $0x80000,%rsi
    2267:	77 57                	ja     22c0 <_mi_page_retire+0x190>
    2269:	8b 47 68             	mov    0x68(%rdi),%eax
    226c:	83 e8 03             	sub    $0x3,%eax
    226f:	83 f8 02             	cmp    $0x2,%eax
    2272:	76 44                	jbe    22b8 <_mi_page_retire+0x188>
    2274:	48 8d 4e 07          	lea    0x7(%rsi),%rcx
    2278:	48 89 c8             	mov    %rcx,%rax
    227b:	48 c1 e8 03          	shr    $0x3,%rax
    227f:	48 83 f9 47          	cmp    $0x47,%rcx
    2283:	0f 86 f3 fe ff ff    	jbe    217c <_mi_page_retire+0x4c>
    2289:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2290:	48 83 e8 01          	sub    $0x1,%rax
    2294:	48 0f bd f8          	bsr    %rax,%rdi
    2298:	8d 4f fe             	lea    -0x2(%rdi),%ecx
    229b:	48 d3 e8             	shr    %cl,%rax
    229e:	83 e0 03             	and    $0x3,%eax
    22a1:	48 8d 44 b8 fd       	lea    -0x3(%rax,%rdi,4),%rax
    22a6:	48 8d 78 29          	lea    0x29(%rax),%rdi
    22aa:	48 c1 e7 05          	shl    $0x5,%rdi
    22ae:	e9 df fe ff ff       	jmp    2192 <_mi_page_retire+0x62>
    22b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    22b8:	48 39 7f 58          	cmp    %rdi,0x58(%rdi)
    22bc:	73 b6                	jae    2274 <_mi_page_retire+0x144>
    22be:	66 90                	xchg   %ax,%ax
    22c0:	bf 40 0e 00 00       	mov    $0xe40,%edi
    22c5:	b8 49 00 00 00       	mov    $0x49,%eax
    22ca:	e9 c3 fe ff ff       	jmp    2192 <_mi_page_retire+0x62>
    22cf:	90                   	nop
    22d0:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    22d6:	76 b8                	jbe    2290 <_mi_page_retire+0x160>
    22d8:	eb e6                	jmp    22c0 <_mi_page_retire+0x190>
    22da:	48 89 df             	mov    %rbx,%rdi
    22dd:	5b                   	pop    %rbx
    22de:	e9 00 00 00 00       	jmp    22e3 <_mi_page_retire+0x1b3>
			22df: R_X86_64_PLT32	_mi_page_publish_retired-0x4
