# Remaining retirement cost investigation

Baseline remains 227eef06ff03f92966f38508441d6c2f60a75135. No production edits or new acceptance dispatch.

Three denser profiles ran the exact existing baseline executables, checked against attribution-provenance.json, with unchanged 8-thread traces at 4999 Hz. Commands and identities are in baseline-dense-provenance.json. Raw data, reports, stdout/stderr are retained. No timing from these runs is acceptance evidence. Kernel symbols are restricted. Dense large and chart profiles show substantial instrumentation/system perturbation; their percentages must not be compared to the earlier profiles as a performance delta. The large run has 42,236 samples and no reported lost samples.

Plain ephemeral self samples: _mi_page_retire 1.79%, _mi_page_publish_retired 1.78%, mi_page_extend_free 0.77%, _mi_page_unpurge_all 0.65%, _mi_page_repurpose_find 0.37%. The first two remain investigation leads. No claimed CPU saving follows from these percentages.

`baseline-dense-retire.asm` shows register saves around the call to _mi_page_publish_retired, followed by updates to the owner's page_retired_min/max. `retire-release-baseline.asm` from the existing optimized codegen build confirms three saved registers in ordinary release code too; that build contains the historical V4 accounting code, but _mi_page_retire is unchanged. It is supporting assembly, not a new exact-baseline build.

Hypothesis: perform identical owner-local retired-bin min/max bookkeeping before publication, so the publication call can be a tail call and no longer keeps theap/queue live across it. This differs from V1/V2 unpurge checks and V3/V4 span accounting. No selection/geometry/aging/retention/purge policy change is proposed.

Required next checks before adopting: review _mi_page_publish_retired and all callees/probes for any observation of retired bounds/reentrant owner behavior; preserve ownership/concurrent scavenger protocol; compile a scratch reordered variant against exact baseline and inspect whether the saves actually disappear on the hot path; design focused RED/GREEN work/codegen evidence and state/correctness tests. If compiler keeps the same work or ordering cannot be justified, reject this lead without launching a performance campaign. This note is not authorization to bypass the existing stage-one screen or platform gates.
