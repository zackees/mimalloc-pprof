# V5 preflight rejection

Candidate C commit 615d123c; generated Rust commit 9a828ba4. The candidate moved publication after owner-local retired-bin bounds updates. Optimized x86-64 code used one saved register instead of three and a tail jump instead of returning call. Focused codegen check was RED on baseline and GREEN on candidate; existing C 3/3, C++ 2/2, ASan with owner gate 2/2 passed. These checks did not cover primitive-reuse failure callbacks.

Review identified a plausible reentrant collection/use-after-free path through the output callback, so the candidate is rejected before any performance dispatch. This is a static safety finding, not a reproduced crash or measured regression. No CPU benefit is claimed. C removal 9605cbe9 and Rust removal 73e47a0a restore production source exactly to frozen baseline 227eef06. No source fix or new guard is included.

Dense profiles are attribution only, with substantial kernel/profiler perturbation in the large/chart runs; do not infer timings or changed workload costs from them. Exact baseline executables are retained in attribution.zip with matching provenance hashes. Local codegen checks are x86-64-specific and not a new CI requirement. All objects, commands, patches, test executables/logs and raw diagnostic profiles are retained here. Broad platform validation was not dispatched for this rejected candidate.
