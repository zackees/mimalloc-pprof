"""Report original V6 cohorts without pooling or altering numeric verdicts."""
from pathlib import Path
import json
from collections import Counter
ROOT=Path('/tmp/mimalloc-614-campaign')
manifest=json.loads((ROOT/'v6-dispatch-manifest.json').read_text())
counts=Counter()
rows=[]
gains=[]
missing=[]
for row in manifest['runs']:
    run_id=row['response']['workflow_run_id']
    source=ROOT/'v6-downloads'/str(run_id)/'verified-ledger.json'
    if not source.exists():
        missing.append(run_id)
        continue
    data=json.loads(source.read_text())
    assert data['baseline']==manifest['baseline'] and data['candidate']==manifest['candidate']
    assert data['workload']==row['workload']
    for cell in data.get('cells',[]):
        counts[cell['verdict']]+=1
        _,lo,hi=cell['change']
        if (cell['metric']=='ops/s' and lo>0) or (cell['metric']=='cpu s' and hi<0):
            gains.append({'workload':row['workload'],'metric':cell['metric'],'change':cell['change']})
    rows.append({'run_id':run_id,**data})
# This is only the declared stage-one screening decision, never merge acceptance.
if counts['FAIL']:
    decision='STOP: confirmed per-cell regression; collect remaining originals without stage two'
elif missing:
    decision='PENDING: original cohorts still missing; do not dispatch stage two'
elif any(not r.get('complete') or not r.get('release_held') for r in rows):
    decision='STOP: incomplete evidence or release-bound violation'
elif not gains:
    decision='STOP: no statistically supported target CPU/throughput gain'
else:
    decision='Stage-one numeric screen met; verify original workflow/sanity completion before stage-two dispatch'
result={'baseline':manifest['baseline'],'candidate':manifest['candidate'],'missing_runs':missing,
        'verdict_counts':dict(counts),'supported_target_gains':gains,'decision':decision,'rows':rows}
(ROOT/'v6-stage-one-results.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# V6 original stage-one ledger','',f"Baseline `{manifest['baseline']}`; candidate `{manifest['candidate']}`.",'',decision,'',
       'Original per-host paired cohorts only; zero memory credit. Intervals and verdicts are retained.','']
for row in rows:
    lines.extend([f"## {row['workload']}",'',f"Run {row['run_id']}; {row['cpu']}; samples per arm: {row['counts']}.",'',
        '| Metric | Change % [95% CI] | Allowance % | Verdict |','| --- | --- | --- | --- |'])
    for c in row.get('cells',[]):
        point,lo,hi=c['change']
        lines.append(f"| {c['metric']} | {point:+.4f} [{lo:+.4f}, {hi:+.4f}] | {c['allowance']:.4f} | {c['verdict']} |")
    lines.extend(['',f"Release p95: {row.get('p95_release_ms')} ms; bound: {row.get('release_bound_ms')} ms; held: {row.get('release_held')}.",''])
(ROOT/'v6-stage-one-ledger.md').write_text('\n'.join(lines)+'\n')
print(decision)
print(dict(counts))
print('Supported target gains:',gains)
