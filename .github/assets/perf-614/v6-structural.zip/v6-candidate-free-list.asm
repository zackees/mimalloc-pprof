
/tmp/mimalloc-614-campaign/v6-page.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <mi_page_free_list_extend>:
       0:	0f b7 47 14          	movzwl 0x14(%rdi),%eax
       4:	48 89 d1             	mov    %rdx,%rcx
       7:	8b 57 30             	mov    0x30(%rdi),%edx
       a:	49 89 c0             	mov    %rax,%r8
       d:	48 8d 44 08 ff       	lea    -0x1(%rax,%rcx,1),%rax
      12:	48 c1 e2 04          	shl    $0x4,%rdx
      16:	4c 0f af c6          	imul   %rsi,%r8
      1a:	48 01 fa             	add    %rdi,%rdx
      1d:	48 0f af c6          	imul   %rsi,%rax
      21:	49 01 d0             	add    %rdx,%r8
      24:	48 01 c2             	add    %rax,%rdx
      27:	49 39 d0             	cmp    %rdx,%r8
      2a:	73 12                	jae    3e <mi_page_free_list_extend+0x3e>
      2c:	4c 89 c0             	mov    %r8,%rax
      2f:	90                   	nop
      30:	48 89 c1             	mov    %rax,%rcx
      33:	48 01 f0             	add    %rsi,%rax
      36:	48 89 01             	mov    %rax,(%rcx)
      39:	48 39 d0             	cmp    %rdx,%rax
      3c:	72 f2                	jb     30 <mi_page_free_list_extend+0x30>
      3e:	48 8b 47 08          	mov    0x8(%rdi),%rax
      42:	48 89 02             	mov    %rax,(%rdx)
      45:	4c 89 47 08          	mov    %r8,0x8(%rdi)
      49:	c3                   	ret
