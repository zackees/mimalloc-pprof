# V6 structural evidence, not performance acceptance

C commit e79fab3c; generated Rust commit 886655b0. Baseline 227eef06ff03f92966f38508441d6c2f60a75135.

The sequential free-list initializer wrote the last link to one-past, then overwrote it with the existing head. The optimized baseline object retains this store and loop iteration. V6 uses a strict loop bound, leaving the final setter unchanged. The same helper/function is shared with a test through headers; a test-only setter macro counts writes without changing production setter calls.

RED v6-red-executable aborts for a singleton extension: writes=2, required1. The exact executable, log, unchanged-loop headers, test source and tracked patch are retained. GREEN C4/4, secure C++3/3 (MI_SECURE=5), actual ASan with owner gate3/3. Test validates decoded links for three sizes, two starting capacities, four lengths, plus prepend in secure mode. Existing event/span/purge tests retained. Ordinary baseline/candidate assembly differs in comparison directions/branch conditions, skipping one loop iteration including one link write.

No selection, geometry, extension count, publication/callback order, retention, aging or purge policy change. Zero memory credit planned. No CPU gain claimed before the fixed-baseline performance campaign. The original local diagnostic profiles are preserved in attribution.zip and v5-preflight.zip; their timings are not acceptance evidence.

Commands: build the listed CMake test targets with their recorded configurations; run ctest -R '^(test-free-list-links|test-event-counters|test-large-span|test-purge-holes)$' as applicable. Red reconstruction needs the archived tracked patch plus its separately archived new headers and test. Restore executable permissions when replaying zip binaries. The exact source diff and codegen command are included. Full platform validation remains pending.
