
/tmp/mimalloc-614-campaign/baseline-plain/perf_ab:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000001efb0 <mi_page_queue_remove>:
   1efb0:	55                   	push   %rbp
   1efb1:	48 89 e5             	mov    %rsp,%rbp
   1efb4:	41 57                	push   %r15
   1efb6:	41 56                	push   %r14
   1efb8:	41 55                	push   %r13
   1efba:	49 89 fd             	mov    %rdi,%r13
   1efbd:	41 54                	push   %r12
   1efbf:	53                   	push   %rbx
   1efc0:	48 89 f3             	mov    %rsi,%rbx
   1efc3:	48 83 ec 08          	sub    $0x8,%rsp
   1efc7:	48 8b 56 50          	mov    0x50(%rsi),%rdx
   1efcb:	4c 8b 66 38          	mov    0x38(%rsi),%r12
   1efcf:	48 85 d2             	test   %rdx,%rdx
   1efd2:	74 08                	je     1efdc <mi_page_queue_remove+0x2c>
   1efd4:	48 8b 46 48          	mov    0x48(%rsi),%rax
   1efd8:	48 89 42 48          	mov    %rax,0x48(%rdx)
   1efdc:	48 8b 43 48          	mov    0x48(%rbx),%rax
   1efe0:	48 85 c0             	test   %rax,%rax
   1efe3:	74 04                	je     1efe9 <mi_page_queue_remove+0x39>
   1efe5:	48 89 50 50          	mov    %rdx,0x50(%rax)
   1efe9:	49 39 5d 08          	cmp    %rbx,0x8(%r13)
   1efed:	74 51                	je     1f040 <mi_page_queue_remove+0x90>
   1efef:	49 39 5d 00          	cmp    %rbx,0x0(%r13)
   1eff3:	74 59                	je     1f04e <mi_page_queue_remove+0x9e>
   1eff5:	49 83 ac 24 b8 00 00 	subq   $0x1,0xb8(%r12)
   1effc:	00 01 
   1effe:	66 0f ef c0          	pxor   %xmm0,%xmm0
   1f002:	49 83 6d 10 01       	subq   $0x1,0x10(%r13)
   1f007:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
   1f00b:	f0 48 0f ba 33 00    	lock btrq $0x0,(%rbx)
   1f011:	73 19                	jae    1f02c <mi_page_queue_remove+0x7c>
   1f013:	48 8b 43 38          	mov    0x38(%rbx),%rax
   1f017:	48 85 c0             	test   %rax,%rax
   1f01a:	74 10                	je     1f02c <mi_page_queue_remove+0x7c>
   1f01c:	0f b7 53 36          	movzwl 0x36(%rbx),%edx
   1f020:	48 0f af 53 28       	imul   0x28(%rbx),%rdx
   1f025:	48 29 90 d0 00 00 00 	sub    %rdx,0xd0(%rax)
   1f02c:	48 83 c4 08          	add    $0x8,%rsp
   1f030:	5b                   	pop    %rbx
   1f031:	41 5c                	pop    %r12
   1f033:	41 5d                	pop    %r13
   1f035:	41 5e                	pop    %r14
   1f037:	41 5f                	pop    %r15
   1f039:	5d                   	pop    %rbp
   1f03a:	c3                   	ret
   1f03b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1f040:	48 8b 53 50          	mov    0x50(%rbx),%rdx
   1f044:	49 89 55 08          	mov    %rdx,0x8(%r13)
   1f048:	49 39 5d 00          	cmp    %rbx,0x0(%r13)
   1f04c:	75 a7                	jne    1eff5 <mi_page_queue_remove+0x45>
   1f04e:	4d 8b 75 18          	mov    0x18(%r13),%r14
   1f052:	49 89 45 00          	mov    %rax,0x0(%r13)
   1f056:	49 81 fe 00 04 00 00 	cmp    $0x400,%r14
   1f05d:	77 96                	ja     1eff5 <mi_page_queue_remove+0x45>
   1f05f:	48 85 c0             	test   %rax,%rax
   1f062:	0f 84 58 01 00 00    	je     1f1c0 <mi_page_queue_remove+0x210>
   1f068:	49 8d 7e 07          	lea    0x7(%r14),%rdi
   1f06c:	4d 8d 84 24 18 01 00 	lea    0x118(%r12),%r8
   1f073:	00 
   1f074:	48 c1 ef 03          	shr    $0x3,%rdi
   1f078:	49 39 84 fc 18 01 00 	cmp    %rax,0x118(%r12,%rdi,8)
   1f07f:	00 
   1f080:	0f 84 6f ff ff ff    	je     1eff5 <mi_page_queue_remove+0x45>
   1f086:	48 83 ff 01          	cmp    $0x1,%rdi
   1f08a:	0f 86 20 01 00 00    	jbe    1f1b0 <mi_page_queue_remove+0x200>
   1f090:	48 83 ff 08          	cmp    $0x8,%rdi
   1f094:	0f 87 30 01 00 00    	ja     1f1ca <mi_page_queue_remove+0x21a>
   1f09a:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
   1f09e:	4d 89 cb             	mov    %r9,%r11
   1f0a1:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
   1f0a5:	49 8d 75 e0          	lea    -0x20(%r13),%rsi
   1f0a9:	4d 8d 94 24 20 05 00 	lea    0x520(%r12),%r10
   1f0b0:	00 
   1f0b1:	eb 1b                	jmp    1f0ce <mi_page_queue_remove+0x11e>
   1f0b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1f0b8:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
   1f0bc:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
   1f0c0:	49 39 cb             	cmp    %rcx,%r11
   1f0c3:	75 28                	jne    1f0ed <mi_page_queue_remove+0x13d>
   1f0c5:	49 39 f2             	cmp    %rsi,%r10
   1f0c8:	73 23                	jae    1f0ed <mi_page_queue_remove+0x13d>
   1f0ca:	48 83 ee 20          	sub    $0x20,%rsi
   1f0ce:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
   1f0d2:	48 83 c1 07          	add    $0x7,%rcx
   1f0d6:	48 89 ca             	mov    %rcx,%rdx
   1f0d9:	48 c1 ea 03          	shr    $0x3,%rdx
   1f0dd:	48 83 f9 47          	cmp    $0x47,%rcx
   1f0e1:	0f 87 99 00 00 00    	ja     1f180 <mi_page_queue_remove+0x1d0>
   1f0e7:	48 83 fa 01          	cmp    $0x1,%rdx
   1f0eb:	77 cb                	ja     1f0b8 <mi_page_queue_remove+0x108>
   1f0ed:	48 83 c2 01          	add    $0x1,%rdx
   1f0f1:	48 39 fa             	cmp    %rdi,%rdx
   1f0f4:	48 0f 47 d7          	cmova  %rdi,%rdx
   1f0f8:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
   1f0fc:	4c 89 ce             	mov    %r9,%rsi
   1f0ff:	41 ba 01 00 00 00    	mov    $0x1,%r10d
   1f105:	48 29 d6             	sub    %rdx,%rsi
   1f108:	49 39 c9             	cmp    %rcx,%r9
   1f10b:	49 0f 42 f2          	cmovb  %r10,%rsi
   1f10f:	48 39 d7             	cmp    %rdx,%rdi
   1f112:	74 5d                	je     1f171 <mi_page_queue_remove+0x1c1>
   1f114:	49 39 c9             	cmp    %rcx,%r9
   1f117:	72 58                	jb     1f171 <mi_page_queue_remove+0x1c1>
   1f119:	48 89 f7             	mov    %rsi,%rdi
   1f11c:	49 8d 8c d4 18 01 00 	lea    0x118(%r12,%rdx,8),%rcx
   1f123:	00 
   1f124:	66 48 0f 6e c0       	movq   %rax,%xmm0
   1f129:	48 d1 ef             	shr    $1,%rdi
   1f12c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
   1f130:	48 c1 e7 04          	shl    $0x4,%rdi
   1f134:	4c 8d 0c 0f          	lea    (%rdi,%rcx,1),%r9
   1f138:	83 e7 10             	and    $0x10,%edi
   1f13b:	74 13                	je     1f150 <mi_page_queue_remove+0x1a0>
   1f13d:	0f 11 01             	movups %xmm0,(%rcx)
   1f140:	48 83 c1 10          	add    $0x10,%rcx
   1f144:	49 39 c9             	cmp    %rcx,%r9
   1f147:	74 17                	je     1f160 <mi_page_queue_remove+0x1b0>
   1f149:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1f150:	0f 11 01             	movups %xmm0,(%rcx)
   1f153:	48 83 c1 20          	add    $0x20,%rcx
   1f157:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   1f15b:	49 39 c9             	cmp    %rcx,%r9
   1f15e:	75 f0                	jne    1f150 <mi_page_queue_remove+0x1a0>
   1f160:	40 f6 c6 01          	test   $0x1,%sil
   1f164:	0f 84 8b fe ff ff    	je     1eff5 <mi_page_queue_remove+0x45>
   1f16a:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
   1f16e:	48 01 f2             	add    %rsi,%rdx
   1f171:	49 89 04 d0          	mov    %rax,(%r8,%rdx,8)
   1f175:	e9 7b fe ff ff       	jmp    1eff5 <mi_page_queue_remove+0x45>
   1f17a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1f180:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
   1f187:	0f 87 60 ff ff ff    	ja     1f0ed <mi_page_queue_remove+0x13d>
   1f18d:	4c 8d 72 ff          	lea    -0x1(%rdx),%r14
   1f191:	4d 0f bd fe          	bsr    %r14,%r15
   1f195:	41 8d 4f fe          	lea    -0x2(%r15),%ecx
   1f199:	49 d3 ee             	shr    %cl,%r14
   1f19c:	41 83 e6 03          	and    $0x3,%r14d
   1f1a0:	4b 8d 4c be fd       	lea    -0x3(%r14,%r15,4),%rcx
   1f1a5:	e9 16 ff ff ff       	jmp    1f0c0 <mi_page_queue_remove+0x110>
   1f1aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1f1b0:	31 d2                	xor    %edx,%edx
   1f1b2:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
   1f1b6:	e9 3d ff ff ff       	jmp    1f0f8 <mi_page_queue_remove+0x148>
   1f1bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1f1c0:	e8 2b 95 ff ff       	call   186f0 <_mi_page_empty_get>
   1f1c5:	e9 9e fe ff ff       	jmp    1f068 <mi_page_queue_remove+0xb8>
   1f1ca:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
   1f1ce:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
   1f1d2:	48 0f bd f2          	bsr    %rdx,%rsi
   1f1d6:	8d 4e fe             	lea    -0x2(%rsi),%ecx
   1f1d9:	48 d3 ea             	shr    %cl,%rdx
   1f1dc:	83 e2 03             	and    $0x3,%edx
   1f1df:	4c 8d 5c b2 fd       	lea    -0x3(%rdx,%rsi,4),%r11
   1f1e4:	e9 bc fe ff ff       	jmp    1f0a5 <mi_page_queue_remove+0xf5>

Disassembly of section .fini:
