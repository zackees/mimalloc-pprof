
/tmp/mimalloc-614-campaign/v7-page.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <mi_page_free_list_extend>:
       0:	0f b7 47 14          	movzwl 0x14(%rdi),%eax
       4:	48 89 d1             	mov    %rdx,%rcx
       7:	8b 57 30             	mov    0x30(%rdi),%edx
       a:	49 89 c0             	mov    %rax,%r8
       d:	48 8d 44 08 ff       	lea    -0x1(%rax,%rcx,1),%rax
      12:	48 c1 e2 04          	shl    $0x4,%rdx
      16:	4c 0f af c6          	imul   %rsi,%r8
      1a:	48 01 fa             	add    %rdi,%rdx
      1d:	48 0f af c6          	imul   %rsi,%rax
      21:	49 01 d0             	add    %rdx,%r8
      24:	48 01 c2             	add    %rax,%rdx
      27:	4c 39 c2             	cmp    %r8,%rdx
      2a:	72 12                	jb     3e <mi_page_free_list_extend+0x3e>
      2c:	4c 89 c0             	mov    %r8,%rax
      2f:	90                   	nop
      30:	48 89 c1             	mov    %rax,%rcx
      33:	48 01 f0             	add    %rsi,%rax
      36:	48 89 01             	mov    %rax,(%rcx)
      39:	48 39 c2             	cmp    %rax,%rdx
      3c:	73 f2                	jae    30 <mi_page_free_list_extend+0x30>
      3e:	48 8b 47 08          	mov    0x8(%rdi),%rax
      42:	48 89 02             	mov    %rax,(%rdx)
      45:	4c 89 47 08          	mov    %r8,0x8(%rdi)
      49:	c3                   	ret
      4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000000050 <mi_page_extend_free>:
      50:	48 83 7e 08 00       	cmpq   $0x0,0x8(%rsi)
      55:	74 09                	je     60 <mi_page_extend_free+0x10>
      57:	b8 01 00 00 00       	mov    $0x1,%eax
      5c:	c3                   	ret
      5d:	0f 1f 00             	nopl   (%rax)
      60:	41 57                	push   %r15
      62:	41 56                	push   %r14
      64:	41 55                	push   %r13
      66:	41 54                	push   %r12
      68:	55                   	push   %rbp
      69:	53                   	push   %rbx
      6a:	48 89 f3             	mov    %rsi,%rbx
      6d:	48 83 ec 08          	sub    $0x8,%rsp
      71:	0f b7 56 14          	movzwl 0x14(%rsi),%edx
      75:	0f b7 46 36          	movzwl 0x36(%rsi),%eax
      79:	66 39 c2             	cmp    %ax,%dx
      7c:	0f 83 61 01 00 00    	jae    1e3 <mi_page_extend_free+0x193>
      82:	48 83 be a0 00 00 00 	cmpq   $0x0,0xa0(%rsi)
      89:	00 
      8a:	49 89 fd             	mov    %rdi,%r13
      8d:	74 13                	je     a2 <mi_page_extend_free+0x52>
      8f:	48 8b 37             	mov    (%rdi),%rsi
      92:	48 89 df             	mov    %rbx,%rdi
      95:	e8 00 00 00 00       	call   9a <mi_page_extend_free+0x4a>
			96: R_X86_64_PLT32	_mi_page_unpublish_retired-0x4
      9a:	0f b7 53 14          	movzwl 0x14(%rbx),%edx
      9e:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
      a2:	4c 8b 63 28          	mov    0x28(%rbx),%r12
      a6:	0f b7 c8             	movzwl %ax,%ecx
      a9:	b8 01 00 00 00       	mov    $0x1,%eax
      ae:	48 29 d1             	sub    %rdx,%rcx
      b1:	49 81 fc ff 0f 00 00 	cmp    $0xfff,%r12
      b8:	0f 86 e2 00 00 00    	jbe    1a0 <mi_page_extend_free+0x150>
      be:	48 39 c8             	cmp    %rcx,%rax
      c1:	44 0f b7 7b 34       	movzwl 0x34(%rbx),%r15d
      c6:	48 0f 46 c8          	cmovbe %rax,%rcx
      ca:	48 89 cd             	mov    %rcx,%rbp
      cd:	e8 00 00 00 00       	call   d2 <mi_page_extend_free+0x82>
			ce: R_X86_64_PLT32	_mi_os_page_size-0x4
      d2:	4c 0f af f8          	imul   %rax,%r15
      d6:	4d 85 ff             	test   %r15,%r15
      d9:	0f 84 35 01 00 00    	je     214 <mi_page_extend_free+0x1c4>
      df:	48 89 e8             	mov    %rbp,%rax
      e2:	49 0f af c4          	imul   %r12,%rax
      e6:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
      ec:	76 1a                	jbe    108 <mi_page_extend_free+0xb8>
      ee:	bd 00 00 01 00       	mov    $0x10000,%ebp
      f3:	4d 85 e4             	test   %r12,%r12
      f6:	74 10                	je     108 <mi_page_extend_free+0xb8>
      f8:	49 8d 84 24 ff ff 00 	lea    0xffff(%r12),%rax
      ff:	00 
     100:	31 d2                	xor    %edx,%edx
     102:	49 f7 f4             	div    %r12
     105:	48 89 c5             	mov    %rax,%rbp
     108:	44 0f b7 73 14       	movzwl 0x14(%rbx),%r14d
     10d:	e8 00 00 00 00       	call   112 <mi_page_extend_free+0xc2>
			10e: R_X86_64_PLT32	_mi_os_page_size-0x4
     112:	8b 73 30             	mov    0x30(%rbx),%esi
     115:	44 8b 43 68          	mov    0x68(%rbx),%r8d
     119:	48 89 c1             	mov    %rax,%rcx
     11c:	49 01 ee             	add    %rbp,%r14
     11f:	b8 00 40 00 00       	mov    $0x4000,%eax
     124:	4d 0f af f4          	imul   %r12,%r14
     128:	48 39 c1             	cmp    %rax,%rcx
     12b:	48 0f 42 c8          	cmovb  %rax,%rcx
     12f:	48 c1 e6 04          	shl    $0x4,%rsi
     133:	48 01 de             	add    %rbx,%rsi
     136:	48 89 f0             	mov    %rsi,%rax
     139:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
     13d:	48 89 f7             	mov    %rsi,%rdi
     140:	66 31 c0             	xor    %ax,%ax
     143:	41 83 f8 06          	cmp    $0x6,%r8d
     147:	48 0f 45 c3          	cmovne %rbx,%rax
     14b:	49 01 d6             	add    %rdx,%r14
     14e:	48 29 c7             	sub    %rax,%rdi
     151:	49 01 fe             	add    %rdi,%r14
     154:	48 85 ca             	test   %rcx,%rdx
     157:	74 57                	je     1b0 <mi_page_extend_free+0x160>
     159:	4c 89 f0             	mov    %r14,%rax
     15c:	31 d2                	xor    %edx,%edx
     15e:	48 f7 f1             	div    %rcx
     161:	49 29 d6             	sub    %rdx,%r14
     164:	4d 39 f7             	cmp    %r14,%r15
     167:	73 52                	jae    1bb <mi_page_extend_free+0x16b>
     169:	4c 89 f2             	mov    %r14,%rdx
     16c:	66 31 f6             	xor    %si,%si
     16f:	49 8b 7d 10          	mov    0x10(%r13),%rdi
     173:	4c 29 fa             	sub    %r15,%rdx
     176:	41 83 f8 06          	cmp    $0x6,%r8d
     17a:	48 0f 45 f3          	cmovne %rbx,%rsi
     17e:	31 c9                	xor    %ecx,%ecx
     180:	4c 01 fe             	add    %r15,%rsi
     183:	e8 00 00 00 00       	call   188 <mi_page_extend_free+0x138>
			184: R_X86_64_PLT32	_mi_os_commit-0x4
     188:	84 c0                	test   %al,%al
     18a:	75 74                	jne    200 <mi_page_extend_free+0x1b0>
     18c:	48 83 c4 08          	add    $0x8,%rsp
     190:	5b                   	pop    %rbx
     191:	5d                   	pop    %rbp
     192:	41 5c                	pop    %r12
     194:	41 5d                	pop    %r13
     196:	41 5e                	pop    %r14
     198:	41 5f                	pop    %r15
     19a:	c3                   	ret
     19b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     1a0:	b8 00 10 00 00       	mov    $0x1000,%eax
     1a5:	31 d2                	xor    %edx,%edx
     1a7:	49 f7 f4             	div    %r12
     1aa:	e9 0f ff ff ff       	jmp    be <mi_page_extend_free+0x6e>
     1af:	90                   	nop
     1b0:	48 f7 d9             	neg    %rcx
     1b3:	49 21 ce             	and    %rcx,%r14
     1b6:	4d 39 f7             	cmp    %r14,%r15
     1b9:	72 ae                	jb     169 <mi_page_extend_free+0x119>
     1bb:	0f b7 43 14          	movzwl 0x14(%rbx),%eax
     1bf:	48 89 df             	mov    %rbx,%rdi
     1c2:	48 01 e8             	add    %rbp,%rax
     1c5:	49 0f af c4          	imul   %r12,%rax
     1c9:	48 01 c6             	add    %rax,%rsi
     1cc:	e8 00 00 00 00       	call   1d1 <mi_page_extend_free+0x181>
			1cd: R_X86_64_PLT32	_mi_page_unpurge_unformed_upto-0x4
     1d1:	48 89 ea             	mov    %rbp,%rdx
     1d4:	4c 89 e6             	mov    %r12,%rsi
     1d7:	48 89 df             	mov    %rbx,%rdi
     1da:	e8 21 fe ff ff       	call   0 <mi_page_free_list_extend>
     1df:	66 01 6b 14          	add    %bp,0x14(%rbx)
     1e3:	48 83 c4 08          	add    $0x8,%rsp
     1e7:	b8 01 00 00 00       	mov    $0x1,%eax
     1ec:	5b                   	pop    %rbx
     1ed:	5d                   	pop    %rbp
     1ee:	41 5c                	pop    %r12
     1f0:	41 5d                	pop    %r13
     1f2:	41 5e                	pop    %r14
     1f4:	41 5f                	pop    %r15
     1f6:	c3                   	ret
     1f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     1fe:	00 00 
     200:	e8 00 00 00 00       	call   205 <mi_page_extend_free+0x1b5>
			201: R_X86_64_PLT32	_mi_os_page_size-0x4
     205:	31 d2                	xor    %edx,%edx
     207:	48 89 c1             	mov    %rax,%rcx
     20a:	4c 89 f0             	mov    %r14,%rax
     20d:	48 f7 f1             	div    %rcx
     210:	66 89 43 34          	mov    %ax,0x34(%rbx)
     214:	8b 73 30             	mov    0x30(%rbx),%esi
     217:	48 c1 e6 04          	shl    $0x4,%rsi
     21b:	48 01 de             	add    %rbx,%rsi
     21e:	eb 9b                	jmp    1bb <mi_page_extend_free+0x16b>

0000000000000220 <mi_page_free_collect_ex.constprop.0>:
     220:	55                   	push   %rbp
     221:	89 f5                	mov    %esi,%ebp
     223:	48 8d 77 20          	lea    0x20(%rdi),%rsi
     227:	53                   	push   %rbx
     228:	48 89 fb             	mov    %rdi,%rbx
     22b:	48 83 ec 08          	sub    $0x8,%rsp
     22f:	48 8b 07             	mov    (%rdi),%rax
     232:	48 8b 57 20          	mov    0x20(%rdi),%rdx
     236:	48 83 fa 01          	cmp    $0x1,%rdx
     23a:	77 74                	ja     2b0 <mi_page_free_collect_ex.constprop.0+0x90>
     23c:	48 8b 43 18          	mov    0x18(%rbx),%rax
     240:	48 8b 53 08          	mov    0x8(%rbx),%rdx
     244:	48 85 c0             	test   %rax,%rax
     247:	74 27                	je     270 <mi_page_free_collect_ex.constprop.0+0x50>
     249:	48 85 d2             	test   %rdx,%rdx
     24c:	0f 85 c6 00 00 00    	jne    318 <mi_page_free_collect_ex.constprop.0+0xf8>
     252:	48 89 43 08          	mov    %rax,0x8(%rbx)
     256:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
     25d:	00 
     25e:	c6 43 17 00          	movb   $0x0,0x17(%rbx)
     262:	48 83 c4 08          	add    $0x8,%rsp
     266:	5b                   	pop    %rbx
     267:	5d                   	pop    %rbp
     268:	c3                   	ret
     269:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     270:	48 85 d2             	test   %rdx,%rdx
     273:	75 ed                	jne    262 <mi_page_free_collect_ex.constprop.0+0x42>
     275:	48 83 7b 70 00       	cmpq   $0x0,0x70(%rbx)
     27a:	75 1b                	jne    297 <mi_page_free_collect_ex.constprop.0+0x77>
     27c:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
     281:	75 14                	jne    297 <mi_page_free_collect_ex.constprop.0+0x77>
     283:	48 83 bb 80 00 00 00 	cmpq   $0x0,0x80(%rbx)
     28a:	00 
     28b:	75 0a                	jne    297 <mi_page_free_collect_ex.constprop.0+0x77>
     28d:	48 83 bb 88 00 00 00 	cmpq   $0x0,0x88(%rbx)
     294:	00 
     295:	74 cb                	je     262 <mi_page_free_collect_ex.constprop.0+0x42>
     297:	e8 00 00 00 00       	call   29c <mi_page_free_collect_ex.constprop.0+0x7c>
			298: R_X86_64_PLT32	_mi_page_purge_holes_in_progress-0x4
     29c:	84 c0                	test   %al,%al
     29e:	75 c2                	jne    262 <mi_page_free_collect_ex.constprop.0+0x42>
     2a0:	48 83 c4 08          	add    $0x8,%rsp
     2a4:	48 89 df             	mov    %rbx,%rdi
     2a7:	5b                   	pop    %rbx
     2a8:	5d                   	pop    %rbp
     2a9:	e9 00 00 00 00       	jmp    2ae <mi_page_free_collect_ex.constprop.0+0x8e>
			2aa: R_X86_64_PLT32	_mi_page_unpurge_run-0x4
     2ae:	66 90                	xchg   %ax,%ax
     2b0:	48 89 d1             	mov    %rdx,%rcx
     2b3:	48 89 d0             	mov    %rdx,%rax
     2b6:	83 e1 01             	and    $0x1,%ecx
     2b9:	f0 48 0f b1 0e       	lock cmpxchg %rcx,(%rsi)
     2be:	0f 94 c1             	sete   %cl
     2c1:	0f b6 c9             	movzbl %cl,%ecx
     2c4:	0f 85 b5 00 00 00    	jne    37f <mi_page_free_collect_ex.constprop.0+0x15f>
     2ca:	48 89 d0             	mov    %rdx,%rax
     2cd:	0f b7 73 14          	movzwl 0x14(%rbx),%esi
     2d1:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
     2d5:	48 8b 10             	mov    (%rax),%rdx
     2d8:	48 85 f6             	test   %rsi,%rsi
     2db:	74 5e                	je     33b <mi_page_free_collect_ex.constprop.0+0x11b>
     2dd:	48 85 d2             	test   %rdx,%rdx
     2e0:	75 0b                	jne    2ed <mi_page_free_collect_ex.constprop.0+0xcd>
     2e2:	eb 57                	jmp    33b <mi_page_free_collect_ex.constprop.0+0x11b>
     2e4:	0f 1f 40 00          	nopl   0x0(%rax)
     2e8:	48 85 d2             	test   %rdx,%rdx
     2eb:	74 51                	je     33e <mi_page_free_collect_ex.constprop.0+0x11e>
     2ed:	48 83 c1 01          	add    $0x1,%rcx
     2f1:	48 89 d7             	mov    %rdx,%rdi
     2f4:	48 8b 12             	mov    (%rdx),%rdx
     2f7:	48 39 ce             	cmp    %rcx,%rsi
     2fa:	73 ec                	jae    2e8 <mi_page_free_collect_ex.constprop.0+0xc8>
     2fc:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 303 <mi_page_free_collect_ex.constprop.0+0xe3>
			2ff: R_X86_64_PC32	.LC0-0x4
     303:	bf 0e 00 00 00       	mov    $0xe,%edi
     308:	31 c0                	xor    %eax,%eax
     30a:	e8 00 00 00 00       	call   30f <mi_page_free_collect_ex.constprop.0+0xef>
			30b: R_X86_64_PLT32	_mi_error_message-0x4
     30f:	e9 28 ff ff ff       	jmp    23c <mi_page_free_collect_ex.constprop.0+0x1c>
     314:	0f 1f 40 00          	nopl   0x0(%rax)
     318:	40 84 ed             	test   %bpl,%bpl
     31b:	0f 84 41 ff ff ff    	je     262 <mi_page_free_collect_ex.constprop.0+0x42>
     321:	48 89 c1             	mov    %rax,%rcx
     324:	0f 1f 40 00          	nopl   0x0(%rax)
     328:	48 89 ce             	mov    %rcx,%rsi
     32b:	48 8b 09             	mov    (%rcx),%rcx
     32e:	48 85 c9             	test   %rcx,%rcx
     331:	75 f5                	jne    328 <mi_page_free_collect_ex.constprop.0+0x108>
     333:	48 89 16             	mov    %rdx,(%rsi)
     336:	e9 17 ff ff ff       	jmp    252 <mi_page_free_collect_ex.constprop.0+0x32>
     33b:	48 89 c7             	mov    %rax,%rdi
     33e:	48 39 ce             	cmp    %rcx,%rsi
     341:	72 b9                	jb     2fc <mi_page_free_collect_ex.constprop.0+0xdc>
     343:	8b 73 10             	mov    0x10(%rbx),%esi
     346:	48 89 f2             	mov    %rsi,%rdx
     349:	48 39 ce             	cmp    %rcx,%rsi
     34c:	72 19                	jb     367 <mi_page_free_collect_ex.constprop.0+0x147>
     34e:	48 8b 73 18          	mov    0x18(%rbx),%rsi
     352:	29 ca                	sub    %ecx,%edx
     354:	48 89 37             	mov    %rsi,(%rdi)
     357:	89 53 10             	mov    %edx,0x10(%rbx)
     35a:	48 8b 53 08          	mov    0x8(%rbx),%rdx
     35e:	48 89 43 18          	mov    %rax,0x18(%rbx)
     362:	e9 e2 fe ff ff       	jmp    249 <mi_page_free_collect_ex.constprop.0+0x29>
     367:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 36e <mi_page_free_collect_ex.constprop.0+0x14e>
			36a: R_X86_64_PC32	.LC1-0x4
     36e:	bf 0e 00 00 00       	mov    $0xe,%edi
     373:	31 c0                	xor    %eax,%eax
     375:	e8 00 00 00 00       	call   37a <mi_page_free_collect_ex.constprop.0+0x15a>
			376: R_X86_64_PLT32	_mi_error_message-0x4
     37a:	e9 bd fe ff ff       	jmp    23c <mi_page_free_collect_ex.constprop.0+0x1c>
     37f:	48 89 c2             	mov    %rax,%rdx
     382:	e9 af fe ff ff       	jmp    236 <mi_page_free_collect_ex.constprop.0+0x16>
     387:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     38e:	00 00 

0000000000000390 <mi_page_queue_push>:
     390:	4c 8b 46 18          	mov    0x18(%rsi),%r8
     394:	49 89 f9             	mov    %rdi,%r9
     397:	48 8b 02             	mov    (%rdx),%rax
     39a:	48 89 d7             	mov    %rdx,%rdi
     39d:	49 81 f8 10 00 08 00 	cmp    $0x80010,%r8
     3a4:	41 0f 94 c2          	sete   %r10b
     3a8:	0f 85 92 01 00 00    	jne    540 <mi_page_queue_push+0x1b0>
     3ae:	48 89 c1             	mov    %rax,%rcx
     3b1:	48 89 c2             	mov    %rax,%rdx
     3b4:	48 83 c9 01          	or     $0x1,%rcx
     3b8:	f0 48 0f b1 0f       	lock cmpxchg %rcx,(%rdi)
     3bd:	75 ef                	jne    3ae <mi_page_queue_push+0x1e>
     3bf:	83 e2 01             	and    $0x1,%edx
     3c2:	41 38 d2             	cmp    %dl,%r10b
     3c5:	74 34                	je     3fb <mi_page_queue_push+0x6b>
     3c7:	48 8b 57 38          	mov    0x38(%rdi),%rdx
     3cb:	48 85 d2             	test   %rdx,%rdx
     3ce:	74 2b                	je     3fb <mi_page_queue_push+0x6b>
     3d0:	48 8b 8a d0 00 00 00 	mov    0xd0(%rdx),%rcx
     3d7:	0f b7 47 36          	movzwl 0x36(%rdi),%eax
     3db:	48 0f af 47 28       	imul   0x28(%rdi),%rax
     3e0:	49 89 ca             	mov    %rcx,%r10
     3e3:	49 29 c2             	sub    %rax,%r10
     3e6:	48 01 c8             	add    %rcx,%rax
     3e9:	49 81 f8 10 00 08 00 	cmp    $0x80010,%r8
     3f0:	49 0f 45 c2          	cmovne %r10,%rax
     3f4:	48 89 82 d0 00 00 00 	mov    %rax,0xd0(%rdx)
     3fb:	48 8b 06             	mov    (%rsi),%rax
     3fe:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
     405:	00 
     406:	48 89 47 48          	mov    %rax,0x48(%rdi)
     40a:	48 85 c0             	test   %rax,%rax
     40d:	0f 84 5d 01 00 00    	je     570 <mi_page_queue_push+0x1e0>
     413:	48 89 78 50          	mov    %rdi,0x50(%rax)
     417:	4c 8b 46 18          	mov    0x18(%rsi),%r8
     41b:	48 83 46 10 01       	addq   $0x1,0x10(%rsi)
     420:	48 89 3e             	mov    %rdi,(%rsi)
     423:	49 81 f8 00 04 00 00 	cmp    $0x400,%r8
     42a:	0f 87 80 01 00 00    	ja     5b0 <mi_page_queue_push+0x220>
     430:	49 83 c0 07          	add    $0x7,%r8
     434:	4d 8d 91 18 01 00 00 	lea    0x118(%r9),%r10
     43b:	49 c1 e8 03          	shr    $0x3,%r8
     43f:	4b 3b bc c1 18 01 00 	cmp    0x118(%r9,%r8,8),%rdi
     446:	00 
     447:	0f 84 63 01 00 00    	je     5b0 <mi_page_queue_push+0x220>
     44d:	41 54                	push   %r12
     44f:	55                   	push   %rbp
     450:	53                   	push   %rbx
     451:	49 83 f8 01          	cmp    $0x1,%r8
     455:	0f 86 05 01 00 00    	jbe    560 <mi_page_queue_push+0x1d0>
     45b:	49 83 f8 08          	cmp    $0x8,%r8
     45f:	0f 87 54 01 00 00    	ja     5b9 <mi_page_queue_push+0x229>
     465:	4d 8d 58 01          	lea    0x1(%r8),%r11
     469:	4c 89 dd             	mov    %r11,%rbp
     46c:	48 83 e5 fe          	and    $0xfffffffffffffffe,%rbp
     470:	48 83 ee 20          	sub    $0x20,%rsi
     474:	49 8d 99 20 05 00 00 	lea    0x520(%r9),%rbx
     47b:	eb 19                	jmp    496 <mi_page_queue_push+0x106>
     47d:	0f 1f 00             	nopl   (%rax)
     480:	48 8d 50 01          	lea    0x1(%rax),%rdx
     484:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
     488:	48 39 d5             	cmp    %rdx,%rbp
     48b:	75 28                	jne    4b5 <mi_page_queue_push+0x125>
     48d:	48 39 f3             	cmp    %rsi,%rbx
     490:	73 23                	jae    4b5 <mi_page_queue_push+0x125>
     492:	48 83 ee 20          	sub    $0x20,%rsi
     496:	48 8b 46 18          	mov    0x18(%rsi),%rax
     49a:	48 8d 50 07          	lea    0x7(%rax),%rdx
     49e:	48 89 d0             	mov    %rdx,%rax
     4a1:	48 c1 e8 03          	shr    $0x3,%rax
     4a5:	48 83 fa 47          	cmp    $0x47,%rdx
     4a9:	0f 87 d1 00 00 00    	ja     580 <mi_page_queue_push+0x1f0>
     4af:	48 83 f8 01          	cmp    $0x1,%rax
     4b3:	77 cb                	ja     480 <mi_page_queue_push+0xf0>
     4b5:	48 83 c0 01          	add    $0x1,%rax
     4b9:	4c 39 c0             	cmp    %r8,%rax
     4bc:	49 0f 47 c0          	cmova  %r8,%rax
     4c0:	48 8d 50 01          	lea    0x1(%rax),%rdx
     4c4:	4c 89 d9             	mov    %r11,%rcx
     4c7:	be 01 00 00 00       	mov    $0x1,%esi
     4cc:	48 29 c1             	sub    %rax,%rcx
     4cf:	49 39 d3             	cmp    %rdx,%r11
     4d2:	48 0f 42 ce          	cmovb  %rsi,%rcx
     4d6:	49 39 c0             	cmp    %rax,%r8
     4d9:	74 51                	je     52c <mi_page_queue_push+0x19c>
     4db:	49 39 d3             	cmp    %rdx,%r11
     4de:	72 4c                	jb     52c <mi_page_queue_push+0x19c>
     4e0:	48 89 ce             	mov    %rcx,%rsi
     4e3:	49 8d 94 c1 18 01 00 	lea    0x118(%r9,%rax,8),%rdx
     4ea:	00 
     4eb:	66 48 0f 6e c7       	movq   %rdi,%xmm0
     4f0:	48 d1 ee             	shr    $1,%rsi
     4f3:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
     4f7:	48 c1 e6 04          	shl    $0x4,%rsi
     4fb:	4c 8d 04 16          	lea    (%rsi,%rdx,1),%r8
     4ff:	83 e6 10             	and    $0x10,%esi
     502:	74 0c                	je     510 <mi_page_queue_push+0x180>
     504:	0f 11 02             	movups %xmm0,(%rdx)
     507:	48 83 c2 10          	add    $0x10,%rdx
     50b:	49 39 d0             	cmp    %rdx,%r8
     50e:	74 10                	je     520 <mi_page_queue_push+0x190>
     510:	0f 11 02             	movups %xmm0,(%rdx)
     513:	48 83 c2 20          	add    $0x20,%rdx
     517:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
     51b:	49 39 d0             	cmp    %rdx,%r8
     51e:	75 f0                	jne    510 <mi_page_queue_push+0x180>
     520:	f6 c1 01             	test   $0x1,%cl
     523:	74 0b                	je     530 <mi_page_queue_push+0x1a0>
     525:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     529:	48 01 c8             	add    %rcx,%rax
     52c:	49 89 3c c2          	mov    %rdi,(%r10,%rax,8)
     530:	5b                   	pop    %rbx
     531:	49 83 81 b8 00 00 00 	addq   $0x1,0xb8(%r9)
     538:	01 
     539:	5d                   	pop    %rbp
     53a:	41 5c                	pop    %r12
     53c:	c3                   	ret
     53d:	0f 1f 00             	nopl   (%rax)
     540:	48 89 c1             	mov    %rax,%rcx
     543:	48 89 c2             	mov    %rax,%rdx
     546:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     54a:	f0 48 0f b1 0f       	lock cmpxchg %rcx,(%rdi)
     54f:	0f 84 6a fe ff ff    	je     3bf <mi_page_queue_push+0x2f>
     555:	eb e9                	jmp    540 <mi_page_queue_push+0x1b0>
     557:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     55e:	00 00 
     560:	31 c0                	xor    %eax,%eax
     562:	4d 8d 58 01          	lea    0x1(%r8),%r11
     566:	e9 55 ff ff ff       	jmp    4c0 <mi_page_queue_push+0x130>
     56b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     570:	48 89 7e 08          	mov    %rdi,0x8(%rsi)
     574:	e9 9e fe ff ff       	jmp    417 <mi_page_queue_push+0x87>
     579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     580:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
     586:	0f 87 29 ff ff ff    	ja     4b5 <mi_page_queue_push+0x125>
     58c:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
     590:	4c 0f bd e2          	bsr    %rdx,%r12
     594:	41 8d 4c 24 fe       	lea    -0x2(%r12),%ecx
     599:	48 d3 ea             	shr    %cl,%rdx
     59c:	83 e2 03             	and    $0x3,%edx
     59f:	4a 8d 54 a2 fd       	lea    -0x3(%rdx,%r12,4),%rdx
     5a4:	e9 df fe ff ff       	jmp    488 <mi_page_queue_push+0xf8>
     5a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     5b0:	49 83 81 b8 00 00 00 	addq   $0x1,0xb8(%r9)
     5b7:	01 
     5b8:	c3                   	ret
     5b9:	49 8d 40 ff          	lea    -0x1(%r8),%rax
     5bd:	4d 8d 58 01          	lea    0x1(%r8),%r11
     5c1:	48 0f bd d0          	bsr    %rax,%rdx
     5c5:	8d 4a fe             	lea    -0x2(%rdx),%ecx
     5c8:	48 d3 e8             	shr    %cl,%rax
     5cb:	83 e0 03             	and    $0x3,%eax
     5ce:	48 8d 6c 90 fd       	lea    -0x3(%rax,%rdx,4),%rbp
     5d3:	e9 98 fe ff ff       	jmp    470 <mi_page_queue_push+0xe0>
     5d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     5df:	00 

00000000000005e0 <mi_page_queue_remove>:
     5e0:	41 56                	push   %r14
     5e2:	41 55                	push   %r13
     5e4:	41 54                	push   %r12
     5e6:	49 89 fc             	mov    %rdi,%r12
     5e9:	55                   	push   %rbp
     5ea:	53                   	push   %rbx
     5eb:	48 8b 56 50          	mov    0x50(%rsi),%rdx
     5ef:	48 89 f3             	mov    %rsi,%rbx
     5f2:	48 8b 6e 38          	mov    0x38(%rsi),%rbp
     5f6:	48 85 d2             	test   %rdx,%rdx
     5f9:	74 08                	je     603 <mi_page_queue_remove+0x23>
     5fb:	48 8b 46 48          	mov    0x48(%rsi),%rax
     5ff:	48 89 42 48          	mov    %rax,0x48(%rdx)
     603:	48 8b 43 48          	mov    0x48(%rbx),%rax
     607:	48 85 c0             	test   %rax,%rax
     60a:	74 04                	je     610 <mi_page_queue_remove+0x30>
     60c:	48 89 50 50          	mov    %rdx,0x50(%rax)
     610:	49 39 5c 24 08       	cmp    %rbx,0x8(%r12)
     615:	74 49                	je     660 <mi_page_queue_remove+0x80>
     617:	49 39 1c 24          	cmp    %rbx,(%r12)
     61b:	74 52                	je     66f <mi_page_queue_remove+0x8f>
     61d:	48 83 ad b8 00 00 00 	subq   $0x1,0xb8(%rbp)
     624:	01 
     625:	66 0f ef c0          	pxor   %xmm0,%xmm0
     629:	49 83 6c 24 10 01    	subq   $0x1,0x10(%r12)
     62f:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
     633:	f0 48 0f ba 33 00    	lock btrq $0x0,(%rbx)
     639:	73 19                	jae    654 <mi_page_queue_remove+0x74>
     63b:	48 8b 43 38          	mov    0x38(%rbx),%rax
     63f:	48 85 c0             	test   %rax,%rax
     642:	74 10                	je     654 <mi_page_queue_remove+0x74>
     644:	0f b7 53 36          	movzwl 0x36(%rbx),%edx
     648:	48 0f af 53 28       	imul   0x28(%rbx),%rdx
     64d:	48 29 90 d0 00 00 00 	sub    %rdx,0xd0(%rax)
     654:	5b                   	pop    %rbx
     655:	5d                   	pop    %rbp
     656:	41 5c                	pop    %r12
     658:	41 5d                	pop    %r13
     65a:	41 5e                	pop    %r14
     65c:	c3                   	ret
     65d:	0f 1f 00             	nopl   (%rax)
     660:	48 8b 53 50          	mov    0x50(%rbx),%rdx
     664:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
     669:	49 39 1c 24          	cmp    %rbx,(%r12)
     66d:	75 ae                	jne    61d <mi_page_queue_remove+0x3d>
     66f:	4d 8b 6c 24 18       	mov    0x18(%r12),%r13
     674:	49 89 04 24          	mov    %rax,(%r12)
     678:	49 81 fd 00 04 00 00 	cmp    $0x400,%r13
     67f:	77 9c                	ja     61d <mi_page_queue_remove+0x3d>
     681:	48 85 c0             	test   %rax,%rax
     684:	0f 84 56 01 00 00    	je     7e0 <mi_page_queue_remove+0x200>
     68a:	49 8d 7d 07          	lea    0x7(%r13),%rdi
     68e:	4c 8d 85 18 01 00 00 	lea    0x118(%rbp),%r8
     695:	48 c1 ef 03          	shr    $0x3,%rdi
     699:	48 39 84 fd 18 01 00 	cmp    %rax,0x118(%rbp,%rdi,8)
     6a0:	00 
     6a1:	0f 84 76 ff ff ff    	je     61d <mi_page_queue_remove+0x3d>
     6a7:	48 83 ff 01          	cmp    $0x1,%rdi
     6ab:	0f 86 1f 01 00 00    	jbe    7d0 <mi_page_queue_remove+0x1f0>
     6b1:	48 83 ff 08          	cmp    $0x8,%rdi
     6b5:	0f 87 2f 01 00 00    	ja     7ea <mi_page_queue_remove+0x20a>
     6bb:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     6bf:	4d 89 cb             	mov    %r9,%r11
     6c2:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
     6c6:	49 8d 74 24 e0       	lea    -0x20(%r12),%rsi
     6cb:	4c 8d 95 20 05 00 00 	lea    0x520(%rbp),%r10
     6d2:	eb 1a                	jmp    6ee <mi_page_queue_remove+0x10e>
     6d4:	0f 1f 40 00          	nopl   0x0(%rax)
     6d8:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
     6dc:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     6e0:	49 39 cb             	cmp    %rcx,%r11
     6e3:	75 28                	jne    70d <mi_page_queue_remove+0x12d>
     6e5:	49 39 f2             	cmp    %rsi,%r10
     6e8:	73 23                	jae    70d <mi_page_queue_remove+0x12d>
     6ea:	48 83 ee 20          	sub    $0x20,%rsi
     6ee:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
     6f2:	48 83 c1 07          	add    $0x7,%rcx
     6f6:	48 89 ca             	mov    %rcx,%rdx
     6f9:	48 c1 ea 03          	shr    $0x3,%rdx
     6fd:	48 83 f9 47          	cmp    $0x47,%rcx
     701:	0f 87 99 00 00 00    	ja     7a0 <mi_page_queue_remove+0x1c0>
     707:	48 83 fa 01          	cmp    $0x1,%rdx
     70b:	77 cb                	ja     6d8 <mi_page_queue_remove+0xf8>
     70d:	48 83 c2 01          	add    $0x1,%rdx
     711:	48 39 fa             	cmp    %rdi,%rdx
     714:	48 0f 47 d7          	cmova  %rdi,%rdx
     718:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
     71c:	4c 89 ce             	mov    %r9,%rsi
     71f:	41 ba 01 00 00 00    	mov    $0x1,%r10d
     725:	48 29 d6             	sub    %rdx,%rsi
     728:	49 39 c9             	cmp    %rcx,%r9
     72b:	49 0f 42 f2          	cmovb  %r10,%rsi
     72f:	48 39 d7             	cmp    %rdx,%rdi
     732:	74 5d                	je     791 <mi_page_queue_remove+0x1b1>
     734:	49 39 c9             	cmp    %rcx,%r9
     737:	72 58                	jb     791 <mi_page_queue_remove+0x1b1>
     739:	48 89 f7             	mov    %rsi,%rdi
     73c:	48 8d 8c d5 18 01 00 	lea    0x118(%rbp,%rdx,8),%rcx
     743:	00 
     744:	66 48 0f 6e c0       	movq   %rax,%xmm0
     749:	48 d1 ef             	shr    $1,%rdi
     74c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
     750:	48 c1 e7 04          	shl    $0x4,%rdi
     754:	4c 8d 0c 0f          	lea    (%rdi,%rcx,1),%r9
     758:	83 e7 10             	and    $0x10,%edi
     75b:	74 13                	je     770 <mi_page_queue_remove+0x190>
     75d:	0f 11 01             	movups %xmm0,(%rcx)
     760:	48 83 c1 10          	add    $0x10,%rcx
     764:	49 39 c9             	cmp    %rcx,%r9
     767:	74 17                	je     780 <mi_page_queue_remove+0x1a0>
     769:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     770:	0f 11 01             	movups %xmm0,(%rcx)
     773:	48 83 c1 20          	add    $0x20,%rcx
     777:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
     77b:	49 39 c9             	cmp    %rcx,%r9
     77e:	75 f0                	jne    770 <mi_page_queue_remove+0x190>
     780:	40 f6 c6 01          	test   $0x1,%sil
     784:	0f 84 93 fe ff ff    	je     61d <mi_page_queue_remove+0x3d>
     78a:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
     78e:	48 01 f2             	add    %rsi,%rdx
     791:	49 89 04 d0          	mov    %rax,(%r8,%rdx,8)
     795:	e9 83 fe ff ff       	jmp    61d <mi_page_queue_remove+0x3d>
     79a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     7a0:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
     7a7:	0f 87 60 ff ff ff    	ja     70d <mi_page_queue_remove+0x12d>
     7ad:	4c 8d 6a ff          	lea    -0x1(%rdx),%r13
     7b1:	4d 0f bd f5          	bsr    %r13,%r14
     7b5:	41 8d 4e fe          	lea    -0x2(%r14),%ecx
     7b9:	49 d3 ed             	shr    %cl,%r13
     7bc:	41 83 e5 03          	and    $0x3,%r13d
     7c0:	4b 8d 4c b5 fd       	lea    -0x3(%r13,%r14,4),%rcx
     7c5:	e9 16 ff ff ff       	jmp    6e0 <mi_page_queue_remove+0x100>
     7ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     7d0:	31 d2                	xor    %edx,%edx
     7d2:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     7d6:	e9 3d ff ff ff       	jmp    718 <mi_page_queue_remove+0x138>
     7db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     7e0:	e8 00 00 00 00       	call   7e5 <mi_page_queue_remove+0x205>
			7e1: R_X86_64_PLT32	_mi_page_empty_get-0x4
     7e5:	e9 a0 fe ff ff       	jmp    68a <mi_page_queue_remove+0xaa>
     7ea:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
     7ee:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     7f2:	48 0f bd f2          	bsr    %rdx,%rsi
     7f6:	8d 4e fe             	lea    -0x2(%rsi),%ecx
     7f9:	48 d3 ea             	shr    %cl,%rdx
     7fc:	83 e2 03             	and    $0x3,%edx
     7ff:	4c 8d 5c b2 fd       	lea    -0x3(%rdx,%rsi,4),%r11
     804:	e9 bd fe ff ff       	jmp    6c6 <mi_page_queue_remove+0xe6>
     809:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000000810 <mi_page_queue_enqueue_from_ex.constprop.0>:
     810:	41 57                	push   %r15
     812:	41 56                	push   %r14
     814:	41 55                	push   %r13
     816:	41 54                	push   %r12
     818:	49 89 f4             	mov    %rsi,%r12
     81b:	55                   	push   %rbp
     81c:	48 89 fd             	mov    %rdi,%rbp
     81f:	53                   	push   %rbx
     820:	48 89 d3             	mov    %rdx,%rbx
     823:	48 83 ec 08          	sub    $0x8,%rsp
     827:	4c 8b 6a 38          	mov    0x38(%rdx),%r13
     82b:	48 8b 52 50          	mov    0x50(%rdx),%rdx
     82f:	48 85 d2             	test   %rdx,%rdx
     832:	74 08                	je     83c <mi_page_queue_enqueue_from_ex.constprop.0+0x2c>
     834:	48 8b 43 48          	mov    0x48(%rbx),%rax
     838:	48 89 42 48          	mov    %rax,0x48(%rdx)
     83c:	48 8b 43 48          	mov    0x48(%rbx),%rax
     840:	48 85 c0             	test   %rax,%rax
     843:	74 04                	je     849 <mi_page_queue_enqueue_from_ex.constprop.0+0x39>
     845:	48 89 50 50          	mov    %rdx,0x50(%rax)
     849:	49 3b 5c 24 08       	cmp    0x8(%r12),%rbx
     84e:	0f 84 e4 01 00 00    	je     a38 <mi_page_queue_enqueue_from_ex.constprop.0+0x228>
     854:	49 3b 1c 24          	cmp    (%r12),%rbx
     858:	0f 84 ed 01 00 00    	je     a4b <mi_page_queue_enqueue_from_ex.constprop.0+0x23b>
     85e:	48 8b 75 18          	mov    0x18(%rbp),%rsi
     862:	48 8b 45 08          	mov    0x8(%rbp),%rax
     866:	49 83 6c 24 10 01    	subq   $0x1,0x10(%r12)
     86c:	48 83 45 10 01       	addq   $0x1,0x10(%rbp)
     871:	48 81 fe 10 00 08 00 	cmp    $0x80010,%rsi
     878:	48 89 43 50          	mov    %rax,0x50(%rbx)
     87c:	40 0f 94 c7          	sete   %dil
     880:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
     887:	00 
     888:	48 85 c0             	test   %rax,%rax
     88b:	74 7b                	je     908 <mi_page_queue_enqueue_from_ex.constprop.0+0xf8>
     88d:	48 89 58 48          	mov    %rbx,0x48(%rax)
     891:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
     895:	48 81 fe 10 00 08 00 	cmp    $0x80010,%rsi
     89c:	0f 85 76 01 00 00    	jne    a18 <mi_page_queue_enqueue_from_ex.constprop.0+0x208>
     8a2:	48 8b 03             	mov    (%rbx),%rax
     8a5:	48 89 c1             	mov    %rax,%rcx
     8a8:	48 89 c2             	mov    %rax,%rdx
     8ab:	48 83 c9 01          	or     $0x1,%rcx
     8af:	f0 48 0f b1 0b       	lock cmpxchg %rcx,(%rbx)
     8b4:	75 ef                	jne    8a5 <mi_page_queue_enqueue_from_ex.constprop.0+0x95>
     8b6:	83 e2 01             	and    $0x1,%edx
     8b9:	40 38 d7             	cmp    %dl,%dil
     8bc:	74 34                	je     8f2 <mi_page_queue_enqueue_from_ex.constprop.0+0xe2>
     8be:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
     8c2:	48 85 c9             	test   %rcx,%rcx
     8c5:	74 2b                	je     8f2 <mi_page_queue_enqueue_from_ex.constprop.0+0xe2>
     8c7:	48 8b 81 d0 00 00 00 	mov    0xd0(%rcx),%rax
     8ce:	0f b7 53 36          	movzwl 0x36(%rbx),%edx
     8d2:	48 0f af 53 28       	imul   0x28(%rbx),%rdx
     8d7:	48 89 c7             	mov    %rax,%rdi
     8da:	48 29 d7             	sub    %rdx,%rdi
     8dd:	48 01 d0             	add    %rdx,%rax
     8e0:	48 81 fe 10 00 08 00 	cmp    $0x80010,%rsi
     8e7:	48 0f 45 c7          	cmovne %rdi,%rax
     8eb:	48 89 81 d0 00 00 00 	mov    %rax,0xd0(%rcx)
     8f2:	48 83 c4 08          	add    $0x8,%rsp
     8f6:	5b                   	pop    %rbx
     8f7:	5d                   	pop    %rbp
     8f8:	41 5c                	pop    %r12
     8fa:	41 5d                	pop    %r13
     8fc:	41 5e                	pop    %r14
     8fe:	41 5f                	pop    %r15
     900:	c3                   	ret
     901:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     908:	66 48 0f 6e c3       	movq   %rbx,%xmm0
     90d:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
     911:	0f 11 45 00          	movups %xmm0,0x0(%rbp)
     915:	48 81 fe 00 04 00 00 	cmp    $0x400,%rsi
     91c:	0f 87 73 ff ff ff    	ja     895 <mi_page_queue_enqueue_from_ex.constprop.0+0x85>
     922:	4c 8d 46 07          	lea    0x7(%rsi),%r8
     926:	4d 8d 8d 18 01 00 00 	lea    0x118(%r13),%r9
     92d:	49 c1 e8 03          	shr    $0x3,%r8
     931:	4b 3b 9c c5 18 01 00 	cmp    0x118(%r13,%r8,8),%rbx
     938:	00 
     939:	0f 84 d9 00 00 00    	je     a18 <mi_page_queue_enqueue_from_ex.constprop.0+0x208>
     93f:	49 83 f8 01          	cmp    $0x1,%r8
     943:	0f 86 bf 02 00 00    	jbe    c08 <mi_page_queue_enqueue_from_ex.constprop.0+0x3f8>
     949:	49 83 f8 08          	cmp    $0x8,%r8
     94d:	0f 87 cf 02 00 00    	ja     c22 <mi_page_queue_enqueue_from_ex.constprop.0+0x412>
     953:	4d 8d 50 01          	lea    0x1(%r8),%r10
     957:	4d 89 d3             	mov    %r10,%r11
     95a:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
     95e:	48 83 ed 20          	sub    $0x20,%rbp
     962:	4d 8d a5 20 05 00 00 	lea    0x520(%r13),%r12
     969:	eb 1b                	jmp    986 <mi_page_queue_enqueue_from_ex.constprop.0+0x176>
     96b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     970:	48 8d 50 01          	lea    0x1(%rax),%rdx
     974:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
     978:	49 39 d3             	cmp    %rdx,%r11
     97b:	75 28                	jne    9a5 <mi_page_queue_enqueue_from_ex.constprop.0+0x195>
     97d:	49 39 ec             	cmp    %rbp,%r12
     980:	73 23                	jae    9a5 <mi_page_queue_enqueue_from_ex.constprop.0+0x195>
     982:	48 83 ed 20          	sub    $0x20,%rbp
     986:	48 8b 45 18          	mov    0x18(%rbp),%rax
     98a:	48 8d 50 07          	lea    0x7(%rax),%rdx
     98e:	48 89 d0             	mov    %rdx,%rax
     991:	48 c1 e8 03          	shr    $0x3,%rax
     995:	48 83 fa 47          	cmp    $0x47,%rdx
     999:	0f 87 11 02 00 00    	ja     bb0 <mi_page_queue_enqueue_from_ex.constprop.0+0x3a0>
     99f:	48 83 f8 01          	cmp    $0x1,%rax
     9a3:	77 cb                	ja     970 <mi_page_queue_enqueue_from_ex.constprop.0+0x160>
     9a5:	48 83 c0 01          	add    $0x1,%rax
     9a9:	4c 39 c0             	cmp    %r8,%rax
     9ac:	49 0f 47 c0          	cmova  %r8,%rax
     9b0:	48 8d 50 01          	lea    0x1(%rax),%rdx
     9b4:	4c 89 d1             	mov    %r10,%rcx
     9b7:	41 bb 01 00 00 00    	mov    $0x1,%r11d
     9bd:	48 29 c1             	sub    %rax,%rcx
     9c0:	49 39 d2             	cmp    %rdx,%r10
     9c3:	49 0f 42 cb          	cmovb  %r11,%rcx
     9c7:	4c 39 c0             	cmp    %r8,%rax
     9ca:	74 48                	je     a14 <mi_page_queue_enqueue_from_ex.constprop.0+0x204>
     9cc:	49 39 d2             	cmp    %rdx,%r10
     9cf:	72 43                	jb     a14 <mi_page_queue_enqueue_from_ex.constprop.0+0x204>
     9d1:	49 89 c8             	mov    %rcx,%r8
     9d4:	49 8d 94 c5 18 01 00 	lea    0x118(%r13,%rax,8),%rdx
     9db:	00 
     9dc:	49 d1 e8             	shr    $1,%r8
     9df:	49 c1 e0 04          	shl    $0x4,%r8
     9e3:	4d 8d 14 10          	lea    (%r8,%rdx,1),%r10
     9e7:	41 83 e0 10          	and    $0x10,%r8d
     9eb:	0f 85 ef 01 00 00    	jne    be0 <mi_page_queue_enqueue_from_ex.constprop.0+0x3d0>
     9f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     9f8:	0f 11 02             	movups %xmm0,(%rdx)
     9fb:	48 83 c2 20          	add    $0x20,%rdx
     9ff:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
     a03:	4c 39 d2             	cmp    %r10,%rdx
     a06:	75 f0                	jne    9f8 <mi_page_queue_enqueue_from_ex.constprop.0+0x1e8>
     a08:	f6 c1 01             	test   $0x1,%cl
     a0b:	74 0b                	je     a18 <mi_page_queue_enqueue_from_ex.constprop.0+0x208>
     a0d:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     a11:	48 01 c8             	add    %rcx,%rax
     a14:	49 89 1c c1          	mov    %rbx,(%r9,%rax,8)
     a18:	48 8b 03             	mov    (%rbx),%rax
     a1b:	48 89 c1             	mov    %rax,%rcx
     a1e:	48 89 c2             	mov    %rax,%rdx
     a21:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     a25:	f0 48 0f b1 0b       	lock cmpxchg %rcx,(%rbx)
     a2a:	0f 84 86 fe ff ff    	je     8b6 <mi_page_queue_enqueue_from_ex.constprop.0+0xa6>
     a30:	eb e9                	jmp    a1b <mi_page_queue_enqueue_from_ex.constprop.0+0x20b>
     a32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     a38:	48 8b 53 50          	mov    0x50(%rbx),%rdx
     a3c:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
     a41:	49 3b 1c 24          	cmp    (%r12),%rbx
     a45:	0f 85 13 fe ff ff    	jne    85e <mi_page_queue_enqueue_from_ex.constprop.0+0x4e>
     a4b:	4d 8b 74 24 18       	mov    0x18(%r12),%r14
     a50:	49 89 04 24          	mov    %rax,(%r12)
     a54:	49 81 fe 00 04 00 00 	cmp    $0x400,%r14
     a5b:	0f 87 fd fd ff ff    	ja     85e <mi_page_queue_enqueue_from_ex.constprop.0+0x4e>
     a61:	48 85 c0             	test   %rax,%rax
     a64:	0f 84 ae 01 00 00    	je     c18 <mi_page_queue_enqueue_from_ex.constprop.0+0x408>
     a6a:	49 8d 7e 07          	lea    0x7(%r14),%rdi
     a6e:	4d 8d 85 18 01 00 00 	lea    0x118(%r13),%r8
     a75:	48 c1 ef 03          	shr    $0x3,%rdi
     a79:	49 39 84 fd 18 01 00 	cmp    %rax,0x118(%r13,%rdi,8)
     a80:	00 
     a81:	0f 84 d7 fd ff ff    	je     85e <mi_page_queue_enqueue_from_ex.constprop.0+0x4e>
     a87:	48 83 ff 01          	cmp    $0x1,%rdi
     a8b:	0f 86 67 01 00 00    	jbe    bf8 <mi_page_queue_enqueue_from_ex.constprop.0+0x3e8>
     a91:	48 83 ff 08          	cmp    $0x8,%rdi
     a95:	0f 87 a6 01 00 00    	ja     c41 <mi_page_queue_enqueue_from_ex.constprop.0+0x431>
     a9b:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     a9f:	4d 89 cb             	mov    %r9,%r11
     aa2:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
     aa6:	49 8d 74 24 e0       	lea    -0x20(%r12),%rsi
     aab:	4d 8d 95 20 05 00 00 	lea    0x520(%r13),%r10
     ab2:	eb 1a                	jmp    ace <mi_page_queue_enqueue_from_ex.constprop.0+0x2be>
     ab4:	0f 1f 40 00          	nopl   0x0(%rax)
     ab8:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
     abc:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
     ac0:	49 39 cb             	cmp    %rcx,%r11
     ac3:	75 28                	jne    aed <mi_page_queue_enqueue_from_ex.constprop.0+0x2dd>
     ac5:	49 39 f2             	cmp    %rsi,%r10
     ac8:	73 23                	jae    aed <mi_page_queue_enqueue_from_ex.constprop.0+0x2dd>
     aca:	48 83 ee 20          	sub    $0x20,%rsi
     ace:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
     ad2:	48 83 c1 07          	add    $0x7,%rcx
     ad6:	48 89 ca             	mov    %rcx,%rdx
     ad9:	48 c1 ea 03          	shr    $0x3,%rdx
     add:	48 83 f9 47          	cmp    $0x47,%rcx
     ae1:	0f 87 99 00 00 00    	ja     b80 <mi_page_queue_enqueue_from_ex.constprop.0+0x370>
     ae7:	48 83 fa 01          	cmp    $0x1,%rdx
     aeb:	77 cb                	ja     ab8 <mi_page_queue_enqueue_from_ex.constprop.0+0x2a8>
     aed:	48 83 c2 01          	add    $0x1,%rdx
     af1:	48 39 fa             	cmp    %rdi,%rdx
     af4:	48 0f 47 d7          	cmova  %rdi,%rdx
     af8:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
     afc:	4c 89 ce             	mov    %r9,%rsi
     aff:	41 ba 01 00 00 00    	mov    $0x1,%r10d
     b05:	48 29 d6             	sub    %rdx,%rsi
     b08:	49 39 c9             	cmp    %rcx,%r9
     b0b:	49 0f 42 f2          	cmovb  %r10,%rsi
     b0f:	48 39 d7             	cmp    %rdx,%rdi
     b12:	74 5d                	je     b71 <mi_page_queue_enqueue_from_ex.constprop.0+0x361>
     b14:	49 39 c9             	cmp    %rcx,%r9
     b17:	72 58                	jb     b71 <mi_page_queue_enqueue_from_ex.constprop.0+0x361>
     b19:	48 89 f7             	mov    %rsi,%rdi
     b1c:	49 8d 8c d5 18 01 00 	lea    0x118(%r13,%rdx,8),%rcx
     b23:	00 
     b24:	66 48 0f 6e c0       	movq   %rax,%xmm0
     b29:	48 d1 ef             	shr    $1,%rdi
     b2c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
     b30:	48 c1 e7 04          	shl    $0x4,%rdi
     b34:	4c 8d 0c 0f          	lea    (%rdi,%rcx,1),%r9
     b38:	83 e7 10             	and    $0x10,%edi
     b3b:	74 13                	je     b50 <mi_page_queue_enqueue_from_ex.constprop.0+0x340>
     b3d:	0f 11 01             	movups %xmm0,(%rcx)
     b40:	48 83 c1 10          	add    $0x10,%rcx
     b44:	49 39 c9             	cmp    %rcx,%r9
     b47:	74 17                	je     b60 <mi_page_queue_enqueue_from_ex.constprop.0+0x350>
     b49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     b50:	0f 11 01             	movups %xmm0,(%rcx)
     b53:	48 83 c1 20          	add    $0x20,%rcx
     b57:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
     b5b:	49 39 c9             	cmp    %rcx,%r9
     b5e:	75 f0                	jne    b50 <mi_page_queue_enqueue_from_ex.constprop.0+0x340>
     b60:	40 f6 c6 01          	test   $0x1,%sil
     b64:	0f 84 f4 fc ff ff    	je     85e <mi_page_queue_enqueue_from_ex.constprop.0+0x4e>
     b6a:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
     b6e:	48 01 f2             	add    %rsi,%rdx
     b71:	49 89 04 d0          	mov    %rax,(%r8,%rdx,8)
     b75:	e9 e4 fc ff ff       	jmp    85e <mi_page_queue_enqueue_from_ex.constprop.0+0x4e>
     b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     b80:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
     b87:	0f 87 60 ff ff ff    	ja     aed <mi_page_queue_enqueue_from_ex.constprop.0+0x2dd>
     b8d:	4c 8d 72 ff          	lea    -0x1(%rdx),%r14
     b91:	4d 0f bd fe          	bsr    %r14,%r15
     b95:	41 8d 4f fe          	lea    -0x2(%r15),%ecx
     b99:	49 d3 ee             	shr    %cl,%r14
     b9c:	41 83 e6 03          	and    $0x3,%r14d
     ba0:	4b 8d 4c be fd       	lea    -0x3(%r14,%r15,4),%rcx
     ba5:	e9 16 ff ff ff       	jmp    ac0 <mi_page_queue_enqueue_from_ex.constprop.0+0x2b0>
     baa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     bb0:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
     bb6:	0f 87 e9 fd ff ff    	ja     9a5 <mi_page_queue_enqueue_from_ex.constprop.0+0x195>
     bbc:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
     bc0:	4c 0f bd f2          	bsr    %rdx,%r14
     bc4:	41 8d 4e fe          	lea    -0x2(%r14),%ecx
     bc8:	48 d3 ea             	shr    %cl,%rdx
     bcb:	83 e2 03             	and    $0x3,%edx
     bce:	4a 8d 54 b2 fd       	lea    -0x3(%rdx,%r14,4),%rdx
     bd3:	e9 a0 fd ff ff       	jmp    978 <mi_page_queue_enqueue_from_ex.constprop.0+0x168>
     bd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     bdf:	00 
     be0:	0f 11 02             	movups %xmm0,(%rdx)
     be3:	48 83 c2 10          	add    $0x10,%rdx
     be7:	4c 39 d2             	cmp    %r10,%rdx
     bea:	0f 85 08 fe ff ff    	jne    9f8 <mi_page_queue_enqueue_from_ex.constprop.0+0x1e8>
     bf0:	e9 13 fe ff ff       	jmp    a08 <mi_page_queue_enqueue_from_ex.constprop.0+0x1f8>
     bf5:	0f 1f 00             	nopl   (%rax)
     bf8:	31 d2                	xor    %edx,%edx
     bfa:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     bfe:	e9 f5 fe ff ff       	jmp    af8 <mi_page_queue_enqueue_from_ex.constprop.0+0x2e8>
     c03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     c08:	31 c0                	xor    %eax,%eax
     c0a:	4d 8d 50 01          	lea    0x1(%r8),%r10
     c0e:	e9 9d fd ff ff       	jmp    9b0 <mi_page_queue_enqueue_from_ex.constprop.0+0x1a0>
     c13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     c18:	e8 00 00 00 00       	call   c1d <mi_page_queue_enqueue_from_ex.constprop.0+0x40d>
			c19: R_X86_64_PLT32	_mi_page_empty_get-0x4
     c1d:	e9 48 fe ff ff       	jmp    a6a <mi_page_queue_enqueue_from_ex.constprop.0+0x25a>
     c22:	49 8d 40 ff          	lea    -0x1(%r8),%rax
     c26:	4d 8d 50 01          	lea    0x1(%r8),%r10
     c2a:	48 0f bd d0          	bsr    %rax,%rdx
     c2e:	8d 4a fe             	lea    -0x2(%rdx),%ecx
     c31:	48 d3 e8             	shr    %cl,%rax
     c34:	83 e0 03             	and    $0x3,%eax
     c37:	4c 8d 5c 90 fd       	lea    -0x3(%rax,%rdx,4),%r11
     c3c:	e9 1d fd ff ff       	jmp    95e <mi_page_queue_enqueue_from_ex.constprop.0+0x14e>
     c41:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
     c45:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
     c49:	48 0f bd f2          	bsr    %rdx,%rsi
     c4d:	8d 4e fe             	lea    -0x2(%rsi),%ecx
     c50:	48 d3 ea             	shr    %cl,%rdx
     c53:	83 e2 03             	and    $0x3,%edx
     c56:	4c 8d 5c b2 fd       	lea    -0x3(%rdx,%rsi,4),%r11
     c5b:	e9 46 fe ff ff       	jmp    aa6 <mi_page_queue_enqueue_from_ex.constprop.0+0x296>

0000000000000c60 <_mi_bin>:
     c60:	48 83 c7 07          	add    $0x7,%rdi
     c64:	48 89 fa             	mov    %rdi,%rdx
     c67:	48 c1 ea 03          	shr    $0x3,%rdx
     c6b:	48 83 ff 47          	cmp    $0x47,%rdi
     c6f:	77 1f                	ja     c90 <_mi_bin+0x30>
     c71:	48 8d 42 01          	lea    0x1(%rdx),%rax
     c75:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
     c79:	48 83 fa 01          	cmp    $0x1,%rdx
     c7d:	ba 01 00 00 00       	mov    $0x1,%edx
     c82:	48 0f 46 c2          	cmovbe %rdx,%rax
     c86:	c3                   	ret
     c87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     c8e:	00 00 
     c90:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
     c97:	77 17                	ja     cb0 <_mi_bin+0x50>
     c99:	48 83 ea 01          	sub    $0x1,%rdx
     c9d:	48 0f bd c2          	bsr    %rdx,%rax
     ca1:	8d 48 fe             	lea    -0x2(%rax),%ecx
     ca4:	48 d3 ea             	shr    %cl,%rdx
     ca7:	83 e2 03             	and    $0x3,%edx
     caa:	48 8d 44 82 fd       	lea    -0x3(%rdx,%rax,4),%rax
     caf:	c3                   	ret
     cb0:	b8 49 00 00 00       	mov    $0x49,%eax
     cb5:	c3                   	ret
     cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
     cbd:	00 00 00 

0000000000000cc0 <_mi_bin_size>:
     cc0:	48 c1 e7 05          	shl    $0x5,%rdi
     cc4:	48 8d 05 00 00 00 00 	lea    0x0(%rip),%rax        # ccb <_mi_bin_size+0xb>
			cc7: R_X86_64_PC32	_mi_theap_empty-0x4
     ccb:	48 8b 84 38 38 05 00 	mov    0x538(%rax,%rdi,1),%rax
     cd2:	00 
     cd3:	c3                   	ret
     cd4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
     cdb:	00 00 00 00 
     cdf:	90                   	nop

0000000000000ce0 <mi_good_size>:
     ce0:	53                   	push   %rbx
     ce1:	48 89 fb             	mov    %rdi,%rbx
     ce4:	48 81 ff 00 00 08 00 	cmp    $0x80000,%rdi
     ceb:	76 33                	jbe    d20 <mi_good_size+0x40>
     ced:	48 85 ff             	test   %rdi,%rdi
     cf0:	79 0e                	jns    d00 <mi_good_size+0x20>
     cf2:	48 89 d8             	mov    %rbx,%rax
     cf5:	5b                   	pop    %rbx
     cf6:	c3                   	ret
     cf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     cfe:	00 00 
     d00:	e8 00 00 00 00       	call   d05 <mi_good_size+0x25>
			d01: R_X86_64_PLT32	_mi_os_page_size-0x4
     d05:	48 89 c1             	mov    %rax,%rcx
     d08:	48 8d 40 ff          	lea    -0x1(%rax),%rax
     d0c:	48 01 c3             	add    %rax,%rbx
     d0f:	48 85 c1             	test   %rax,%rcx
     d12:	75 4c                	jne    d60 <mi_good_size+0x80>
     d14:	48 f7 d9             	neg    %rcx
     d17:	48 21 cb             	and    %rcx,%rbx
     d1a:	48 89 d8             	mov    %rbx,%rax
     d1d:	5b                   	pop    %rbx
     d1e:	c3                   	ret
     d1f:	90                   	nop
     d20:	48 83 c3 07          	add    $0x7,%rbx
     d24:	48 89 da             	mov    %rbx,%rdx
     d27:	48 c1 ea 03          	shr    $0x3,%rdx
     d2b:	48 83 fb 47          	cmp    $0x47,%rbx
     d2f:	77 3f                	ja     d70 <mi_good_size+0x90>
     d31:	48 8d 42 01          	lea    0x1(%rdx),%rax
     d35:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
     d39:	48 83 fa 01          	cmp    $0x1,%rdx
     d3d:	ba 01 00 00 00       	mov    $0x1,%edx
     d42:	48 0f 46 c2          	cmovbe %rdx,%rax
     d46:	48 c1 e0 05          	shl    $0x5,%rax
     d4a:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # d51 <mi_good_size+0x71>
			d4d: R_X86_64_PC32	_mi_theap_empty-0x4
     d51:	48 8b 9c 02 38 05 00 	mov    0x538(%rdx,%rax,1),%rbx
     d58:	00 
     d59:	48 89 d8             	mov    %rbx,%rax
     d5c:	5b                   	pop    %rbx
     d5d:	c3                   	ret
     d5e:	66 90                	xchg   %ax,%ax
     d60:	48 89 d8             	mov    %rbx,%rax
     d63:	31 d2                	xor    %edx,%edx
     d65:	48 f7 f1             	div    %rcx
     d68:	48 29 d3             	sub    %rdx,%rbx
     d6b:	48 89 d8             	mov    %rbx,%rax
     d6e:	5b                   	pop    %rbx
     d6f:	c3                   	ret
     d70:	48 83 ea 01          	sub    $0x1,%rdx
     d74:	48 0f bd c2          	bsr    %rdx,%rax
     d78:	8d 48 fe             	lea    -0x2(%rax),%ecx
     d7b:	48 d3 ea             	shr    %cl,%rdx
     d7e:	83 e2 03             	and    $0x3,%edx
     d81:	48 8d 44 82 fd       	lea    -0x3(%rdx,%rax,4),%rax
     d86:	eb be                	jmp    d46 <mi_good_size+0x66>
     d88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     d8f:	00 

0000000000000d90 <_mi_page_queue_is_valid>:
     d90:	48 85 f6             	test   %rsi,%rsi
     d93:	74 23                	je     db8 <_mi_page_queue_is_valid+0x28>
     d95:	48 8b 06             	mov    (%rsi),%rax
     d98:	48 85 c0             	test   %rax,%rax
     d9b:	74 0f                	je     dac <_mi_page_queue_is_valid+0x1c>
     d9d:	0f 1f 00             	nopl   (%rax)
     da0:	48 8b 10             	mov    (%rax),%rdx
     da3:	48 8b 40 48          	mov    0x48(%rax),%rax
     da7:	48 85 c0             	test   %rax,%rax
     daa:	75 f4                	jne    da0 <_mi_page_queue_is_valid+0x10>
     dac:	b8 01 00 00 00       	mov    $0x1,%eax
     db1:	c3                   	ret
     db2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     db8:	31 c0                	xor    %eax,%eax
     dba:	c3                   	ret
     dbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000000dc0 <_mi_page_stats_bin>:
     dc0:	66 83 7f 36 01       	cmpw   $0x1,0x36(%rdi)
     dc5:	48 8b 57 28          	mov    0x28(%rdi),%rdx
     dc9:	74 2d                	je     df8 <_mi_page_stats_bin+0x38>
     dcb:	48 83 c2 07          	add    $0x7,%rdx
     dcf:	48 89 d1             	mov    %rdx,%rcx
     dd2:	48 c1 e9 03          	shr    $0x3,%rcx
     dd6:	48 83 fa 47          	cmp    $0x47,%rdx
     dda:	77 74                	ja     e50 <_mi_page_stats_bin+0x90>
     ddc:	48 8d 41 01          	lea    0x1(%rcx),%rax
     de0:	ba 01 00 00 00       	mov    $0x1,%edx
     de5:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
     de9:	48 83 f9 01          	cmp    $0x1,%rcx
     ded:	48 0f 46 c2          	cmovbe %rdx,%rax
     df1:	c3                   	ret
     df2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
     df8:	b8 49 00 00 00       	mov    $0x49,%eax
     dfd:	48 81 fa 00 00 08 00 	cmp    $0x80000,%rdx
     e04:	77 11                	ja     e17 <_mi_page_stats_bin+0x57>
     e06:	8b 77 68             	mov    0x68(%rdi),%esi
     e09:	8d 4e fd             	lea    -0x3(%rsi),%ecx
     e0c:	83 f9 02             	cmp    $0x2,%ecx
     e0f:	77 0f                	ja     e20 <_mi_page_stats_bin+0x60>
     e11:	48 39 7f 58          	cmp    %rdi,0x58(%rdi)
     e15:	73 09                	jae    e20 <_mi_page_stats_bin+0x60>
     e17:	c3                   	ret
     e18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
     e1f:	00 
     e20:	48 83 c2 07          	add    $0x7,%rdx
     e24:	48 89 d1             	mov    %rdx,%rcx
     e27:	48 c1 e9 03          	shr    $0x3,%rcx
     e2b:	48 83 fa 47          	cmp    $0x47,%rdx
     e2f:	76 ab                	jbe    ddc <_mi_page_stats_bin+0x1c>
     e31:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
     e35:	48 0f bd d0          	bsr    %rax,%rdx
     e39:	8d 4a fe             	lea    -0x2(%rdx),%ecx
     e3c:	48 d3 e8             	shr    %cl,%rax
     e3f:	48 89 c1             	mov    %rax,%rcx
     e42:	83 e1 03             	and    $0x3,%ecx
     e45:	48 8d 44 91 fd       	lea    -0x3(%rcx,%rdx,4),%rax
     e4a:	c3                   	ret
     e4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
     e50:	48 81 f9 00 00 01 00 	cmp    $0x10000,%rcx
     e57:	76 d8                	jbe    e31 <_mi_page_stats_bin+0x71>
     e59:	b8 49 00 00 00       	mov    $0x49,%eax
     e5e:	c3                   	ret
     e5f:	90                   	nop

0000000000000e60 <_mi_page_free_collect>:
     e60:	55                   	push   %rbp
     e61:	89 f5                	mov    %esi,%ebp
     e63:	48 8d 77 20          	lea    0x20(%rdi),%rsi
     e67:	53                   	push   %rbx
     e68:	48 89 fb             	mov    %rdi,%rbx
     e6b:	48 83 ec 08          	sub    $0x8,%rsp
     e6f:	48 8b 07             	mov    (%rdi),%rax
     e72:	48 8b 57 20          	mov    0x20(%rdi),%rdx
     e76:	48 83 fa 01          	cmp    $0x1,%rdx
     e7a:	77 74                	ja     ef0 <_mi_page_free_collect+0x90>
     e7c:	48 8b 43 18          	mov    0x18(%rbx),%rax
     e80:	48 8b 53 08          	mov    0x8(%rbx),%rdx
     e84:	48 85 c0             	test   %rax,%rax
     e87:	74 27                	je     eb0 <_mi_page_free_collect+0x50>
     e89:	48 85 d2             	test   %rdx,%rdx
     e8c:	0f 85 c6 00 00 00    	jne    f58 <_mi_page_free_collect+0xf8>
     e92:	48 89 43 08          	mov    %rax,0x8(%rbx)
     e96:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
     e9d:	00 
     e9e:	c6 43 17 00          	movb   $0x0,0x17(%rbx)
     ea2:	48 83 c4 08          	add    $0x8,%rsp
     ea6:	5b                   	pop    %rbx
     ea7:	5d                   	pop    %rbp
     ea8:	c3                   	ret
     ea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
     eb0:	48 85 d2             	test   %rdx,%rdx
     eb3:	75 ed                	jne    ea2 <_mi_page_free_collect+0x42>
     eb5:	48 83 7b 70 00       	cmpq   $0x0,0x70(%rbx)
     eba:	75 1b                	jne    ed7 <_mi_page_free_collect+0x77>
     ebc:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
     ec1:	75 14                	jne    ed7 <_mi_page_free_collect+0x77>
     ec3:	48 83 bb 80 00 00 00 	cmpq   $0x0,0x80(%rbx)
     eca:	00 
     ecb:	75 0a                	jne    ed7 <_mi_page_free_collect+0x77>
     ecd:	48 83 bb 88 00 00 00 	cmpq   $0x0,0x88(%rbx)
     ed4:	00 
     ed5:	74 cb                	je     ea2 <_mi_page_free_collect+0x42>
     ed7:	e8 00 00 00 00       	call   edc <_mi_page_free_collect+0x7c>
			ed8: R_X86_64_PLT32	_mi_page_purge_holes_in_progress-0x4
     edc:	84 c0                	test   %al,%al
     ede:	75 c2                	jne    ea2 <_mi_page_free_collect+0x42>
     ee0:	48 83 c4 08          	add    $0x8,%rsp
     ee4:	48 89 df             	mov    %rbx,%rdi
     ee7:	5b                   	pop    %rbx
     ee8:	5d                   	pop    %rbp
     ee9:	e9 00 00 00 00       	jmp    eee <_mi_page_free_collect+0x8e>
			eea: R_X86_64_PLT32	_mi_page_unpurge_run-0x4
     eee:	66 90                	xchg   %ax,%ax
     ef0:	48 89 d1             	mov    %rdx,%rcx
     ef3:	48 89 d0             	mov    %rdx,%rax
     ef6:	83 e1 01             	and    $0x1,%ecx
     ef9:	f0 48 0f b1 0e       	lock cmpxchg %rcx,(%rsi)
     efe:	0f 94 c1             	sete   %cl
     f01:	0f b6 c9             	movzbl %cl,%ecx
     f04:	0f 85 b5 00 00 00    	jne    fbf <_mi_page_free_collect+0x15f>
     f0a:	48 89 d0             	mov    %rdx,%rax
     f0d:	0f b7 73 14          	movzwl 0x14(%rbx),%esi
     f11:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
     f15:	48 8b 10             	mov    (%rax),%rdx
     f18:	48 85 d2             	test   %rdx,%rdx
     f1b:	74 5e                	je     f7b <_mi_page_free_collect+0x11b>
     f1d:	48 85 f6             	test   %rsi,%rsi
     f20:	75 0b                	jne    f2d <_mi_page_free_collect+0xcd>
     f22:	eb 57                	jmp    f7b <_mi_page_free_collect+0x11b>
     f24:	0f 1f 40 00          	nopl   0x0(%rax)
     f28:	48 85 d2             	test   %rdx,%rdx
     f2b:	74 51                	je     f7e <_mi_page_free_collect+0x11e>
     f2d:	48 83 c1 01          	add    $0x1,%rcx
     f31:	48 89 d7             	mov    %rdx,%rdi
     f34:	48 8b 12             	mov    (%rdx),%rdx
     f37:	48 39 ce             	cmp    %rcx,%rsi
     f3a:	73 ec                	jae    f28 <_mi_page_free_collect+0xc8>
     f3c:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # f43 <_mi_page_free_collect+0xe3>
			f3f: R_X86_64_PC32	.LC0-0x4
     f43:	bf 0e 00 00 00       	mov    $0xe,%edi
     f48:	31 c0                	xor    %eax,%eax
     f4a:	e8 00 00 00 00       	call   f4f <_mi_page_free_collect+0xef>
			f4b: R_X86_64_PLT32	_mi_error_message-0x4
     f4f:	e9 28 ff ff ff       	jmp    e7c <_mi_page_free_collect+0x1c>
     f54:	0f 1f 40 00          	nopl   0x0(%rax)
     f58:	40 84 ed             	test   %bpl,%bpl
     f5b:	0f 84 41 ff ff ff    	je     ea2 <_mi_page_free_collect+0x42>
     f61:	48 89 c1             	mov    %rax,%rcx
     f64:	0f 1f 40 00          	nopl   0x0(%rax)
     f68:	48 89 ce             	mov    %rcx,%rsi
     f6b:	48 8b 09             	mov    (%rcx),%rcx
     f6e:	48 85 c9             	test   %rcx,%rcx
     f71:	75 f5                	jne    f68 <_mi_page_free_collect+0x108>
     f73:	48 89 16             	mov    %rdx,(%rsi)
     f76:	e9 17 ff ff ff       	jmp    e92 <_mi_page_free_collect+0x32>
     f7b:	48 89 c7             	mov    %rax,%rdi
     f7e:	48 39 ce             	cmp    %rcx,%rsi
     f81:	72 b9                	jb     f3c <_mi_page_free_collect+0xdc>
     f83:	8b 73 10             	mov    0x10(%rbx),%esi
     f86:	48 89 f2             	mov    %rsi,%rdx
     f89:	48 39 ce             	cmp    %rcx,%rsi
     f8c:	72 19                	jb     fa7 <_mi_page_free_collect+0x147>
     f8e:	48 8b 73 18          	mov    0x18(%rbx),%rsi
     f92:	29 ca                	sub    %ecx,%edx
     f94:	48 89 37             	mov    %rsi,(%rdi)
     f97:	89 53 10             	mov    %edx,0x10(%rbx)
     f9a:	48 8b 53 08          	mov    0x8(%rbx),%rdx
     f9e:	48 89 43 18          	mov    %rax,0x18(%rbx)
     fa2:	e9 e2 fe ff ff       	jmp    e89 <_mi_page_free_collect+0x29>
     fa7:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # fae <_mi_page_free_collect+0x14e>
			faa: R_X86_64_PC32	.LC1-0x4
     fae:	bf 0e 00 00 00       	mov    $0xe,%edi
     fb3:	31 c0                	xor    %eax,%eax
     fb5:	e8 00 00 00 00       	call   fba <_mi_page_free_collect+0x15a>
			fb6: R_X86_64_PLT32	_mi_error_message-0x4
     fba:	e9 bd fe ff ff       	jmp    e7c <_mi_page_free_collect+0x1c>
     fbf:	48 89 c2             	mov    %rax,%rdx
     fc2:	e9 af fe ff ff       	jmp    e76 <_mi_page_free_collect+0x16>
     fc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     fce:	00 00 

0000000000000fd0 <_mi_page_free_collect_no_unpurge>:
     fd0:	41 54                	push   %r12
     fd2:	55                   	push   %rbp
     fd3:	89 f5                	mov    %esi,%ebp
     fd5:	53                   	push   %rbx
     fd6:	48 8b 07             	mov    (%rdi),%rax
     fd9:	48 89 fb             	mov    %rdi,%rbx
     fdc:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
     fe0:	48 83 f8 04          	cmp    $0x4,%rax
     fe4:	76 42                	jbe    1028 <_mi_page_free_collect_no_unpurge+0x58>
     fe6:	48 8b 47 38          	mov    0x38(%rdi),%rax
     fea:	48 85 c0             	test   %rax,%rax
     fed:	74 30                	je     101f <_mi_page_free_collect_no_unpurge+0x4f>
     fef:	48 8b 50 08          	mov    0x8(%rax),%rdx
     ff3:	48 85 d2             	test   %rdx,%rdx
     ff6:	74 30                	je     1028 <_mi_page_free_collect_no_unpurge+0x58>
     ff8:	4c 8b 20             	mov    (%rax),%r12
     ffb:	4d 85 e4             	test   %r12,%r12
     ffe:	74 1f                	je     101f <_mi_page_free_collect_no_unpurge+0x4f>
    1000:	49 83 3c 24 08       	cmpq   $0x8,(%r12)
    1005:	74 21                	je     1028 <_mi_page_free_collect_no_unpurge+0x58>
    1007:	e8 00 00 00 00       	call   100c <_mi_page_free_collect_no_unpurge+0x3c>
			1008: R_X86_64_PLT32	_mi_thread_id-0x4
    100c:	49 3b 04 24          	cmp    (%r12),%rax
    1010:	74 16                	je     1028 <_mi_page_free_collect_no_unpurge+0x58>
    1012:	49 8b 94 24 48 01 00 	mov    0x148(%r12),%rdx
    1019:	00 
    101a:	48 39 d0             	cmp    %rdx,%rax
    101d:	74 09                	je     1028 <_mi_page_free_collect_no_unpurge+0x58>
    101f:	5b                   	pop    %rbx
    1020:	5d                   	pop    %rbp
    1021:	41 5c                	pop    %r12
    1023:	c3                   	ret
    1024:	0f 1f 40 00          	nopl   0x0(%rax)
    1028:	48 8b 03             	mov    (%rbx),%rax
    102b:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    102f:	48 8d 73 20          	lea    0x20(%rbx),%rsi
    1033:	48 83 fa 01          	cmp    $0x1,%rdx
    1037:	77 27                	ja     1060 <_mi_page_free_collect_no_unpurge+0x90>
    1039:	48 8b 43 18          	mov    0x18(%rbx),%rax
    103d:	48 85 c0             	test   %rax,%rax
    1040:	74 dd                	je     101f <_mi_page_free_collect_no_unpurge+0x4f>
    1042:	48 8b 53 08          	mov    0x8(%rbx),%rdx
    1046:	48 85 d2             	test   %rdx,%rdx
    1049:	75 7d                	jne    10c8 <_mi_page_free_collect_no_unpurge+0xf8>
    104b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    104f:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    1056:	00 
    1057:	c6 43 17 00          	movb   $0x0,0x17(%rbx)
    105b:	5b                   	pop    %rbx
    105c:	5d                   	pop    %rbp
    105d:	41 5c                	pop    %r12
    105f:	c3                   	ret
    1060:	48 89 d1             	mov    %rdx,%rcx
    1063:	48 89 d0             	mov    %rdx,%rax
    1066:	83 e1 01             	and    $0x1,%ecx
    1069:	f0 48 0f b1 0e       	lock cmpxchg %rcx,(%rsi)
    106e:	0f 94 c1             	sete   %cl
    1071:	0f b6 c9             	movzbl %cl,%ecx
    1074:	0f 85 b1 00 00 00    	jne    112b <_mi_page_free_collect_no_unpurge+0x15b>
    107a:	48 89 d0             	mov    %rdx,%rax
    107d:	0f b7 73 14          	movzwl 0x14(%rbx),%esi
    1081:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    1085:	48 8b 10             	mov    (%rax),%rdx
    1088:	48 85 f6             	test   %rsi,%rsi
    108b:	74 5e                	je     10eb <_mi_page_free_collect_no_unpurge+0x11b>
    108d:	48 85 d2             	test   %rdx,%rdx
    1090:	75 0b                	jne    109d <_mi_page_free_collect_no_unpurge+0xcd>
    1092:	eb 57                	jmp    10eb <_mi_page_free_collect_no_unpurge+0x11b>
    1094:	0f 1f 40 00          	nopl   0x0(%rax)
    1098:	48 85 d2             	test   %rdx,%rdx
    109b:	74 51                	je     10ee <_mi_page_free_collect_no_unpurge+0x11e>
    109d:	48 83 c1 01          	add    $0x1,%rcx
    10a1:	48 89 d7             	mov    %rdx,%rdi
    10a4:	48 8b 12             	mov    (%rdx),%rdx
    10a7:	48 39 ce             	cmp    %rcx,%rsi
    10aa:	73 ec                	jae    1098 <_mi_page_free_collect_no_unpurge+0xc8>
    10ac:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 10b3 <_mi_page_free_collect_no_unpurge+0xe3>
			10af: R_X86_64_PC32	.LC0-0x4
    10b3:	bf 0e 00 00 00       	mov    $0xe,%edi
    10b8:	31 c0                	xor    %eax,%eax
    10ba:	e8 00 00 00 00       	call   10bf <_mi_page_free_collect_no_unpurge+0xef>
			10bb: R_X86_64_PLT32	_mi_error_message-0x4
    10bf:	e9 75 ff ff ff       	jmp    1039 <_mi_page_free_collect_no_unpurge+0x69>
    10c4:	0f 1f 40 00          	nopl   0x0(%rax)
    10c8:	40 84 ed             	test   %bpl,%bpl
    10cb:	0f 84 4e ff ff ff    	je     101f <_mi_page_free_collect_no_unpurge+0x4f>
    10d1:	48 89 c1             	mov    %rax,%rcx
    10d4:	0f 1f 40 00          	nopl   0x0(%rax)
    10d8:	48 89 ce             	mov    %rcx,%rsi
    10db:	48 8b 09             	mov    (%rcx),%rcx
    10de:	48 85 c9             	test   %rcx,%rcx
    10e1:	75 f5                	jne    10d8 <_mi_page_free_collect_no_unpurge+0x108>
    10e3:	48 89 16             	mov    %rdx,(%rsi)
    10e6:	e9 60 ff ff ff       	jmp    104b <_mi_page_free_collect_no_unpurge+0x7b>
    10eb:	48 89 c7             	mov    %rax,%rdi
    10ee:	48 39 ce             	cmp    %rcx,%rsi
    10f1:	72 b9                	jb     10ac <_mi_page_free_collect_no_unpurge+0xdc>
    10f3:	8b 73 10             	mov    0x10(%rbx),%esi
    10f6:	48 89 f2             	mov    %rsi,%rdx
    10f9:	48 39 ce             	cmp    %rcx,%rsi
    10fc:	72 15                	jb     1113 <_mi_page_free_collect_no_unpurge+0x143>
    10fe:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    1102:	29 ca                	sub    %ecx,%edx
    1104:	48 89 37             	mov    %rsi,(%rdi)
    1107:	48 89 43 18          	mov    %rax,0x18(%rbx)
    110b:	89 53 10             	mov    %edx,0x10(%rbx)
    110e:	e9 2f ff ff ff       	jmp    1042 <_mi_page_free_collect_no_unpurge+0x72>
    1113:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 111a <_mi_page_free_collect_no_unpurge+0x14a>
			1116: R_X86_64_PC32	.LC1-0x4
    111a:	bf 0e 00 00 00       	mov    $0xe,%edi
    111f:	31 c0                	xor    %eax,%eax
    1121:	e8 00 00 00 00       	call   1126 <_mi_page_free_collect_no_unpurge+0x156>
			1122: R_X86_64_PLT32	_mi_error_message-0x4
    1126:	e9 0e ff ff ff       	jmp    1039 <_mi_page_free_collect_no_unpurge+0x69>
    112b:	48 89 c2             	mov    %rax,%rdx
    112e:	e9 00 ff ff ff       	jmp    1033 <_mi_page_free_collect_no_unpurge+0x63>
    1133:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    113a:	00 00 00 00 
    113e:	66 90                	xchg   %ax,%ax

0000000000001140 <_mi_page_free_collect_partly>:
    1140:	48 85 f6             	test   %rsi,%rsi
    1143:	0f 84 87 00 00 00    	je     11d0 <_mi_page_free_collect_partly+0x90>
    1149:	53                   	push   %rbx
    114a:	48 89 fb             	mov    %rdi,%rbx
    114d:	48 8b 3e             	mov    (%rsi),%rdi
    1150:	48 85 ff             	test   %rdi,%rdi
    1153:	75 0b                	jne    1160 <_mi_page_free_collect_partly+0x20>
    1155:	83 7b 10 01          	cmpl   $0x1,0x10(%rbx)
    1159:	74 65                	je     11c0 <_mi_page_free_collect_partly+0x80>
    115b:	5b                   	pop    %rbx
    115c:	c3                   	ret
    115d:	0f 1f 00             	nopl   (%rax)
    1160:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
    1167:	48 8b 07             	mov    (%rdi),%rax
    116a:	49 89 f8             	mov    %rdi,%r8
    116d:	0f b7 4b 14          	movzwl 0x14(%rbx),%ecx
    1171:	48 85 c0             	test   %rax,%rax
    1174:	74 62                	je     11d8 <_mi_page_free_collect_partly+0x98>
    1176:	48 85 c9             	test   %rcx,%rcx
    1179:	74 5d                	je     11d8 <_mi_page_free_collect_partly+0x98>
    117b:	ba 01 00 00 00       	mov    $0x1,%edx
    1180:	eb 0b                	jmp    118d <_mi_page_free_collect_partly+0x4d>
    1182:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1188:	48 85 c0             	test   %rax,%rax
    118b:	74 53                	je     11e0 <_mi_page_free_collect_partly+0xa0>
    118d:	48 83 c2 01          	add    $0x1,%rdx
    1191:	48 89 c6             	mov    %rax,%rsi
    1194:	48 8b 00             	mov    (%rax),%rax
    1197:	48 39 d1             	cmp    %rdx,%rcx
    119a:	73 ec                	jae    1188 <_mi_page_free_collect_partly+0x48>
    119c:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 11a3 <_mi_page_free_collect_partly+0x63>
			119f: R_X86_64_PC32	.LC0-0x4
    11a3:	bf 0e 00 00 00       	mov    $0xe,%edi
    11a8:	31 c0                	xor    %eax,%eax
    11aa:	e8 00 00 00 00       	call   11af <_mi_page_free_collect_partly+0x6f>
			11ab: R_X86_64_PLT32	_mi_error_message-0x4
    11af:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    11b3:	4d 85 c0             	test   %r8,%r8
    11b6:	74 9d                	je     1155 <_mi_page_free_collect_partly+0x15>
    11b8:	eb 46                	jmp    1200 <_mi_page_free_collect_partly+0xc0>
    11ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    11c0:	48 89 df             	mov    %rbx,%rdi
    11c3:	31 f6                	xor    %esi,%esi
    11c5:	5b                   	pop    %rbx
    11c6:	e9 55 f0 ff ff       	jmp    220 <mi_page_free_collect_ex.constprop.0>
    11cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    11d0:	c3                   	ret
    11d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    11d8:	48 89 fe             	mov    %rdi,%rsi
    11db:	ba 01 00 00 00       	mov    $0x1,%edx
    11e0:	48 39 d1             	cmp    %rdx,%rcx
    11e3:	72 b7                	jb     119c <_mi_page_free_collect_partly+0x5c>
    11e5:	8b 4b 10             	mov    0x10(%rbx),%ecx
    11e8:	48 89 c8             	mov    %rcx,%rax
    11eb:	48 39 d1             	cmp    %rdx,%rcx
    11ee:	72 30                	jb     1220 <_mi_page_free_collect_partly+0xe0>
    11f0:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
    11f4:	29 d0                	sub    %edx,%eax
    11f6:	48 89 0e             	mov    %rcx,(%rsi)
    11f9:	48 89 7b 18          	mov    %rdi,0x18(%rbx)
    11fd:	89 43 10             	mov    %eax,0x10(%rbx)
    1200:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    1205:	0f 85 4a ff ff ff    	jne    1155 <_mi_page_free_collect_partly+0x15>
    120b:	4c 89 43 08          	mov    %r8,0x8(%rbx)
    120f:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    1216:	00 
    1217:	c6 43 17 00          	movb   $0x0,0x17(%rbx)
    121b:	e9 35 ff ff ff       	jmp    1155 <_mi_page_free_collect_partly+0x15>
    1220:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 1227 <_mi_page_free_collect_partly+0xe7>
			1223: R_X86_64_PC32	.LC1-0x4
    1227:	bf 0e 00 00 00       	mov    $0xe,%edi
    122c:	31 c0                	xor    %eax,%eax
    122e:	e8 00 00 00 00       	call   1233 <_mi_page_free_collect_partly+0xf3>
			122f: R_X86_64_PLT32	_mi_error_message-0x4
    1233:	e9 77 ff ff ff       	jmp    11af <_mi_page_free_collect_partly+0x6f>
    1238:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    123f:	00 

0000000000001240 <_mi_theap_page_reclaim>:
    1240:	41 54                	push   %r12
    1242:	31 c9                	xor    %ecx,%ecx
    1244:	55                   	push   %rbp
    1245:	48 89 fd             	mov    %rdi,%rbp
    1248:	53                   	push   %rbx
    1249:	48 89 f3             	mov    %rsi,%rbx
    124c:	48 89 7e 38          	mov    %rdi,0x38(%rsi)
    1250:	48 85 ff             	test   %rdi,%rdi
    1253:	74 06                	je     125b <_mi_theap_page_reclaim+0x1b>
    1255:	48 8b 07             	mov    (%rdi),%rax
    1258:	48 8b 08             	mov    (%rax),%rcx
    125b:	48 8b 03             	mov    (%rbx),%rax
    125e:	48 89 c2             	mov    %rax,%rdx
    1261:	83 e2 03             	and    $0x3,%edx
    1264:	48 09 ca             	or     %rcx,%rdx
    1267:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    126c:	41 0f 94 c4          	sete   %r12b
    1270:	45 0f b6 e4          	movzbl %r12b,%r12d
    1274:	4d 85 e4             	test   %r12,%r12
    1277:	74 e5                	je     125e <_mi_theap_page_reclaim+0x1e>
    1279:	31 f6                	xor    %esi,%esi
    127b:	48 89 df             	mov    %rbx,%rdi
    127e:	e8 9d ef ff ff       	call   220 <mi_page_free_collect_ex.constprop.0>
    1283:	48 8b 03             	mov    (%rbx),%rax
    1286:	a8 01                	test   $0x1,%al
    1288:	0f 85 62 01 00 00    	jne    13f0 <_mi_theap_page_reclaim+0x1b0>
    128e:	66 83 7b 36 01       	cmpw   $0x1,0x36(%rbx)
    1293:	48 8b 43 28          	mov    0x28(%rbx),%rax
    1297:	0f 84 fb 00 00 00    	je     1398 <_mi_theap_page_reclaim+0x158>
    129d:	48 83 c0 07          	add    $0x7,%rax
    12a1:	48 89 c2             	mov    %rax,%rdx
    12a4:	48 c1 ea 03          	shr    $0x3,%rdx
    12a8:	48 83 f8 47          	cmp    $0x47,%rax
    12ac:	0f 87 16 03 00 00    	ja     15c8 <_mi_theap_page_reclaim+0x388>
    12b2:	be 40 05 00 00       	mov    $0x540,%esi
    12b7:	48 83 fa 01          	cmp    $0x1,%rdx
    12bb:	76 13                	jbe    12d0 <_mi_theap_page_reclaim+0x90>
    12bd:	48 83 c2 01          	add    $0x1,%rdx
    12c1:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    12c5:	48 8d 72 29          	lea    0x29(%rdx),%rsi
    12c9:	49 89 d4             	mov    %rdx,%r12
    12cc:	48 c1 e6 05          	shl    $0x5,%rsi
    12d0:	4c 89 e0             	mov    %r12,%rax
    12d3:	48 c1 e0 05          	shl    $0x5,%rax
    12d7:	48 8b 8c 05 38 05 00 	mov    0x538(%rbp,%rax,1),%rcx
    12de:	00 
    12df:	48 8b 03             	mov    (%rbx),%rax
    12e2:	48 81 f9 10 00 08 00 	cmp    $0x80010,%rcx
    12e9:	41 0f 94 c0          	sete   %r8b
    12ed:	0f 85 dd 00 00 00    	jne    13d0 <_mi_theap_page_reclaim+0x190>
    12f3:	48 89 c7             	mov    %rax,%rdi
    12f6:	48 89 c2             	mov    %rax,%rdx
    12f9:	48 83 cf 01          	or     $0x1,%rdi
    12fd:	f0 48 0f b1 3b       	lock cmpxchg %rdi,(%rbx)
    1302:	75 ef                	jne    12f3 <_mi_theap_page_reclaim+0xb3>
    1304:	83 e2 01             	and    $0x1,%edx
    1307:	41 38 d0             	cmp    %dl,%r8b
    130a:	74 34                	je     1340 <_mi_theap_page_reclaim+0x100>
    130c:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    1310:	48 85 d2             	test   %rdx,%rdx
    1313:	74 2b                	je     1340 <_mi_theap_page_reclaim+0x100>
    1315:	48 8b ba d0 00 00 00 	mov    0xd0(%rdx),%rdi
    131c:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
    1320:	48 0f af 43 28       	imul   0x28(%rbx),%rax
    1325:	49 89 f8             	mov    %rdi,%r8
    1328:	49 29 c0             	sub    %rax,%r8
    132b:	48 01 f8             	add    %rdi,%rax
    132e:	48 81 f9 10 00 08 00 	cmp    $0x80010,%rcx
    1335:	49 0f 45 c0          	cmovne %r8,%rax
    1339:	48 89 82 d0 00 00 00 	mov    %rax,0xd0(%rdx)
    1340:	4c 89 e0             	mov    %r12,%rax
    1343:	48 c1 e0 05          	shl    $0x5,%rax
    1347:	48 01 e8             	add    %rbp,%rax
    134a:	48 8b 90 28 05 00 00 	mov    0x528(%rax),%rdx
    1351:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
    1358:	00 
    1359:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    135d:	48 85 d2             	test   %rdx,%rdx
    1360:	0f 84 9a 00 00 00    	je     1400 <_mi_theap_page_reclaim+0x1c0>
    1366:	48 89 5a 48          	mov    %rbx,0x48(%rdx)
    136a:	48 83 80 30 05 00 00 	addq   $0x1,0x530(%rax)
    1371:	01 
    1372:	48 89 98 28 05 00 00 	mov    %rbx,0x528(%rax)
    1379:	48 3b 98 20 05 00 00 	cmp    0x520(%rax),%rbx
    1380:	0f 84 9a 00 00 00    	je     1420 <_mi_theap_page_reclaim+0x1e0>
    1386:	48 83 85 b8 00 00 00 	addq   $0x1,0xb8(%rbp)
    138d:	01 
    138e:	5b                   	pop    %rbx
    138f:	5d                   	pop    %rbp
    1390:	41 5c                	pop    %r12
    1392:	c3                   	ret
    1393:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1398:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
    139e:	77 20                	ja     13c0 <_mi_theap_page_reclaim+0x180>
    13a0:	8b 4b 68             	mov    0x68(%rbx),%ecx
    13a3:	8d 51 fd             	lea    -0x3(%rcx),%edx
    13a6:	83 fa 02             	cmp    $0x2,%edx
    13a9:	0f 87 a9 01 00 00    	ja     1558 <_mi_theap_page_reclaim+0x318>
    13af:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
    13b3:	0f 83 9f 01 00 00    	jae    1558 <_mi_theap_page_reclaim+0x318>
    13b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    13c0:	be 40 0e 00 00       	mov    $0xe40,%esi
    13c5:	41 bc 49 00 00 00    	mov    $0x49,%r12d
    13cb:	e9 00 ff ff ff       	jmp    12d0 <_mi_theap_page_reclaim+0x90>
    13d0:	48 89 c7             	mov    %rax,%rdi
    13d3:	48 89 c2             	mov    %rax,%rdx
    13d6:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
    13da:	f0 48 0f b1 3b       	lock cmpxchg %rdi,(%rbx)
    13df:	0f 84 1f ff ff ff    	je     1304 <_mi_theap_page_reclaim+0xc4>
    13e5:	eb e9                	jmp    13d0 <_mi_theap_page_reclaim+0x190>
    13e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    13ee:	00 00 
    13f0:	be 60 0e 00 00       	mov    $0xe60,%esi
    13f5:	41 bc 4a 00 00 00    	mov    $0x4a,%r12d
    13fb:	e9 d0 fe ff ff       	jmp    12d0 <_mi_theap_page_reclaim+0x90>
    1400:	4c 89 e2             	mov    %r12,%rdx
    1403:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    1408:	48 c1 e2 05          	shl    $0x5,%rdx
    140c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    1410:	0f 11 84 2a 20 05 00 	movups %xmm0,0x520(%rdx,%rbp,1)
    1417:	00 
    1418:	48 83 80 30 05 00 00 	addq   $0x1,0x530(%rax)
    141f:	01 
    1420:	49 c1 e4 05          	shl    $0x5,%r12
    1424:	4a 8b bc 25 38 05 00 	mov    0x538(%rbp,%r12,1),%rdi
    142b:	00 
    142c:	48 81 ff 00 04 00 00 	cmp    $0x400,%rdi
    1433:	0f 87 4d ff ff ff    	ja     1386 <_mi_theap_page_reclaim+0x146>
    1439:	48 83 c7 07          	add    $0x7,%rdi
    143d:	4c 8d 85 18 01 00 00 	lea    0x118(%rbp),%r8
    1444:	48 c1 ef 03          	shr    $0x3,%rdi
    1448:	48 39 9c fd 18 01 00 	cmp    %rbx,0x118(%rbp,%rdi,8)
    144f:	00 
    1450:	0f 84 30 ff ff ff    	je     1386 <_mi_theap_page_reclaim+0x146>
    1456:	48 83 ff 01          	cmp    $0x1,%rdi
    145a:	0f 86 80 01 00 00    	jbe    15e0 <_mi_theap_page_reclaim+0x3a0>
    1460:	48 83 ff 08          	cmp    $0x8,%rdi
    1464:	0f 87 81 01 00 00    	ja     15eb <_mi_theap_page_reclaim+0x3ab>
    146a:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    146e:	4d 89 cb             	mov    %r9,%r11
    1471:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
    1475:	48 8d 74 35 e0       	lea    -0x20(%rbp,%rsi,1),%rsi
    147a:	4c 8d 95 20 05 00 00 	lea    0x520(%rbp),%r10
    1481:	eb 1b                	jmp    149e <_mi_theap_page_reclaim+0x25e>
    1483:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1488:	48 8d 50 01          	lea    0x1(%rax),%rdx
    148c:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    1490:	49 39 d3             	cmp    %rdx,%r11
    1493:	75 28                	jne    14bd <_mi_theap_page_reclaim+0x27d>
    1495:	49 39 f2             	cmp    %rsi,%r10
    1498:	73 23                	jae    14bd <_mi_theap_page_reclaim+0x27d>
    149a:	48 83 ee 20          	sub    $0x20,%rsi
    149e:	48 8b 46 18          	mov    0x18(%rsi),%rax
    14a2:	48 8d 50 07          	lea    0x7(%rax),%rdx
    14a6:	48 89 d0             	mov    %rdx,%rax
    14a9:	48 c1 e8 03          	shr    $0x3,%rax
    14ad:	48 83 fa 47          	cmp    $0x47,%rdx
    14b1:	0f 87 e1 00 00 00    	ja     1598 <_mi_theap_page_reclaim+0x358>
    14b7:	48 83 f8 01          	cmp    $0x1,%rax
    14bb:	77 cb                	ja     1488 <_mi_theap_page_reclaim+0x248>
    14bd:	48 83 c0 01          	add    $0x1,%rax
    14c1:	48 39 f8             	cmp    %rdi,%rax
    14c4:	48 0f 47 c7          	cmova  %rdi,%rax
    14c8:	48 8d 50 01          	lea    0x1(%rax),%rdx
    14cc:	4c 89 c9             	mov    %r9,%rcx
    14cf:	be 01 00 00 00       	mov    $0x1,%esi
    14d4:	48 29 c1             	sub    %rax,%rcx
    14d7:	49 39 d1             	cmp    %rdx,%r9
    14da:	48 0f 42 ce          	cmovb  %rsi,%rcx
    14de:	48 39 c7             	cmp    %rax,%rdi
    14e1:	74 5d                	je     1540 <_mi_theap_page_reclaim+0x300>
    14e3:	49 39 d1             	cmp    %rdx,%r9
    14e6:	72 58                	jb     1540 <_mi_theap_page_reclaim+0x300>
    14e8:	48 89 ce             	mov    %rcx,%rsi
    14eb:	48 8d 94 c5 18 01 00 	lea    0x118(%rbp,%rax,8),%rdx
    14f2:	00 
    14f3:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    14f8:	48 d1 ee             	shr    $1,%rsi
    14fb:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    14ff:	48 c1 e6 04          	shl    $0x4,%rsi
    1503:	48 8d 3c 16          	lea    (%rsi,%rdx,1),%rdi
    1507:	83 e6 10             	and    $0x10,%esi
    150a:	74 14                	je     1520 <_mi_theap_page_reclaim+0x2e0>
    150c:	0f 11 02             	movups %xmm0,(%rdx)
    150f:	48 83 c2 10          	add    $0x10,%rdx
    1513:	48 39 fa             	cmp    %rdi,%rdx
    1516:	74 18                	je     1530 <_mi_theap_page_reclaim+0x2f0>
    1518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    151f:	00 
    1520:	0f 11 02             	movups %xmm0,(%rdx)
    1523:	48 83 c2 20          	add    $0x20,%rdx
    1527:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
    152b:	48 39 fa             	cmp    %rdi,%rdx
    152e:	75 f0                	jne    1520 <_mi_theap_page_reclaim+0x2e0>
    1530:	f6 c1 01             	test   $0x1,%cl
    1533:	0f 84 4d fe ff ff    	je     1386 <_mi_theap_page_reclaim+0x146>
    1539:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
    153d:	48 01 c8             	add    %rcx,%rax
    1540:	49 89 1c c0          	mov    %rbx,(%r8,%rax,8)
    1544:	48 83 85 b8 00 00 00 	addq   $0x1,0xb8(%rbp)
    154b:	01 
    154c:	5b                   	pop    %rbx
    154d:	5d                   	pop    %rbp
    154e:	41 5c                	pop    %r12
    1550:	c3                   	ret
    1551:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1558:	48 83 c0 07          	add    $0x7,%rax
    155c:	48 89 c2             	mov    %rax,%rdx
    155f:	48 c1 ea 03          	shr    $0x3,%rdx
    1563:	48 83 f8 47          	cmp    $0x47,%rax
    1567:	0f 86 45 fd ff ff    	jbe    12b2 <_mi_theap_page_reclaim+0x72>
    156d:	0f 1f 00             	nopl   (%rax)
    1570:	48 83 ea 01          	sub    $0x1,%rdx
    1574:	48 0f bd c2          	bsr    %rdx,%rax
    1578:	8d 48 fe             	lea    -0x2(%rax),%ecx
    157b:	48 d3 ea             	shr    %cl,%rdx
    157e:	83 e2 03             	and    $0x3,%edx
    1581:	4c 8d 64 82 fd       	lea    -0x3(%rdx,%rax,4),%r12
    1586:	49 8d 74 24 29       	lea    0x29(%r12),%rsi
    158b:	48 c1 e6 05          	shl    $0x5,%rsi
    158f:	e9 3c fd ff ff       	jmp    12d0 <_mi_theap_page_reclaim+0x90>
    1594:	0f 1f 40 00          	nopl   0x0(%rax)
    1598:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    159e:	0f 87 19 ff ff ff    	ja     14bd <_mi_theap_page_reclaim+0x27d>
    15a4:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    15a8:	4c 0f bd e2          	bsr    %rdx,%r12
    15ac:	41 8d 4c 24 fe       	lea    -0x2(%r12),%ecx
    15b1:	48 d3 ea             	shr    %cl,%rdx
    15b4:	83 e2 03             	and    $0x3,%edx
    15b7:	4a 8d 54 a2 fd       	lea    -0x3(%rdx,%r12,4),%rdx
    15bc:	e9 cf fe ff ff       	jmp    1490 <_mi_theap_page_reclaim+0x250>
    15c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    15c8:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
    15cf:	76 9f                	jbe    1570 <_mi_theap_page_reclaim+0x330>
    15d1:	e9 ea fd ff ff       	jmp    13c0 <_mi_theap_page_reclaim+0x180>
    15d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    15dd:	00 00 00 
    15e0:	31 c0                	xor    %eax,%eax
    15e2:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    15e6:	e9 dd fe ff ff       	jmp    14c8 <_mi_theap_page_reclaim+0x288>
    15eb:	48 8d 47 ff          	lea    -0x1(%rdi),%rax
    15ef:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    15f3:	48 0f bd d0          	bsr    %rax,%rdx
    15f7:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    15fa:	48 d3 e8             	shr    %cl,%rax
    15fd:	83 e0 03             	and    $0x3,%eax
    1600:	4c 8d 5c 90 fd       	lea    -0x3(%rax,%rdx,4),%r11
    1605:	e9 6b fe ff ff       	jmp    1475 <_mi_theap_page_reclaim+0x235>
    160a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000001610 <_mi_page_abandon>:
    1610:	55                   	push   %rbp
    1611:	48 89 f5             	mov    %rsi,%rbp
    1614:	31 f6                	xor    %esi,%esi
    1616:	53                   	push   %rbx
    1617:	48 89 fb             	mov    %rdi,%rbx
    161a:	48 83 ec 08          	sub    $0x8,%rsp
    161e:	e8 00 00 00 00       	call   1623 <_mi_page_abandon+0x13>
			161f: R_X86_64_PLT32	_mi_page_free_collect_no_unpurge-0x4
    1623:	8b 43 10             	mov    0x10(%rbx),%eax
    1626:	85 c0                	test   %eax,%eax
    1628:	75 3e                	jne    1668 <_mi_page_abandon+0x58>
    162a:	f0 48 83 23 fd       	lock andq $0xfffffffffffffffd,(%rbx)
    162f:	48 89 de             	mov    %rbx,%rsi
    1632:	48 89 ef             	mov    %rbp,%rdi
    1635:	e8 a6 ef ff ff       	call   5e0 <mi_page_queue_remove>
    163a:	48 8b 73 38          	mov    0x38(%rbx),%rsi
    163e:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    1645:	00 
    1646:	48 8b 03             	mov    (%rbx),%rax
    1649:	48 89 c2             	mov    %rax,%rdx
    164c:	83 e2 03             	and    $0x3,%edx
    164f:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    1654:	75 f3                	jne    1649 <_mi_page_abandon+0x39>
    1656:	48 83 c4 08          	add    $0x8,%rsp
    165a:	48 89 df             	mov    %rbx,%rdi
    165d:	5b                   	pop    %rbx
    165e:	5d                   	pop    %rbp
    165f:	e9 00 00 00 00       	jmp    1664 <_mi_page_abandon+0x54>
			1660: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    1664:	0f 1f 40 00          	nopl   0x0(%rax)
    1668:	48 89 de             	mov    %rbx,%rsi
    166b:	48 89 ef             	mov    %rbp,%rdi
    166e:	e8 6d ef ff ff       	call   5e0 <mi_page_queue_remove>
    1673:	48 8b 73 38          	mov    0x38(%rbx),%rsi
    1677:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    167e:	00 
    167f:	48 8b 03             	mov    (%rbx),%rax
    1682:	48 89 c2             	mov    %rax,%rdx
    1685:	83 e2 03             	and    $0x3,%edx
    1688:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    168d:	75 f3                	jne    1682 <_mi_page_abandon+0x72>
    168f:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    1693:	48 83 c4 08          	add    $0x8,%rsp
    1697:	48 89 df             	mov    %rbx,%rdi
    169a:	5b                   	pop    %rbx
    169b:	5d                   	pop    %rbp
    169c:	e9 00 00 00 00       	jmp    16a1 <_mi_page_abandon+0x91>
			169d: R_X86_64_PLT32	_mi_arenas_page_abandon-0x4
    16a1:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    16a8:	00 00 00 00 
    16ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000016b0 <mi_page_fresh_alloc>:
    16b0:	41 57                	push   %r15
    16b2:	41 56                	push   %r14
    16b4:	49 89 ce             	mov    %rcx,%r14
    16b7:	41 55                	push   %r13
    16b9:	49 89 f5             	mov    %rsi,%r13
    16bc:	41 54                	push   %r12
    16be:	49 89 d4             	mov    %rdx,%r12
    16c1:	55                   	push   %rbp
    16c2:	48 89 fd             	mov    %rdi,%rbp
    16c5:	53                   	push   %rbx
    16c6:	48 83 ec 28          	sub    $0x28,%rsp
    16ca:	48 85 c9             	test   %rcx,%rcx
    16cd:	0f 85 6d 02 00 00    	jne    1940 <mi_page_fresh_alloc+0x290>
    16d3:	48 85 f6             	test   %rsi,%rsi
    16d6:	0f 84 64 02 00 00    	je     1940 <mi_page_fresh_alloc+0x290>
    16dc:	48 8d 82 55 ad fe ff 	lea    -0x152ab(%rdx),%rax
    16e3:	48 3d 55 ad 06 00    	cmp    $0x6ad55,%rax
    16e9:	0f 87 51 02 00 00    	ja     1940 <mi_page_fresh_alloc+0x290>
    16ef:	48 8b 07             	mov    (%rdi),%rax
    16f2:	8b 80 f4 01 00 00    	mov    0x1f4(%rax),%eax
    16f8:	85 c0                	test   %eax,%eax
    16fa:	0f 84 40 02 00 00    	je     1940 <mi_page_fresh_alloc+0x290>
    1700:	48 8d 42 07          	lea    0x7(%rdx),%rax
    1704:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    1708:	48 c1 e8 03          	shr    $0x3,%rax
    170c:	48 83 e8 01          	sub    $0x1,%rax
    1710:	48 0f bd d0          	bsr    %rax,%rdx
    1714:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    1717:	48 d3 e8             	shr    %cl,%rax
    171a:	83 e0 03             	and    $0x3,%eax
    171d:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
    1722:	48 89 04 24          	mov    %rax,(%rsp)
    1726:	48 83 c0 0d          	add    $0xd,%rax
    172a:	48 8b 04 c6          	mov    (%rsi,%rax,8),%rax
    172e:	48 85 c0             	test   %rax,%rax
    1731:	0f 85 09 02 00 00    	jne    1940 <mi_page_fresh_alloc+0x290>
    1737:	31 d2                	xor    %edx,%edx
    1739:	4c 89 e6             	mov    %r12,%rsi
    173c:	e8 00 00 00 00       	call   1741 <mi_page_fresh_alloc+0x91>
			173d: R_X86_64_PLT32	_mi_large_span_peek_slices-0x4
    1741:	4f 8d 04 24          	lea    (%r12,%r12,1),%r8
    1745:	4c 89 ee             	mov    %r13,%rsi
    1748:	48 89 ef             	mov    %rbp,%rdi
    174b:	48 c1 e0 10          	shl    $0x10,%rax
    174f:	4c 8d 4c 24 18       	lea    0x18(%rsp),%r9
    1754:	b9 3c 00 00 00       	mov    $0x3c,%ecx
    1759:	ba 32 00 00 00       	mov    $0x32,%edx
    175e:	4c 39 c0             	cmp    %r8,%rax
    1761:	4c 0f 43 c0          	cmovae %rax,%r8
    1765:	e8 00 00 00 00       	call   176a <mi_page_fresh_alloc+0xba>
			1766: R_X86_64_PLT32	_mi_page_repurpose_find-0x4
    176a:	49 89 c7             	mov    %rax,%r15
    176d:	48 85 c0             	test   %rax,%rax
    1770:	0f 84 ca 01 00 00    	je     1940 <mi_page_fresh_alloc+0x290>
    1776:	31 d2                	xor    %edx,%edx
    1778:	4c 89 e6             	mov    %r12,%rsi
    177b:	48 89 ef             	mov    %rbp,%rdi
    177e:	e8 00 00 00 00       	call   1783 <mi_page_fresh_alloc+0xd3>
			177f: R_X86_64_PLT32	_mi_large_span_slices-0x4
    1783:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    1787:	49 8b 1f             	mov    (%r15),%rbx
    178a:	83 ae f4 01 00 00 01 	subl   $0x1,0x1f4(%rsi)
    1791:	48 89 df             	mov    %rbx,%rdi
    1794:	e8 00 00 00 00       	call   1799 <mi_page_fresh_alloc+0xe9>
			1795: R_X86_64_PLT32	_mi_page_unpublish_retired-0x4
    1799:	66 0f ef c0          	pxor   %xmm0,%xmm0
    179d:	48 8b 43 28          	mov    0x28(%rbx),%rax
    17a1:	49 c7 47 10 00 00 00 	movq   $0x0,0x10(%r15)
    17a8:	00 
    17a9:	41 0f 11 07          	movups %xmm0,(%r15)
    17ad:	48 83 ad b8 00 00 00 	subq   $0x1,0xb8(%rbp)
    17b4:	01 
    17b5:	66 83 7b 36 01       	cmpw   $0x1,0x36(%rbx)
    17ba:	0f 84 38 02 00 00    	je     19f8 <mi_page_fresh_alloc+0x348>
    17c0:	48 8d 50 07          	lea    0x7(%rax),%rdx
    17c4:	48 89 d0             	mov    %rdx,%rax
    17c7:	48 c1 e8 03          	shr    $0x3,%rax
    17cb:	48 83 fa 47          	cmp    $0x47,%rdx
    17cf:	0f 87 eb 02 00 00    	ja     1ac0 <mi_page_fresh_alloc+0x410>
    17d5:	bf 40 18 00 00       	mov    $0x1840,%edi
    17da:	48 83 f8 01          	cmp    $0x1,%rax
    17de:	76 14                	jbe    17f4 <mi_page_fresh_alloc+0x144>
    17e0:	48 83 c0 01          	add    $0x1,%rax
    17e4:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    17e8:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    17ec:	48 8d 3c c5 28 18 00 	lea    0x1828(,%rax,8),%rdi
    17f3:	00 
    17f4:	48 01 ef             	add    %rbp,%rdi
    17f7:	be 01 00 00 00       	mov    $0x1,%esi
    17fc:	e8 00 00 00 00       	call   1801 <mi_page_fresh_alloc+0x151>
			17fd: R_X86_64_PLT32	__mi_stat_decrease-0x4
    1801:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    1806:	31 d2                	xor    %edx,%edx
    1808:	8b 73 68             	mov    0x68(%rbx),%esi
    180b:	4c 89 e7             	mov    %r12,%rdi
    180e:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
    1815:	00 
    1816:	49 f7 f4             	div    %r12
    1819:	8b 53 30             	mov    0x30(%rbx),%edx
    181c:	c6 43 6e 00          	movb   $0x0,0x6e(%rbx)
    1820:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    1827:	00 00 00 00 
    182b:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%rbx)
    1832:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    1839:	00 
    183a:	48 c1 e2 04          	shl    $0x4,%rdx
    183e:	48 01 da             	add    %rbx,%rdx
    1841:	48 89 d1             	mov    %rdx,%rcx
    1844:	66 31 c9             	xor    %cx,%cx
    1847:	83 fe 06             	cmp    $0x6,%esi
    184a:	48 0f 45 cb          	cmovne %rbx,%rcx
    184e:	48 29 ca             	sub    %rcx,%rdx
    1851:	0f b7 4b 36          	movzwl 0x36(%rbx),%ecx
    1855:	48 0f af 4b 28       	imul   0x28(%rbx),%rcx
    185a:	4c 89 63 28          	mov    %r12,0x28(%rbx)
    185e:	48 8d 8c 0a ff ff 00 	lea    0xffff(%rdx,%rcx,1),%rcx
    1865:	00 
    1866:	48 c1 e9 10          	shr    $0x10,%rcx
    186a:	48 0f af f8          	imul   %rax,%rdi
    186e:	66 89 43 36          	mov    %ax,0x36(%rbx)
    1872:	48 8d 94 3a ff ff 00 	lea    0xffff(%rdx,%rdi,1),%rdx
    1879:	00 
    187a:	48 c1 ea 10          	shr    $0x10,%rdx
    187e:	66 83 f8 01          	cmp    $0x1,%ax
    1882:	0f 84 18 02 00 00    	je     1aa0 <mi_page_fresh_alloc+0x3f0>
    1888:	48 8b 04 24          	mov    (%rsp),%rax
    188c:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    1890:	48 8d 3c c5 28 18 00 	lea    0x1828(,%rax,8),%rdi
    1897:	00 
    1898:	48 01 ef             	add    %rbp,%rdi
    189b:	be 01 00 00 00       	mov    $0x1,%esi
    18a0:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    18a5:	48 89 0c 24          	mov    %rcx,(%rsp)
    18a9:	e8 00 00 00 00       	call   18ae <mi_page_fresh_alloc+0x1fe>
			18aa: R_X86_64_PLT32	__mi_stat_increase-0x4
    18ae:	48 8b 0c 24          	mov    (%rsp),%rcx
    18b2:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    18b7:	48 39 ca             	cmp    %rcx,%rdx
    18ba:	73 64                	jae    1920 <mi_page_fresh_alloc+0x270>
    18bc:	48 29 d1             	sub    %rdx,%rcx
    18bf:	48 89 df             	mov    %rbx,%rdi
    18c2:	48 c1 e1 10          	shl    $0x10,%rcx
    18c6:	83 7b 68 06          	cmpl   $0x6,0x68(%rbx)
    18ca:	48 89 ce             	mov    %rcx,%rsi
    18cd:	75 0d                	jne    18dc <mi_page_fresh_alloc+0x22c>
    18cf:	8b 7b 30             	mov    0x30(%rbx),%edi
    18d2:	48 c1 e7 04          	shl    $0x4,%rdi
    18d6:	48 01 df             	add    %rbx,%rdi
    18d9:	66 31 ff             	xor    %di,%di
    18dc:	48 c1 e2 10          	shl    $0x10,%rdx
    18e0:	48 01 d7             	add    %rdx,%rdi
    18e3:	e8 00 00 00 00       	call   18e8 <mi_page_fresh_alloc+0x238>
			18e4: R_X86_64_PLT32	_mi_page_map_unregister_range-0x4
    18e8:	4c 89 ee             	mov    %r13,%rsi
    18eb:	48 89 da             	mov    %rbx,%rdx
    18ee:	48 89 ef             	mov    %rbp,%rdi
    18f1:	e8 9a ea ff ff       	call   390 <mi_page_queue_push>
    18f6:	48 89 df             	mov    %rbx,%rdi
    18f9:	e8 00 00 00 00       	call   18fe <mi_page_fresh_alloc+0x24e>
			18fa: R_X86_64_PLT32	_mi_page_purged_reset-0x4
    18fe:	48 89 de             	mov    %rbx,%rsi
    1901:	48 89 ef             	mov    %rbp,%rdi
    1904:	e8 47 e7 ff ff       	call   50 <mi_page_extend_free>
    1909:	84 c0                	test   %al,%al
    190b:	75 6d                	jne    197a <mi_page_fresh_alloc+0x2ca>
    190d:	48 89 de             	mov    %rbx,%rsi
    1910:	4c 89 ef             	mov    %r13,%rdi
    1913:	e8 c8 ec ff ff       	call   5e0 <mi_page_queue_remove>
    1918:	eb 17                	jmp    1931 <mi_page_fresh_alloc+0x281>
    191a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1920:	48 39 d1             	cmp    %rdx,%rcx
    1923:	73 c3                	jae    18e8 <mi_page_fresh_alloc+0x238>
    1925:	48 89 df             	mov    %rbx,%rdi
    1928:	e8 00 00 00 00       	call   192d <mi_page_fresh_alloc+0x27d>
			1929: R_X86_64_PLT32	_mi_page_map_register-0x4
    192d:	84 c0                	test   %al,%al
    192f:	75 b7                	jne    18e8 <mi_page_fresh_alloc+0x238>
    1931:	48 89 ee             	mov    %rbp,%rsi
    1934:	48 89 df             	mov    %rbx,%rdi
    1937:	e8 00 00 00 00       	call   193c <mi_page_fresh_alloc+0x28c>
			1938: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    193c:	0f 1f 40 00          	nopl   0x0(%rax)
    1940:	4c 89 f2             	mov    %r14,%rdx
    1943:	4c 89 e6             	mov    %r12,%rsi
    1946:	48 89 ef             	mov    %rbp,%rdi
    1949:	e8 00 00 00 00       	call   194e <mi_page_fresh_alloc+0x29e>
			194a: R_X86_64_PLT32	_mi_arenas_page_alloc-0x4
    194e:	48 89 c3             	mov    %rax,%rbx
    1951:	48 85 c0             	test   %rax,%rax
    1954:	0f 84 93 00 00 00    	je     19ed <mi_page_fresh_alloc+0x33d>
    195a:	48 8b 00             	mov    (%rax),%rax
    195d:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
    1961:	48 83 f8 04          	cmp    $0x4,%rax
    1965:	76 29                	jbe    1990 <mi_page_fresh_alloc+0x2e0>
    1967:	4d 85 ed             	test   %r13,%r13
    196a:	74 0e                	je     197a <mi_page_fresh_alloc+0x2ca>
    196c:	48 89 da             	mov    %rbx,%rdx
    196f:	4c 89 ee             	mov    %r13,%rsi
    1972:	48 89 ef             	mov    %rbp,%rdi
    1975:	e8 16 ea ff ff       	call   390 <mi_page_queue_push>
    197a:	48 83 c4 28          	add    $0x28,%rsp
    197e:	48 89 d8             	mov    %rbx,%rax
    1981:	5b                   	pop    %rbx
    1982:	5d                   	pop    %rbp
    1983:	41 5c                	pop    %r12
    1985:	41 5d                	pop    %r13
    1987:	41 5e                	pop    %r14
    1989:	41 5f                	pop    %r15
    198b:	c3                   	ret
    198c:	0f 1f 40 00          	nopl   0x0(%rax)
    1990:	48 89 de             	mov    %rbx,%rsi
    1993:	48 89 ef             	mov    %rbp,%rdi
    1996:	e8 00 00 00 00       	call   199b <mi_page_fresh_alloc+0x2eb>
			1997: R_X86_64_PLT32	_mi_theap_page_reclaim-0x4
    199b:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    19a0:	75 d8                	jne    197a <mi_page_fresh_alloc+0x2ca>
    19a2:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
    19a6:	66 39 43 14          	cmp    %ax,0x14(%rbx)
    19aa:	0f 82 b0 00 00 00    	jb     1a60 <mi_page_fresh_alloc+0x3b0>
    19b0:	48 83 7b 70 00       	cmpq   $0x0,0x70(%rbx)
    19b5:	0f 85 c5 00 00 00    	jne    1a80 <mi_page_fresh_alloc+0x3d0>
    19bb:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
    19c0:	0f 85 ba 00 00 00    	jne    1a80 <mi_page_fresh_alloc+0x3d0>
    19c6:	48 83 bb 80 00 00 00 	cmpq   $0x0,0x80(%rbx)
    19cd:	00 
    19ce:	0f 85 ac 00 00 00    	jne    1a80 <mi_page_fresh_alloc+0x3d0>
    19d4:	48 83 bb 88 00 00 00 	cmpq   $0x0,0x88(%rbx)
    19db:	00 
    19dc:	0f 85 9e 00 00 00    	jne    1a80 <mi_page_fresh_alloc+0x3d0>
    19e2:	4c 89 ee             	mov    %r13,%rsi
    19e5:	48 89 df             	mov    %rbx,%rdi
    19e8:	e8 00 00 00 00       	call   19ed <mi_page_fresh_alloc+0x33d>
			19e9: R_X86_64_PLT32	_mi_page_abandon-0x4
    19ed:	31 db                	xor    %ebx,%ebx
    19ef:	eb 89                	jmp    197a <mi_page_fresh_alloc+0x2ca>
    19f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    19f8:	bf 00 1f 00 00       	mov    $0x1f00,%edi
    19fd:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
    1a03:	0f 87 eb fd ff ff    	ja     17f4 <mi_page_fresh_alloc+0x144>
    1a09:	8b 4b 68             	mov    0x68(%rbx),%ecx
    1a0c:	8d 51 fd             	lea    -0x3(%rcx),%edx
    1a0f:	83 fa 02             	cmp    $0x2,%edx
    1a12:	77 0a                	ja     1a1e <mi_page_fresh_alloc+0x36e>
    1a14:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
    1a18:	0f 82 d6 fd ff ff    	jb     17f4 <mi_page_fresh_alloc+0x144>
    1a1e:	48 8d 50 07          	lea    0x7(%rax),%rdx
    1a22:	48 89 d0             	mov    %rdx,%rax
    1a25:	48 c1 e8 03          	shr    $0x3,%rax
    1a29:	48 83 fa 47          	cmp    $0x47,%rdx
    1a2d:	0f 86 a2 fd ff ff    	jbe    17d5 <mi_page_fresh_alloc+0x125>
    1a33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1a38:	48 83 e8 01          	sub    $0x1,%rax
    1a3c:	48 0f bd d0          	bsr    %rax,%rdx
    1a40:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    1a43:	48 d3 e8             	shr    %cl,%rax
    1a46:	83 e0 03             	and    $0x3,%eax
    1a49:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
    1a4e:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    1a52:	48 8d 3c c5 28 18 00 	lea    0x1828(,%rax,8),%rdi
    1a59:	00 
    1a5a:	e9 95 fd ff ff       	jmp    17f4 <mi_page_fresh_alloc+0x144>
    1a5f:	90                   	nop
    1a60:	48 89 de             	mov    %rbx,%rsi
    1a63:	48 89 ef             	mov    %rbp,%rdi
    1a66:	e8 e5 e5 ff ff       	call   50 <mi_page_extend_free>
    1a6b:	84 c0                	test   %al,%al
    1a6d:	0f 85 07 ff ff ff    	jne    197a <mi_page_fresh_alloc+0x2ca>
    1a73:	e9 6a ff ff ff       	jmp    19e2 <mi_page_fresh_alloc+0x332>
    1a78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    1a7f:	00 
    1a80:	48 89 df             	mov    %rbx,%rdi
    1a83:	e8 00 00 00 00       	call   1a88 <mi_page_fresh_alloc+0x3d8>
			1a84: R_X86_64_PLT32	_mi_page_unpurge_run-0x4
    1a88:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    1a8d:	0f 85 e7 fe ff ff    	jne    197a <mi_page_fresh_alloc+0x2ca>
    1a93:	e9 4a ff ff ff       	jmp    19e2 <mi_page_fresh_alloc+0x332>
    1a98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    1a9f:	00 
    1aa0:	83 ee 03             	sub    $0x3,%esi
    1aa3:	83 fe 02             	cmp    $0x2,%esi
    1aa6:	0f 87 dc fd ff ff    	ja     1888 <mi_page_fresh_alloc+0x1d8>
    1aac:	bf 00 1f 00 00       	mov    $0x1f00,%edi
    1ab1:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
    1ab5:	0f 82 dd fd ff ff    	jb     1898 <mi_page_fresh_alloc+0x1e8>
    1abb:	e9 c8 fd ff ff       	jmp    1888 <mi_page_fresh_alloc+0x1d8>
    1ac0:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    1ac6:	0f 86 6c ff ff ff    	jbe    1a38 <mi_page_fresh_alloc+0x388>
    1acc:	bf 00 1f 00 00       	mov    $0x1f00,%edi
    1ad1:	e9 1e fd ff ff       	jmp    17f4 <mi_page_fresh_alloc+0x144>
    1ad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    1add:	00 00 00 

0000000000001ae0 <_mi_page_free_or_reserve>:
    1ae0:	41 57                	push   %r15
    1ae2:	41 56                	push   %r14
    1ae4:	41 55                	push   %r13
    1ae6:	49 89 fd             	mov    %rdi,%r13
    1ae9:	41 54                	push   %r12
    1aeb:	55                   	push   %rbp
    1aec:	48 89 f5             	mov    %rsi,%rbp
    1aef:	53                   	push   %rbx
    1af0:	48 89 fb             	mov    %rdi,%rbx
    1af3:	48 83 ec 08          	sub    $0x8,%rsp
    1af7:	f0 48 83 27 fd       	lock andq $0xfffffffffffffffd,(%rdi)
    1afc:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    1b00:	4c 8b 67 38          	mov    0x38(%rdi),%r12
    1b04:	48 85 d2             	test   %rdx,%rdx
    1b07:	74 08                	je     1b11 <_mi_page_free_or_reserve+0x31>
    1b09:	48 8b 47 48          	mov    0x48(%rdi),%rax
    1b0d:	48 89 42 48          	mov    %rax,0x48(%rdx)
    1b11:	48 8b 43 48          	mov    0x48(%rbx),%rax
    1b15:	48 85 c0             	test   %rax,%rax
    1b18:	74 04                	je     1b1e <_mi_page_free_or_reserve+0x3e>
    1b1a:	48 89 50 50          	mov    %rdx,0x50(%rax)
    1b1e:	48 3b 5d 08          	cmp    0x8(%rbp),%rbx
    1b22:	0f 84 a8 00 00 00    	je     1bd0 <_mi_page_free_or_reserve+0xf0>
    1b28:	48 3b 5d 00          	cmp    0x0(%rbp),%rbx
    1b2c:	0f 84 b0 00 00 00    	je     1be2 <_mi_page_free_or_reserve+0x102>
    1b32:	49 83 ac 24 b8 00 00 	subq   $0x1,0xb8(%r12)
    1b39:	00 01 
    1b3b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    1b3f:	48 83 6d 10 01       	subq   $0x1,0x10(%rbp)
    1b44:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
    1b48:	f0 49 0f ba 75 00 00 	lock btrq $0x0,0x0(%r13)
    1b4f:	73 57                	jae    1ba8 <_mi_page_free_or_reserve+0xc8>
    1b51:	48 8b 6b 38          	mov    0x38(%rbx),%rbp
    1b55:	48 85 ed             	test   %rbp,%rbp
    1b58:	74 10                	je     1b6a <_mi_page_free_or_reserve+0x8a>
    1b5a:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
    1b5e:	48 0f af 43 28       	imul   0x28(%rbx),%rax
    1b63:	48 29 85 d0 00 00 00 	sub    %rax,0xd0(%rbp)
    1b6a:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    1b71:	00 
    1b72:	48 8b 03             	mov    (%rbx),%rax
    1b75:	48 89 c2             	mov    %rax,%rdx
    1b78:	83 e2 03             	and    $0x3,%edx
    1b7b:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    1b80:	75 f3                	jne    1b75 <_mi_page_free_or_reserve+0x95>
    1b82:	c6 43 16 00          	movb   $0x0,0x16(%rbx)
    1b86:	48 89 ee             	mov    %rbp,%rsi
    1b89:	48 89 df             	mov    %rbx,%rdi
    1b8c:	e8 00 00 00 00       	call   1b91 <_mi_page_free_or_reserve+0xb1>
			1b8d: R_X86_64_PLT32	_mi_arenas_page_reserve-0x4
    1b91:	84 c0                	test   %al,%al
    1b93:	74 1b                	je     1bb0 <_mi_page_free_or_reserve+0xd0>
    1b95:	48 83 c4 08          	add    $0x8,%rsp
    1b99:	5b                   	pop    %rbx
    1b9a:	5d                   	pop    %rbp
    1b9b:	41 5c                	pop    %r12
    1b9d:	41 5d                	pop    %r13
    1b9f:	41 5e                	pop    %r14
    1ba1:	41 5f                	pop    %r15
    1ba3:	c3                   	ret
    1ba4:	0f 1f 40 00          	nopl   0x0(%rax)
    1ba8:	48 8b 6b 38          	mov    0x38(%rbx),%rbp
    1bac:	eb bc                	jmp    1b6a <_mi_page_free_or_reserve+0x8a>
    1bae:	66 90                	xchg   %ax,%ax
    1bb0:	48 83 c4 08          	add    $0x8,%rsp
    1bb4:	48 89 ee             	mov    %rbp,%rsi
    1bb7:	48 89 df             	mov    %rbx,%rdi
    1bba:	5b                   	pop    %rbx
    1bbb:	5d                   	pop    %rbp
    1bbc:	41 5c                	pop    %r12
    1bbe:	41 5d                	pop    %r13
    1bc0:	41 5e                	pop    %r14
    1bc2:	41 5f                	pop    %r15
    1bc4:	e9 00 00 00 00       	jmp    1bc9 <_mi_page_free_or_reserve+0xe9>
			1bc5: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    1bc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1bd0:	48 8b 53 50          	mov    0x50(%rbx),%rdx
    1bd4:	48 89 55 08          	mov    %rdx,0x8(%rbp)
    1bd8:	48 3b 5d 00          	cmp    0x0(%rbp),%rbx
    1bdc:	0f 85 50 ff ff ff    	jne    1b32 <_mi_page_free_or_reserve+0x52>
    1be2:	4c 8b 75 18          	mov    0x18(%rbp),%r14
    1be6:	48 89 45 00          	mov    %rax,0x0(%rbp)
    1bea:	49 81 fe 00 04 00 00 	cmp    $0x400,%r14
    1bf1:	0f 87 3b ff ff ff    	ja     1b32 <_mi_page_free_or_reserve+0x52>
    1bf7:	48 85 c0             	test   %rax,%rax
    1bfa:	0f 84 58 01 00 00    	je     1d58 <_mi_page_free_or_reserve+0x278>
    1c00:	49 8d 7e 07          	lea    0x7(%r14),%rdi
    1c04:	4d 8d 84 24 18 01 00 	lea    0x118(%r12),%r8
    1c0b:	00 
    1c0c:	48 c1 ef 03          	shr    $0x3,%rdi
    1c10:	49 39 84 fc 18 01 00 	cmp    %rax,0x118(%r12,%rdi,8)
    1c17:	00 
    1c18:	0f 84 14 ff ff ff    	je     1b32 <_mi_page_free_or_reserve+0x52>
    1c1e:	48 83 ff 01          	cmp    $0x1,%rdi
    1c22:	0f 86 20 01 00 00    	jbe    1d48 <_mi_page_free_or_reserve+0x268>
    1c28:	48 83 ff 08          	cmp    $0x8,%rdi
    1c2c:	0f 87 30 01 00 00    	ja     1d62 <_mi_page_free_or_reserve+0x282>
    1c32:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    1c36:	4d 89 cb             	mov    %r9,%r11
    1c39:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
    1c3d:	48 8d 75 e0          	lea    -0x20(%rbp),%rsi
    1c41:	4d 8d 94 24 20 05 00 	lea    0x520(%r12),%r10
    1c48:	00 
    1c49:	eb 1b                	jmp    1c66 <_mi_page_free_or_reserve+0x186>
    1c4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1c50:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
    1c54:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
    1c58:	49 39 cb             	cmp    %rcx,%r11
    1c5b:	75 28                	jne    1c85 <_mi_page_free_or_reserve+0x1a5>
    1c5d:	49 39 f2             	cmp    %rsi,%r10
    1c60:	73 23                	jae    1c85 <_mi_page_free_or_reserve+0x1a5>
    1c62:	48 83 ee 20          	sub    $0x20,%rsi
    1c66:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
    1c6a:	48 83 c1 07          	add    $0x7,%rcx
    1c6e:	48 89 ca             	mov    %rcx,%rdx
    1c71:	48 c1 ea 03          	shr    $0x3,%rdx
    1c75:	48 83 f9 47          	cmp    $0x47,%rcx
    1c79:	0f 87 99 00 00 00    	ja     1d18 <_mi_page_free_or_reserve+0x238>
    1c7f:	48 83 fa 01          	cmp    $0x1,%rdx
    1c83:	77 cb                	ja     1c50 <_mi_page_free_or_reserve+0x170>
    1c85:	48 83 c2 01          	add    $0x1,%rdx
    1c89:	48 39 fa             	cmp    %rdi,%rdx
    1c8c:	48 0f 47 d7          	cmova  %rdi,%rdx
    1c90:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
    1c94:	4c 89 ce             	mov    %r9,%rsi
    1c97:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    1c9d:	48 29 d6             	sub    %rdx,%rsi
    1ca0:	49 39 c9             	cmp    %rcx,%r9
    1ca3:	49 0f 42 f2          	cmovb  %r10,%rsi
    1ca7:	48 39 d7             	cmp    %rdx,%rdi
    1caa:	74 5d                	je     1d09 <_mi_page_free_or_reserve+0x229>
    1cac:	49 39 c9             	cmp    %rcx,%r9
    1caf:	72 58                	jb     1d09 <_mi_page_free_or_reserve+0x229>
    1cb1:	48 89 f7             	mov    %rsi,%rdi
    1cb4:	49 8d 8c d4 18 01 00 	lea    0x118(%r12,%rdx,8),%rcx
    1cbb:	00 
    1cbc:	66 48 0f 6e c0       	movq   %rax,%xmm0
    1cc1:	48 d1 ef             	shr    $1,%rdi
    1cc4:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    1cc8:	48 c1 e7 04          	shl    $0x4,%rdi
    1ccc:	4c 8d 0c 0f          	lea    (%rdi,%rcx,1),%r9
    1cd0:	83 e7 10             	and    $0x10,%edi
    1cd3:	74 13                	je     1ce8 <_mi_page_free_or_reserve+0x208>
    1cd5:	0f 11 01             	movups %xmm0,(%rcx)
    1cd8:	48 83 c1 10          	add    $0x10,%rcx
    1cdc:	4c 39 c9             	cmp    %r9,%rcx
    1cdf:	74 17                	je     1cf8 <_mi_page_free_or_reserve+0x218>
    1ce1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    1ce8:	0f 11 01             	movups %xmm0,(%rcx)
    1ceb:	48 83 c1 20          	add    $0x20,%rcx
    1cef:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
    1cf3:	4c 39 c9             	cmp    %r9,%rcx
    1cf6:	75 f0                	jne    1ce8 <_mi_page_free_or_reserve+0x208>
    1cf8:	40 f6 c6 01          	test   $0x1,%sil
    1cfc:	0f 84 30 fe ff ff    	je     1b32 <_mi_page_free_or_reserve+0x52>
    1d02:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
    1d06:	48 01 f2             	add    %rsi,%rdx
    1d09:	49 89 04 d0          	mov    %rax,(%r8,%rdx,8)
    1d0d:	e9 20 fe ff ff       	jmp    1b32 <_mi_page_free_or_reserve+0x52>
    1d12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1d18:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
    1d1f:	0f 87 60 ff ff ff    	ja     1c85 <_mi_page_free_or_reserve+0x1a5>
    1d25:	4c 8d 72 ff          	lea    -0x1(%rdx),%r14
    1d29:	4d 0f bd fe          	bsr    %r14,%r15
    1d2d:	41 8d 4f fe          	lea    -0x2(%r15),%ecx
    1d31:	49 d3 ee             	shr    %cl,%r14
    1d34:	41 83 e6 03          	and    $0x3,%r14d
    1d38:	4b 8d 4c be fd       	lea    -0x3(%r14,%r15,4),%rcx
    1d3d:	e9 16 ff ff ff       	jmp    1c58 <_mi_page_free_or_reserve+0x178>
    1d42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    1d48:	31 d2                	xor    %edx,%edx
    1d4a:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    1d4e:	e9 3d ff ff ff       	jmp    1c90 <_mi_page_free_or_reserve+0x1b0>
    1d53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1d58:	e8 00 00 00 00       	call   1d5d <_mi_page_free_or_reserve+0x27d>
			1d59: R_X86_64_PLT32	_mi_page_empty_get-0x4
    1d5d:	e9 9e fe ff ff       	jmp    1c00 <_mi_page_free_or_reserve+0x120>
    1d62:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    1d66:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
    1d6a:	48 0f bd f2          	bsr    %rdx,%rsi
    1d6e:	8d 4e fe             	lea    -0x2(%rsi),%ecx
    1d71:	48 d3 ea             	shr    %cl,%rdx
    1d74:	83 e2 03             	and    $0x3,%edx
    1d77:	4c 8d 5c b2 fd       	lea    -0x3(%rdx,%rsi,4),%r11
    1d7c:	e9 bc fe ff ff       	jmp    1c3d <_mi_page_free_or_reserve+0x15d>
    1d81:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    1d88:	00 00 00 00 
    1d8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000001d90 <_mi_page_unfull>:
    1d90:	48 8b 07             	mov    (%rdi),%rax
    1d93:	48 89 fa             	mov    %rdi,%rdx
    1d96:	48 89 fe             	mov    %rdi,%rsi
    1d99:	a8 01                	test   $0x1,%al
    1d9b:	75 03                	jne    1da0 <_mi_page_unfull+0x10>
    1d9d:	c3                   	ret
    1d9e:	66 90                	xchg   %ax,%ax
    1da0:	4c 8b 4f 38          	mov    0x38(%rdi),%r9
    1da4:	4d 8d 81 60 0e 00 00 	lea    0xe60(%r9),%r8
    1dab:	f0 48 0f ba 37 00    	lock btrq $0x0,(%rdi)
    1db1:	73 19                	jae    1dcc <_mi_page_unfull+0x3c>
    1db3:	48 8b 47 38          	mov    0x38(%rdi),%rax
    1db7:	48 85 c0             	test   %rax,%rax
    1dba:	74 10                	je     1dcc <_mi_page_unfull+0x3c>
    1dbc:	0f b7 4f 36          	movzwl 0x36(%rdi),%ecx
    1dc0:	48 0f af 4f 28       	imul   0x28(%rdi),%rcx
    1dc5:	48 29 88 d0 00 00 00 	sub    %rcx,0xd0(%rax)
    1dcc:	48 8b 02             	mov    (%rdx),%rax
    1dcf:	4c 89 c7             	mov    %r8,%rdi
    1dd2:	a8 01                	test   $0x1,%al
    1dd4:	75 40                	jne    1e16 <_mi_page_unfull+0x86>
    1dd6:	66 83 7a 36 01       	cmpw   $0x1,0x36(%rdx)
    1ddb:	48 8b 42 28          	mov    0x28(%rdx),%rax
    1ddf:	74 5f                	je     1e40 <_mi_page_unfull+0xb0>
    1de1:	48 8d 48 07          	lea    0x7(%rax),%rcx
    1de5:	48 89 c8             	mov    %rcx,%rax
    1de8:	48 c1 e8 03          	shr    $0x3,%rax
    1dec:	48 83 f9 47          	cmp    $0x47,%rcx
    1df0:	0f 87 ba 00 00 00    	ja     1eb0 <_mi_page_unfull+0x120>
    1df6:	49 8d b9 40 05 00 00 	lea    0x540(%r9),%rdi
    1dfd:	48 83 f8 01          	cmp    $0x1,%rax
    1e01:	76 13                	jbe    1e16 <_mi_page_unfull+0x86>
    1e03:	48 8d 78 01          	lea    0x1(%rax),%rdi
    1e07:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
    1e0b:	48 83 c7 29          	add    $0x29,%rdi
    1e0f:	48 c1 e7 05          	shl    $0x5,%rdi
    1e13:	4c 01 cf             	add    %r9,%rdi
    1e16:	f0 48 0f ba 2e 00    	lock btsq $0x0,(%rsi)
    1e1c:	72 19                	jb     1e37 <_mi_page_unfull+0xa7>
    1e1e:	48 8b 42 38          	mov    0x38(%rdx),%rax
    1e22:	48 85 c0             	test   %rax,%rax
    1e25:	74 10                	je     1e37 <_mi_page_unfull+0xa7>
    1e27:	0f b7 4a 36          	movzwl 0x36(%rdx),%ecx
    1e2b:	48 0f af 4a 28       	imul   0x28(%rdx),%rcx
    1e30:	48 01 88 d0 00 00 00 	add    %rcx,0xd0(%rax)
    1e37:	4c 89 c6             	mov    %r8,%rsi
    1e3a:	e9 d1 e9 ff ff       	jmp    810 <mi_page_queue_enqueue_from_ex.constprop.0>
    1e3f:	90                   	nop
    1e40:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
    1e46:	77 58                	ja     1ea0 <_mi_page_unfull+0x110>
    1e48:	8b 4a 68             	mov    0x68(%rdx),%ecx
    1e4b:	83 e9 03             	sub    $0x3,%ecx
    1e4e:	83 f9 02             	cmp    $0x2,%ecx
    1e51:	76 3d                	jbe    1e90 <_mi_page_unfull+0x100>
    1e53:	48 8d 48 07          	lea    0x7(%rax),%rcx
    1e57:	48 89 c8             	mov    %rcx,%rax
    1e5a:	48 c1 e8 03          	shr    $0x3,%rax
    1e5e:	48 83 f9 47          	cmp    $0x47,%rcx
    1e62:	76 92                	jbe    1df6 <_mi_page_unfull+0x66>
    1e64:	0f 1f 40 00          	nopl   0x0(%rax)
    1e68:	48 83 e8 01          	sub    $0x1,%rax
    1e6c:	48 0f bd f8          	bsr    %rax,%rdi
    1e70:	8d 4f fe             	lea    -0x2(%rdi),%ecx
    1e73:	48 d3 e8             	shr    %cl,%rax
    1e76:	83 e0 03             	and    $0x3,%eax
    1e79:	48 8d 7c b8 26       	lea    0x26(%rax,%rdi,4),%rdi
    1e7e:	48 c1 e7 05          	shl    $0x5,%rdi
    1e82:	4c 01 cf             	add    %r9,%rdi
    1e85:	eb 8f                	jmp    1e16 <_mi_page_unfull+0x86>
    1e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1e8e:	00 00 
    1e90:	48 39 52 58          	cmp    %rdx,0x58(%rdx)
    1e94:	73 bd                	jae    1e53 <_mi_page_unfull+0xc3>
    1e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    1e9d:	00 00 00 
    1ea0:	49 8d b9 40 0e 00 00 	lea    0xe40(%r9),%rdi
    1ea7:	e9 6a ff ff ff       	jmp    1e16 <_mi_page_unfull+0x86>
    1eac:	0f 1f 40 00          	nopl   0x0(%rax)
    1eb0:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    1eb6:	76 b0                	jbe    1e68 <_mi_page_unfull+0xd8>
    1eb8:	eb e6                	jmp    1ea0 <_mi_page_unfull+0x110>
    1eba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000001ec0 <_mi_page_free>:
    1ec0:	41 57                	push   %r15
    1ec2:	41 56                	push   %r14
    1ec4:	41 55                	push   %r13
    1ec6:	41 54                	push   %r12
    1ec8:	49 89 fc             	mov    %rdi,%r12
    1ecb:	55                   	push   %rbp
    1ecc:	53                   	push   %rbx
    1ecd:	48 89 f3             	mov    %rsi,%rbx
    1ed0:	48 83 ec 18          	sub    $0x18,%rsp
    1ed4:	f0 48 83 27 fd       	lock andq $0xfffffffffffffffd,(%rdi)
    1ed9:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    1edd:	48 8b 6f 38          	mov    0x38(%rdi),%rbp
    1ee1:	48 85 d2             	test   %rdx,%rdx
    1ee4:	74 08                	je     1eee <_mi_page_free+0x2e>
    1ee6:	48 8b 47 48          	mov    0x48(%rdi),%rax
    1eea:	48 89 42 48          	mov    %rax,0x48(%rdx)
    1eee:	48 8b 47 48          	mov    0x48(%rdi),%rax
    1ef2:	48 85 c0             	test   %rax,%rax
    1ef5:	74 04                	je     1efb <_mi_page_free+0x3b>
    1ef7:	48 89 50 50          	mov    %rdx,0x50(%rax)
    1efb:	48 3b 7b 08          	cmp    0x8(%rbx),%rdi
    1eff:	74 7f                	je     1f80 <_mi_page_free+0xc0>
    1f01:	48 3b 3b             	cmp    (%rbx),%rdi
    1f04:	0f 84 87 00 00 00    	je     1f91 <_mi_page_free+0xd1>
    1f0a:	48 83 ad b8 00 00 00 	subq   $0x1,0xb8(%rbp)
    1f11:	01 
    1f12:	66 0f ef c0          	pxor   %xmm0,%xmm0
    1f16:	48 83 6b 10 01       	subq   $0x1,0x10(%rbx)
    1f1b:	0f 11 47 48          	movups %xmm0,0x48(%rdi)
    1f1f:	f0 49 0f ba 34 24 00 	lock btrq $0x0,(%r12)
    1f26:	73 48                	jae    1f70 <_mi_page_free+0xb0>
    1f28:	48 8b 77 38          	mov    0x38(%rdi),%rsi
    1f2c:	48 85 f6             	test   %rsi,%rsi
    1f2f:	74 10                	je     1f41 <_mi_page_free+0x81>
    1f31:	0f b7 47 36          	movzwl 0x36(%rdi),%eax
    1f35:	48 0f af 47 28       	imul   0x28(%rdi),%rax
    1f3a:	48 29 86 d0 00 00 00 	sub    %rax,0xd0(%rsi)
    1f41:	48 c7 47 38 00 00 00 	movq   $0x0,0x38(%rdi)
    1f48:	00 
    1f49:	48 8b 07             	mov    (%rdi),%rax
    1f4c:	48 89 c2             	mov    %rax,%rdx
    1f4f:	83 e2 03             	and    $0x3,%edx
    1f52:	f0 48 0f b1 17       	lock cmpxchg %rdx,(%rdi)
    1f57:	75 f3                	jne    1f4c <_mi_page_free+0x8c>
    1f59:	48 83 c4 18          	add    $0x18,%rsp
    1f5d:	5b                   	pop    %rbx
    1f5e:	5d                   	pop    %rbp
    1f5f:	41 5c                	pop    %r12
    1f61:	41 5d                	pop    %r13
    1f63:	41 5e                	pop    %r14
    1f65:	41 5f                	pop    %r15
    1f67:	e9 00 00 00 00       	jmp    1f6c <_mi_page_free+0xac>
			1f68: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    1f6c:	0f 1f 40 00          	nopl   0x0(%rax)
    1f70:	48 8b 77 38          	mov    0x38(%rdi),%rsi
    1f74:	eb cb                	jmp    1f41 <_mi_page_free+0x81>
    1f76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    1f7d:	00 00 00 
    1f80:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    1f84:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    1f88:	48 3b 3b             	cmp    (%rbx),%rdi
    1f8b:	0f 85 79 ff ff ff    	jne    1f0a <_mi_page_free+0x4a>
    1f91:	4c 8b 6b 18          	mov    0x18(%rbx),%r13
    1f95:	48 89 03             	mov    %rax,(%rbx)
    1f98:	49 81 fd 00 04 00 00 	cmp    $0x400,%r13
    1f9f:	0f 87 65 ff ff ff    	ja     1f0a <_mi_page_free+0x4a>
    1fa5:	48 85 c0             	test   %rax,%rax
    1fa8:	0f 84 5a 01 00 00    	je     2108 <_mi_page_free+0x248>
    1fae:	4d 8d 45 07          	lea    0x7(%r13),%r8
    1fb2:	4c 8d 8d 18 01 00 00 	lea    0x118(%rbp),%r9
    1fb9:	49 c1 e8 03          	shr    $0x3,%r8
    1fbd:	4a 39 84 c5 18 01 00 	cmp    %rax,0x118(%rbp,%r8,8)
    1fc4:	00 
    1fc5:	0f 84 3f ff ff ff    	je     1f0a <_mi_page_free+0x4a>
    1fcb:	49 83 f8 01          	cmp    $0x1,%r8
    1fcf:	0f 86 23 01 00 00    	jbe    20f8 <_mi_page_free+0x238>
    1fd5:	49 83 f8 08          	cmp    $0x8,%r8
    1fd9:	0f 87 3d 01 00 00    	ja     211c <_mi_page_free+0x25c>
    1fdf:	4d 8d 50 01          	lea    0x1(%r8),%r10
    1fe3:	4d 89 d5             	mov    %r10,%r13
    1fe6:	49 83 e5 fe          	and    $0xfffffffffffffffe,%r13
    1fea:	48 8d 73 e0          	lea    -0x20(%rbx),%rsi
    1fee:	4c 8d 9d 20 05 00 00 	lea    0x520(%rbp),%r11
    1ff5:	eb 1f                	jmp    2016 <_mi_page_free+0x156>
    1ff7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1ffe:	00 00 
    2000:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
    2004:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
    2008:	49 39 cd             	cmp    %rcx,%r13
    200b:	75 28                	jne    2035 <_mi_page_free+0x175>
    200d:	49 39 f3             	cmp    %rsi,%r11
    2010:	73 23                	jae    2035 <_mi_page_free+0x175>
    2012:	48 83 ee 20          	sub    $0x20,%rsi
    2016:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
    201a:	48 83 c1 07          	add    $0x7,%rcx
    201e:	48 89 ca             	mov    %rcx,%rdx
    2021:	48 c1 ea 03          	shr    $0x3,%rdx
    2025:	48 83 f9 47          	cmp    $0x47,%rcx
    2029:	0f 87 99 00 00 00    	ja     20c8 <_mi_page_free+0x208>
    202f:	48 83 fa 01          	cmp    $0x1,%rdx
    2033:	77 cb                	ja     2000 <_mi_page_free+0x140>
    2035:	48 83 c2 01          	add    $0x1,%rdx
    2039:	4c 39 c2             	cmp    %r8,%rdx
    203c:	49 0f 47 d0          	cmova  %r8,%rdx
    2040:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
    2044:	4c 89 d6             	mov    %r10,%rsi
    2047:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    204d:	48 29 d6             	sub    %rdx,%rsi
    2050:	49 39 ca             	cmp    %rcx,%r10
    2053:	49 0f 42 f3          	cmovb  %r11,%rsi
    2057:	49 39 d0             	cmp    %rdx,%r8
    205a:	74 5d                	je     20b9 <_mi_page_free+0x1f9>
    205c:	49 39 ca             	cmp    %rcx,%r10
    205f:	72 58                	jb     20b9 <_mi_page_free+0x1f9>
    2061:	49 89 f0             	mov    %rsi,%r8
    2064:	48 8d 8c d5 18 01 00 	lea    0x118(%rbp,%rdx,8),%rcx
    206b:	00 
    206c:	66 48 0f 6e c0       	movq   %rax,%xmm0
    2071:	49 d1 e8             	shr    $1,%r8
    2074:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    2078:	49 c1 e0 04          	shl    $0x4,%r8
    207c:	4d 8d 14 08          	lea    (%r8,%rcx,1),%r10
    2080:	41 83 e0 10          	and    $0x10,%r8d
    2084:	74 12                	je     2098 <_mi_page_free+0x1d8>
    2086:	0f 11 01             	movups %xmm0,(%rcx)
    2089:	48 83 c1 10          	add    $0x10,%rcx
    208d:	4c 39 d1             	cmp    %r10,%rcx
    2090:	74 16                	je     20a8 <_mi_page_free+0x1e8>
    2092:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2098:	0f 11 01             	movups %xmm0,(%rcx)
    209b:	48 83 c1 20          	add    $0x20,%rcx
    209f:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
    20a3:	4c 39 d1             	cmp    %r10,%rcx
    20a6:	75 f0                	jne    2098 <_mi_page_free+0x1d8>
    20a8:	40 f6 c6 01          	test   $0x1,%sil
    20ac:	0f 84 58 fe ff ff    	je     1f0a <_mi_page_free+0x4a>
    20b2:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
    20b6:	48 01 f2             	add    %rsi,%rdx
    20b9:	49 89 04 d1          	mov    %rax,(%r9,%rdx,8)
    20bd:	e9 48 fe ff ff       	jmp    1f0a <_mi_page_free+0x4a>
    20c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    20c8:	48 81 fa 00 00 01 00 	cmp    $0x10000,%rdx
    20cf:	0f 87 60 ff ff ff    	ja     2035 <_mi_page_free+0x175>
    20d5:	4c 8d 72 ff          	lea    -0x1(%rdx),%r14
    20d9:	4d 0f bd fe          	bsr    %r14,%r15
    20dd:	41 8d 4f fe          	lea    -0x2(%r15),%ecx
    20e1:	49 d3 ee             	shr    %cl,%r14
    20e4:	41 83 e6 03          	and    $0x3,%r14d
    20e8:	4b 8d 4c be fd       	lea    -0x3(%r14,%r15,4),%rcx
    20ed:	e9 16 ff ff ff       	jmp    2008 <_mi_page_free+0x148>
    20f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    20f8:	31 d2                	xor    %edx,%edx
    20fa:	4d 8d 50 01          	lea    0x1(%r8),%r10
    20fe:	e9 3d ff ff ff       	jmp    2040 <_mi_page_free+0x180>
    2103:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2108:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    210d:	e8 00 00 00 00       	call   2112 <_mi_page_free+0x252>
			210e: R_X86_64_PLT32	_mi_page_empty_get-0x4
    2112:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    2117:	e9 92 fe ff ff       	jmp    1fae <_mi_page_free+0xee>
    211c:	49 8d 50 ff          	lea    -0x1(%r8),%rdx
    2120:	4d 8d 50 01          	lea    0x1(%r8),%r10
    2124:	48 0f bd f2          	bsr    %rdx,%rsi
    2128:	8d 4e fe             	lea    -0x2(%rsi),%ecx
    212b:	48 d3 ea             	shr    %cl,%rdx
    212e:	83 e2 03             	and    $0x3,%edx
    2131:	4c 8d 6c b2 fd       	lea    -0x3(%rdx,%rsi,4),%r13
    2136:	e9 af fe ff ff       	jmp    1fea <_mi_page_free+0x12a>
    213b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000002140 <_mi_page_retire>:
    2140:	80 7f 16 00          	cmpb   $0x0,0x16(%rdi)
    2144:	74 0a                	je     2150 <_mi_page_retire+0x10>
    2146:	c3                   	ret
    2147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    214e:	00 00 
    2150:	53                   	push   %rbx
    2151:	48 83 ec 10          	sub    $0x10,%rsp
    2155:	f0 48 83 27 fd       	lock andq $0xfffffffffffffffd,(%rdi)
    215a:	48 8b 5f 38          	mov    0x38(%rdi),%rbx
    215e:	48 8b 07             	mov    (%rdi),%rax
    2161:	48 8b 57 28          	mov    0x28(%rdi),%rdx
    2165:	a8 01                	test   $0x1,%al
    2167:	75 77                	jne    21e0 <_mi_page_retire+0xa0>
    2169:	66 83 7f 36 01       	cmpw   $0x1,0x36(%rdi)
    216e:	0f 84 cc 00 00 00    	je     2240 <_mi_page_retire+0x100>
    2174:	48 8d 4a 07          	lea    0x7(%rdx),%rcx
    2178:	48 89 c8             	mov    %rcx,%rax
    217b:	48 c1 e8 03          	shr    $0x3,%rax
    217f:	48 83 f9 47          	cmp    $0x47,%rcx
    2183:	0f 87 27 01 00 00    	ja     22b0 <_mi_page_retire+0x170>
    2189:	48 83 f8 01          	cmp    $0x1,%rax
    218d:	76 41                	jbe    21d0 <_mi_page_retire+0x90>
    218f:	48 83 c0 01          	add    $0x1,%rax
    2193:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    2197:	48 8d 70 29          	lea    0x29(%rax),%rsi
    219b:	48 c1 e6 05          	shl    $0x5,%rsi
    219f:	48 c1 e0 05          	shl    $0x5,%rax
    21a3:	48 01 de             	add    %rbx,%rsi
    21a6:	48 01 d8             	add    %rbx,%rax
    21a9:	48 81 b8 38 05 00 00 	cmpq   $0x80000,0x538(%rax)
    21b0:	00 00 08 00 
    21b4:	77 09                	ja     21bf <_mi_page_retire+0x7f>
    21b6:	48 39 b8 28 05 00 00 	cmp    %rdi,0x528(%rax)
    21bd:	74 31                	je     21f0 <_mi_page_retire+0xb0>
    21bf:	48 83 c4 10          	add    $0x10,%rsp
    21c3:	5b                   	pop    %rbx
    21c4:	e9 f7 fc ff ff       	jmp    1ec0 <_mi_page_free>
    21c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    21d0:	be 40 05 00 00       	mov    $0x540,%esi
    21d5:	b8 01 00 00 00       	mov    $0x1,%eax
    21da:	eb c3                	jmp    219f <_mi_page_retire+0x5f>
    21dc:	0f 1f 40 00          	nopl   0x0(%rax)
    21e0:	be 60 0e 00 00       	mov    $0xe60,%esi
    21e5:	b8 4a 00 00 00       	mov    $0x4a,%eax
    21ea:	eb b3                	jmp    219f <_mi_page_retire+0x5f>
    21ec:	0f 1f 40 00          	nopl   0x0(%rax)
    21f0:	48 39 b8 20 05 00 00 	cmp    %rdi,0x520(%rax)
    21f7:	75 c6                	jne    21bf <_mi_page_retire+0x7f>
    21f9:	48 81 fa 00 28 00 00 	cmp    $0x2800,%rdx
    2200:	0f 87 ba 00 00 00    	ja     22c0 <_mi_page_retire+0x180>
    2206:	c6 47 16 10          	movb   $0x10,0x16(%rdi)
    220a:	48 8d 83 20 05 00 00 	lea    0x520(%rbx),%rax
    2211:	48 29 c6             	sub    %rax,%rsi
    2214:	48 c1 fe 05          	sar    $0x5,%rsi
    2218:	48 3b b3 c0 00 00 00 	cmp    0xc0(%rbx),%rsi
    221f:	73 07                	jae    2228 <_mi_page_retire+0xe8>
    2221:	48 89 b3 c0 00 00 00 	mov    %rsi,0xc0(%rbx)
    2228:	48 39 b3 c8 00 00 00 	cmp    %rsi,0xc8(%rbx)
    222f:	73 07                	jae    2238 <_mi_page_retire+0xf8>
    2231:	48 89 b3 c8 00 00 00 	mov    %rsi,0xc8(%rbx)
    2238:	48 83 c4 10          	add    $0x10,%rsp
    223c:	5b                   	pop    %rbx
    223d:	c3                   	ret
    223e:	66 90                	xchg   %ax,%ax
    2240:	48 81 fa 00 00 08 00 	cmp    $0x80000,%rdx
    2247:	77 57                	ja     22a0 <_mi_page_retire+0x160>
    2249:	8b 47 68             	mov    0x68(%rdi),%eax
    224c:	83 e8 03             	sub    $0x3,%eax
    224f:	83 f8 02             	cmp    $0x2,%eax
    2252:	76 44                	jbe    2298 <_mi_page_retire+0x158>
    2254:	48 8d 4a 07          	lea    0x7(%rdx),%rcx
    2258:	48 89 c8             	mov    %rcx,%rax
    225b:	48 c1 e8 03          	shr    $0x3,%rax
    225f:	48 83 f9 47          	cmp    $0x47,%rcx
    2263:	0f 86 20 ff ff ff    	jbe    2189 <_mi_page_retire+0x49>
    2269:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2270:	48 83 e8 01          	sub    $0x1,%rax
    2274:	48 0f bd f0          	bsr    %rax,%rsi
    2278:	8d 4e fe             	lea    -0x2(%rsi),%ecx
    227b:	48 d3 e8             	shr    %cl,%rax
    227e:	83 e0 03             	and    $0x3,%eax
    2281:	48 8d 44 b0 fd       	lea    -0x3(%rax,%rsi,4),%rax
    2286:	48 8d 70 29          	lea    0x29(%rax),%rsi
    228a:	48 c1 e6 05          	shl    $0x5,%rsi
    228e:	e9 0c ff ff ff       	jmp    219f <_mi_page_retire+0x5f>
    2293:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2298:	48 39 7f 58          	cmp    %rdi,0x58(%rdi)
    229c:	73 b6                	jae    2254 <_mi_page_retire+0x114>
    229e:	66 90                	xchg   %ax,%ax
    22a0:	be 40 0e 00 00       	mov    $0xe40,%esi
    22a5:	b8 49 00 00 00       	mov    $0x49,%eax
    22aa:	e9 f0 fe ff ff       	jmp    219f <_mi_page_retire+0x5f>
    22af:	90                   	nop
    22b0:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    22b6:	76 b8                	jbe    2270 <_mi_page_retire+0x130>
    22b8:	eb e6                	jmp    22a0 <_mi_page_retire+0x160>
    22ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    22c0:	c6 47 16 04          	movb   $0x4,0x16(%rdi)
    22c4:	48 81 fa aa 52 01 00 	cmp    $0x152aa,%rdx
    22cb:	0f 86 39 ff ff ff    	jbe    220a <_mi_page_retire+0xca>
    22d1:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    22d6:	e8 00 00 00 00       	call   22db <_mi_page_retire+0x19b>
			22d7: R_X86_64_PLT32	_mi_page_publish_retired-0x4
    22db:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    22e0:	e9 25 ff ff ff       	jmp    220a <_mi_page_retire+0xca>
    22e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    22ec:	00 00 00 00 

00000000000022f0 <_mi_theap_collect_retired>:
    22f0:	41 57                	push   %r15
    22f2:	41 56                	push   %r14
    22f4:	41 55                	push   %r13
    22f6:	41 54                	push   %r12
    22f8:	49 89 fc             	mov    %rdi,%r12
    22fb:	55                   	push   %rbp
    22fc:	53                   	push   %rbx
    22fd:	48 83 ec 08          	sub    $0x8,%rsp
    2301:	48 8b af c0 00 00 00 	mov    0xc0(%rdi),%rbp
    2308:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    230f:	48 39 ea             	cmp    %rbp,%rdx
    2312:	0f 82 38 02 00 00    	jb     2550 <_mi_theap_collect_retired+0x260>
    2318:	48 8d 5d 29          	lea    0x29(%rbp),%rbx
    231c:	41 89 f5             	mov    %esi,%r13d
    231f:	45 31 f6             	xor    %r14d,%r14d
    2322:	41 bf 4a 00 00 00    	mov    $0x4a,%r15d
    2328:	48 c1 e3 05          	shl    $0x5,%rbx
    232c:	48 01 fb             	add    %rdi,%rbx
    232f:	90                   	nop
    2330:	48 8b 3b             	mov    (%rbx),%rdi
    2333:	48 85 ff             	test   %rdi,%rdi
    2336:	0f 84 84 00 00 00    	je     23c0 <_mi_theap_collect_retired+0xd0>
    233c:	0f b6 47 16          	movzbl 0x16(%rdi),%eax
    2340:	84 c0                	test   %al,%al
    2342:	74 7c                	je     23c0 <_mi_theap_collect_retired+0xd0>
    2344:	8b 4f 10             	mov    0x10(%rdi),%ecx
    2347:	85 c9                	test   %ecx,%ecx
    2349:	0f 85 89 00 00 00    	jne    23d8 <_mi_theap_collect_retired+0xe8>
    234f:	83 e8 01             	sub    $0x1,%eax
    2352:	88 47 16             	mov    %al,0x16(%rdi)
    2355:	84 c0                	test   %al,%al
    2357:	74 57                	je     23b0 <_mi_theap_collect_retired+0xc0>
    2359:	45 84 ed             	test   %r13b,%r13b
    235c:	75 52                	jne    23b0 <_mi_theap_collect_retired+0xc0>
    235e:	49 39 ef             	cmp    %rbp,%r15
    2361:	4c 0f 47 fd          	cmova  %rbp,%r15
    2365:	49 39 ee             	cmp    %rbp,%r14
    2368:	4c 0f 42 f5          	cmovb  %rbp,%r14
    236c:	48 83 c5 01          	add    $0x1,%rbp
    2370:	48 83 c3 20          	add    $0x20,%rbx
    2374:	48 39 ea             	cmp    %rbp,%rdx
    2377:	73 b7                	jae    2330 <_mi_theap_collect_retired+0x40>
    2379:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2380:	41 80 bc 24 11 01 00 	cmpb   $0x0,0x111(%r12)
    2387:	00 00 
    2389:	4d 89 bc 24 c0 00 00 	mov    %r15,0xc0(%r12)
    2390:	00 
    2391:	4d 89 b4 24 c8 00 00 	mov    %r14,0xc8(%r12)
    2398:	00 
    2399:	74 45                	je     23e0 <_mi_theap_collect_retired+0xf0>
    239b:	48 83 c4 08          	add    $0x8,%rsp
    239f:	5b                   	pop    %rbx
    23a0:	5d                   	pop    %rbp
    23a1:	41 5c                	pop    %r12
    23a3:	41 5d                	pop    %r13
    23a5:	41 5e                	pop    %r14
    23a7:	41 5f                	pop    %r15
    23a9:	c3                   	ret
    23aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    23b0:	48 89 de             	mov    %rbx,%rsi
    23b3:	e8 00 00 00 00       	call   23b8 <_mi_theap_collect_retired+0xc8>
			23b4: R_X86_64_PLT32	_mi_page_free-0x4
    23b8:	49 8b 94 24 c8 00 00 	mov    0xc8(%r12),%rdx
    23bf:	00 
    23c0:	48 83 c5 01          	add    $0x1,%rbp
    23c4:	48 83 c3 20          	add    $0x20,%rbx
    23c8:	48 39 ea             	cmp    %rbp,%rdx
    23cb:	0f 83 5f ff ff ff    	jae    2330 <_mi_theap_collect_retired+0x40>
    23d1:	eb ad                	jmp    2380 <_mi_theap_collect_retired+0x90>
    23d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    23d8:	c6 47 16 00          	movb   $0x0,0x16(%rdi)
    23dc:	eb e2                	jmp    23c0 <_mi_theap_collect_retired+0xd0>
    23de:	66 90                	xchg   %ax,%ax
    23e0:	49 8b ac 24 60 0e 00 	mov    0xe60(%r12),%rbp
    23e7:	00 
    23e8:	4d 8d ac 24 60 0e 00 	lea    0xe60(%r12),%r13
    23ef:	00 
    23f0:	48 85 ed             	test   %rbp,%rbp
    23f3:	74 a6                	je     239b <_mi_theap_collect_retired+0xab>
    23f5:	48 89 eb             	mov    %rbp,%rbx
    23f8:	31 f6                	xor    %esi,%esi
    23fa:	48 8b 6d 48          	mov    0x48(%rbp),%rbp
    23fe:	48 89 df             	mov    %rbx,%rdi
    2401:	e8 1a de ff ff       	call   220 <mi_page_free_collect_ex.constprop.0>
    2406:	8b 43 10             	mov    0x10(%rbx),%eax
    2409:	0f b7 53 36          	movzwl 0x36(%rbx),%edx
    240d:	39 c2                	cmp    %eax,%edx
    240f:	74 df                	je     23f0 <_mi_theap_collect_retired+0x100>
    2411:	85 c0                	test   %eax,%eax
    2413:	75 1b                	jne    2430 <_mi_theap_collect_retired+0x140>
    2415:	4c 89 ee             	mov    %r13,%rsi
    2418:	48 89 df             	mov    %rbx,%rdi
    241b:	e8 00 00 00 00       	call   2420 <_mi_theap_collect_retired+0x130>
			241c: R_X86_64_PLT32	_mi_page_free-0x4
    2420:	48 85 ed             	test   %rbp,%rbp
    2423:	75 d0                	jne    23f5 <_mi_theap_collect_retired+0x105>
    2425:	e9 71 ff ff ff       	jmp    239b <_mi_theap_collect_retired+0xab>
    242a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2430:	48 8b 03             	mov    (%rbx),%rax
    2433:	48 89 da             	mov    %rbx,%rdx
    2436:	a8 01                	test   $0x1,%al
    2438:	74 b6                	je     23f0 <_mi_theap_collect_retired+0x100>
    243a:	4c 8b 43 38          	mov    0x38(%rbx),%r8
    243e:	49 8d b0 60 0e 00 00 	lea    0xe60(%r8),%rsi
    2445:	f0 48 0f ba 33 00    	lock btrq $0x0,(%rbx)
    244b:	73 19                	jae    2466 <_mi_theap_collect_retired+0x176>
    244d:	48 8b 43 38          	mov    0x38(%rbx),%rax
    2451:	48 85 c0             	test   %rax,%rax
    2454:	74 10                	je     2466 <_mi_theap_collect_retired+0x176>
    2456:	0f b7 4b 36          	movzwl 0x36(%rbx),%ecx
    245a:	48 0f af 4b 28       	imul   0x28(%rbx),%rcx
    245f:	48 29 88 d0 00 00 00 	sub    %rcx,0xd0(%rax)
    2466:	48 8b 03             	mov    (%rbx),%rax
    2469:	48 89 f7             	mov    %rsi,%rdi
    246c:	a8 01                	test   $0x1,%al
    246e:	75 43                	jne    24b3 <_mi_theap_collect_retired+0x1c3>
    2470:	66 83 7b 36 01       	cmpw   $0x1,0x36(%rbx)
    2475:	48 8b 43 28          	mov    0x28(%rbx),%rax
    2479:	74 6d                	je     24e8 <_mi_theap_collect_retired+0x1f8>
    247b:	48 8d 48 07          	lea    0x7(%rax),%rcx
    247f:	48 89 c8             	mov    %rcx,%rax
    2482:	48 c1 e8 03          	shr    $0x3,%rax
    2486:	48 83 f9 47          	cmp    $0x47,%rcx
    248a:	0f 87 a8 00 00 00    	ja     2538 <_mi_theap_collect_retired+0x248>
    2490:	49 8d b8 40 05 00 00 	lea    0x540(%r8),%rdi
    2497:	48 83 f8 01          	cmp    $0x1,%rax
    249b:	76 16                	jbe    24b3 <_mi_theap_collect_retired+0x1c3>
    249d:	48 8d 78 01          	lea    0x1(%rax),%rdi
    24a1:	48 89 f8             	mov    %rdi,%rax
    24a4:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    24a8:	48 8d 78 29          	lea    0x29(%rax),%rdi
    24ac:	48 c1 e7 05          	shl    $0x5,%rdi
    24b0:	4c 01 c7             	add    %r8,%rdi
    24b3:	f0 48 0f ba 2a 00    	lock btsq $0x0,(%rdx)
    24b9:	72 19                	jb     24d4 <_mi_theap_collect_retired+0x1e4>
    24bb:	48 8b 43 38          	mov    0x38(%rbx),%rax
    24bf:	48 85 c0             	test   %rax,%rax
    24c2:	74 10                	je     24d4 <_mi_theap_collect_retired+0x1e4>
    24c4:	0f b7 53 36          	movzwl 0x36(%rbx),%edx
    24c8:	48 0f af 53 28       	imul   0x28(%rbx),%rdx
    24cd:	48 01 90 d0 00 00 00 	add    %rdx,0xd0(%rax)
    24d4:	48 89 da             	mov    %rbx,%rdx
    24d7:	e8 34 e3 ff ff       	call   810 <mi_page_queue_enqueue_from_ex.constprop.0>
    24dc:	e9 0f ff ff ff       	jmp    23f0 <_mi_theap_collect_retired+0x100>
    24e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    24e8:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
    24ee:	77 50                	ja     2540 <_mi_theap_collect_retired+0x250>
    24f0:	8b 4b 68             	mov    0x68(%rbx),%ecx
    24f3:	83 e9 03             	sub    $0x3,%ecx
    24f6:	83 f9 02             	cmp    $0x2,%ecx
    24f9:	77 06                	ja     2501 <_mi_theap_collect_retired+0x211>
    24fb:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
    24ff:	72 3f                	jb     2540 <_mi_theap_collect_retired+0x250>
    2501:	48 8d 48 07          	lea    0x7(%rax),%rcx
    2505:	48 89 c8             	mov    %rcx,%rax
    2508:	48 c1 e8 03          	shr    $0x3,%rax
    250c:	48 83 f9 47          	cmp    $0x47,%rcx
    2510:	0f 86 7a ff ff ff    	jbe    2490 <_mi_theap_collect_retired+0x1a0>
    2516:	48 83 e8 01          	sub    $0x1,%rax
    251a:	48 0f bd f8          	bsr    %rax,%rdi
    251e:	8d 4f fe             	lea    -0x2(%rdi),%ecx
    2521:	48 d3 e8             	shr    %cl,%rax
    2524:	83 e0 03             	and    $0x3,%eax
    2527:	48 8d 7c b8 26       	lea    0x26(%rax,%rdi,4),%rdi
    252c:	48 c1 e7 05          	shl    $0x5,%rdi
    2530:	4c 01 c7             	add    %r8,%rdi
    2533:	e9 7b ff ff ff       	jmp    24b3 <_mi_theap_collect_retired+0x1c3>
    2538:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    253e:	76 d6                	jbe    2516 <_mi_theap_collect_retired+0x226>
    2540:	49 8d b8 40 0e 00 00 	lea    0xe40(%r8),%rdi
    2547:	e9 67 ff ff ff       	jmp    24b3 <_mi_theap_collect_retired+0x1c3>
    254c:	0f 1f 40 00          	nopl   0x0(%rax)
    2550:	45 31 f6             	xor    %r14d,%r14d
    2553:	41 bf 4a 00 00 00    	mov    $0x4a,%r15d
    2559:	e9 22 fe ff ff       	jmp    2380 <_mi_theap_collect_retired+0x90>
    255e:	66 90                	xchg   %ax,%ax

0000000000002560 <mi_page_queue_find_free_ex>:
    2560:	41 57                	push   %r15
    2562:	41 56                	push   %r14
    2564:	41 55                	push   %r13
    2566:	41 54                	push   %r12
    2568:	55                   	push   %rbp
    2569:	53                   	push   %rbx
    256a:	48 83 ec 28          	sub    $0x28,%rsp
    256e:	48 81 7e 18 00 28 00 	cmpq   $0x2800,0x18(%rsi)
    2575:	00 
    2576:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
    257b:	48 89 34 24          	mov    %rsi,(%rsp)
    257f:	89 54 24 1c          	mov    %edx,0x1c(%rsp)
    2583:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    258a:	00 00 
    258c:	77 0c                	ja     259a <mi_page_queue_find_free_ex+0x3a>
    258e:	48 8b 87 08 01 00 00 	mov    0x108(%rdi),%rax
    2595:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    259a:	48 8b 04 24          	mov    (%rsp),%rax
    259e:	4c 8b 28             	mov    (%rax),%r13
    25a1:	4d 85 ed             	test   %r13,%r13
    25a4:	0f 84 2e 03 00 00    	je     28d8 <mi_page_queue_find_free_ex+0x378>
    25aa:	31 ed                	xor    %ebp,%ebp
    25ac:	45 31 f6             	xor    %r14d,%r14d
    25af:	45 31 ff             	xor    %r15d,%r15d
    25b2:	eb 37                	jmp    25eb <mi_page_queue_find_free_ex+0x8b>
    25b4:	0f 1f 40 00          	nopl   0x0(%rax)
    25b8:	8b 73 10             	mov    0x10(%rbx),%esi
    25bb:	39 c6                	cmp    %eax,%esi
    25bd:	72 15                	jb     25d4 <mi_page_queue_find_free_ex+0x74>
    25bf:	0f b7 7b 36          	movzwl 0x36(%rbx),%edi
    25c3:	89 f8                	mov    %edi,%eax
    25c5:	29 f7                	sub    %esi,%edi
    25c7:	66 c1 e8 03          	shr    $0x3,%ax
    25cb:	0f b7 c0             	movzwl %ax,%eax
    25ce:	39 f8                	cmp    %edi,%eax
    25d0:	48 0f 42 eb          	cmovb  %rbx,%rbp
    25d4:	4d 85 f6             	test   %r14,%r14
    25d7:	0f 8e 83 00 00 00    	jle    2660 <mi_page_queue_find_free_ex+0x100>
    25dd:	45 84 e4             	test   %r12b,%r12b
    25e0:	75 7e                	jne    2660 <mi_page_queue_find_free_ex+0x100>
    25e2:	4d 85 ed             	test   %r13,%r13
    25e5:	0f 84 85 01 00 00    	je     2770 <mi_page_queue_find_free_ex+0x210>
    25eb:	4c 89 eb             	mov    %r13,%rbx
    25ee:	49 83 c7 01          	add    $0x1,%r15
    25f2:	49 83 ee 01          	sub    $0x1,%r14
    25f6:	4d 8b 6d 48          	mov    0x48(%r13),%r13
    25fa:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    25ff:	0f 84 cb 00 00 00    	je     26d0 <mi_page_queue_find_free_ex+0x170>
    2605:	41 bc 01 00 00 00    	mov    $0x1,%r12d
    260b:	48 85 ed             	test   %rbp,%rbp
    260e:	0f 84 20 02 00 00    	je     2834 <mi_page_queue_find_free_ex+0x2d4>
    2614:	8b 45 10             	mov    0x10(%rbp),%eax
    2617:	85 c0                	test   %eax,%eax
    2619:	75 9d                	jne    25b8 <mi_page_queue_find_free_ex+0x58>
    261b:	f0 48 83 65 00 fd    	lock andq $0xfffffffffffffffd,0x0(%rbp)
    2621:	48 8b 3c 24          	mov    (%rsp),%rdi
    2625:	48 89 ee             	mov    %rbp,%rsi
    2628:	e8 b3 df ff ff       	call   5e0 <mi_page_queue_remove>
    262d:	48 8b 75 38          	mov    0x38(%rbp),%rsi
    2631:	48 c7 45 38 00 00 00 	movq   $0x0,0x38(%rbp)
    2638:	00 
    2639:	48 8b 45 00          	mov    0x0(%rbp),%rax
    263d:	48 89 c7             	mov    %rax,%rdi
    2640:	83 e7 03             	and    $0x3,%edi
    2643:	f0 48 0f b1 7d 00    	lock cmpxchg %rdi,0x0(%rbp)
    2649:	75 f2                	jne    263d <mi_page_queue_find_free_ex+0xdd>
    264b:	48 89 ef             	mov    %rbp,%rdi
    264e:	48 89 dd             	mov    %rbx,%rbp
    2651:	e8 00 00 00 00       	call   2656 <mi_page_queue_find_free_ex+0xf6>
			2652: R_X86_64_PLT32	_mi_arenas_page_free-0x4
    2656:	4d 85 f6             	test   %r14,%r14
    2659:	7f 82                	jg     25dd <mi_page_queue_find_free_ex+0x7d>
    265b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2660:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    2665:	4c 89 fe             	mov    %r15,%rsi
    2668:	48 8d bb f0 0f 00 00 	lea    0xff0(%rbx),%rdi
    266f:	e8 00 00 00 00       	call   2674 <mi_page_queue_find_free_ex+0x114>
			2670: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    2674:	48 8d bb f8 0f 00 00 	lea    0xff8(%rbx),%rdi
    267b:	be 01 00 00 00       	mov    $0x1,%esi
    2680:	e8 00 00 00 00       	call   2685 <mi_page_queue_find_free_ex+0x125>
			2681: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    2685:	48 83 7d 08 00       	cmpq   $0x0,0x8(%rbp)
    268a:	0f 84 f8 01 00 00    	je     2888 <mi_page_queue_find_free_ex+0x328>
    2690:	48 8b 1c 24          	mov    (%rsp),%rbx
    2694:	48 3b 2b             	cmp    (%rbx),%rbp
    2697:	74 1b                	je     26b4 <mi_page_queue_find_free_ex+0x154>
    2699:	48 89 ee             	mov    %rbp,%rsi
    269c:	48 89 df             	mov    %rbx,%rdi
    269f:	e8 3c df ff ff       	call   5e0 <mi_page_queue_remove>
    26a4:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    26a9:	48 89 ea             	mov    %rbp,%rdx
    26ac:	48 89 de             	mov    %rbx,%rsi
    26af:	e8 dc dc ff ff       	call   390 <mi_page_queue_push>
    26b4:	c6 45 16 00          	movb   $0x0,0x16(%rbp)
    26b8:	48 83 c4 28          	add    $0x28,%rsp
    26bc:	48 89 e8             	mov    %rbp,%rax
    26bf:	5b                   	pop    %rbx
    26c0:	5d                   	pop    %rbp
    26c1:	41 5c                	pop    %r12
    26c3:	41 5d                	pop    %r13
    26c5:	41 5e                	pop    %r14
    26c7:	41 5f                	pop    %r15
    26c9:	c3                   	ret
    26ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    26d0:	31 f6                	xor    %esi,%esi
    26d2:	48 89 df             	mov    %rbx,%rdi
    26d5:	e8 46 db ff ff       	call   220 <mi_page_free_collect_ex.constprop.0>
    26da:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    26df:	0f 85 20 ff ff ff    	jne    2605 <mi_page_queue_find_free_ex+0xa5>
    26e5:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
    26e9:	66 39 43 14          	cmp    %ax,0x14(%rbx)
    26ed:	0f 82 35 01 00 00    	jb     2828 <mi_page_queue_find_free_ex+0x2c8>
    26f3:	48 83 6c 24 08 01    	subq   $0x1,0x8(%rsp)
    26f9:	0f 89 e3 fe ff ff    	jns    25e2 <mi_page_queue_find_free_ex+0x82>
    26ff:	4c 8b 63 38          	mov    0x38(%rbx),%r12
    2703:	48 89 de             	mov    %rbx,%rsi
    2706:	4c 89 e7             	mov    %r12,%rdi
    2709:	e8 00 00 00 00       	call   270e <mi_page_queue_find_free_ex+0x1ae>
			270a: R_X86_64_PLT32	_mi_large_span_on_full-0x4
    270e:	41 80 bc 24 11 01 00 	cmpb   $0x0,0x111(%r12)
    2715:	00 00 
    2717:	0f 84 33 01 00 00    	je     2850 <mi_page_queue_find_free_ex+0x2f0>
    271d:	31 f6                	xor    %esi,%esi
    271f:	48 89 df             	mov    %rbx,%rdi
    2722:	e8 00 00 00 00       	call   2727 <mi_page_queue_find_free_ex+0x1c7>
			2723: R_X86_64_PLT32	_mi_page_free_collect_no_unpurge-0x4
    2727:	8b 43 10             	mov    0x10(%rbx),%eax
    272a:	85 c0                	test   %eax,%eax
    272c:	0f 84 76 01 00 00    	je     28a8 <mi_page_queue_find_free_ex+0x348>
    2732:	48 8b 3c 24          	mov    (%rsp),%rdi
    2736:	48 89 de             	mov    %rbx,%rsi
    2739:	e8 a2 de ff ff       	call   5e0 <mi_page_queue_remove>
    273e:	48 8b 73 38          	mov    0x38(%rbx),%rsi
    2742:	48 c7 43 38 00 00 00 	movq   $0x0,0x38(%rbx)
    2749:	00 
    274a:	48 8b 03             	mov    (%rbx),%rax
    274d:	48 89 c2             	mov    %rax,%rdx
    2750:	83 e2 03             	and    $0x3,%edx
    2753:	f0 48 0f b1 13       	lock cmpxchg %rdx,(%rbx)
    2758:	75 f3                	jne    274d <mi_page_queue_find_free_ex+0x1ed>
    275a:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    275e:	48 89 df             	mov    %rbx,%rdi
    2761:	e8 00 00 00 00       	call   2766 <mi_page_queue_find_free_ex+0x206>
			2762: R_X86_64_PLT32	_mi_arenas_page_abandon-0x4
    2766:	4d 85 ed             	test   %r13,%r13
    2769:	0f 85 7c fe ff ff    	jne    25eb <mi_page_queue_find_free_ex+0x8b>
    276f:	90                   	nop
    2770:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    2775:	4c 89 fe             	mov    %r15,%rsi
    2778:	48 8d bb f0 0f 00 00 	lea    0xff0(%rbx),%rdi
    277f:	e8 00 00 00 00       	call   2784 <mi_page_queue_find_free_ex+0x224>
			2780: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    2784:	48 8d bb f8 0f 00 00 	lea    0xff8(%rbx),%rdi
    278b:	be 01 00 00 00       	mov    $0x1,%esi
    2790:	e8 00 00 00 00       	call   2795 <mi_page_queue_find_free_ex+0x235>
			2791: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    2795:	48 85 ed             	test   %rbp,%rbp
    2798:	0f 85 e7 fe ff ff    	jne    2685 <mi_page_queue_find_free_ex+0x125>
    279e:	66 90                	xchg   %ax,%ax
    27a0:	48 8b 04 24          	mov    (%rsp),%rax
    27a4:	48 8b 50 18          	mov    0x18(%rax),%rdx
    27a8:	48 8d 82 55 ad fe ff 	lea    -0x152ab(%rdx),%rax
    27af:	48 3d 55 ad 06 00    	cmp    $0x6ad55,%rax
    27b5:	0f 87 04 01 00 00    	ja     28bf <mi_page_queue_find_free_ex+0x35f>
    27bb:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    27c0:	48 8b 01             	mov    (%rcx),%rax
    27c3:	48 8b 89 d8 00 00 00 	mov    0xd8(%rcx),%rcx
    27ca:	89 ce                	mov    %ecx,%esi
    27cc:	2b b0 f0 01 00 00    	sub    0x1f0(%rax),%esi
    27d2:	83 fe 03             	cmp    $0x3,%esi
    27d5:	0f 87 de 00 00 00    	ja     28b9 <mi_page_queue_find_free_ex+0x359>
    27db:	4c 8b 3c 24          	mov    (%rsp),%r15
    27df:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    27e4:	31 c9                	xor    %ecx,%ecx
    27e6:	4c 89 fe             	mov    %r15,%rsi
    27e9:	48 89 df             	mov    %rbx,%rdi
    27ec:	e8 bf ee ff ff       	call   16b0 <mi_page_fresh_alloc>
    27f1:	48 89 c5             	mov    %rax,%rbp
    27f4:	48 85 c0             	test   %rax,%rax
    27f7:	0f 85 bb fe ff ff    	jne    26b8 <mi_page_queue_find_free_ex+0x158>
    27fd:	80 7c 24 1c 00       	cmpb   $0x0,0x1c(%rsp)
    2802:	0f 84 b0 fe ff ff    	je     26b8 <mi_page_queue_find_free_ex+0x158>
    2808:	48 83 c4 28          	add    $0x28,%rsp
    280c:	4c 89 fe             	mov    %r15,%rsi
    280f:	48 89 df             	mov    %rbx,%rdi
    2812:	31 d2                	xor    %edx,%edx
    2814:	5b                   	pop    %rbx
    2815:	5d                   	pop    %rbp
    2816:	41 5c                	pop    %r12
    2818:	41 5d                	pop    %r13
    281a:	41 5e                	pop    %r14
    281c:	41 5f                	pop    %r15
    281e:	e9 3d fd ff ff       	jmp    2560 <mi_page_queue_find_free_ex>
    2823:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2828:	45 31 e4             	xor    %r12d,%r12d
    282b:	48 85 ed             	test   %rbp,%rbp
    282e:	0f 85 e0 fd ff ff    	jne    2614 <mi_page_queue_find_free_ex+0xb4>
    2834:	bf 25 00 00 00       	mov    $0x25,%edi
    2839:	48 89 dd             	mov    %rbx,%rbp
    283c:	e8 00 00 00 00       	call   2841 <mi_page_queue_find_free_ex+0x2e1>
			283d: R_X86_64_PLT32	_mi_option_get_fast-0x4
    2841:	49 89 c6             	mov    %rax,%r14
    2844:	e9 8b fd ff ff       	jmp    25d4 <mi_page_queue_find_free_ex+0x74>
    2849:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2850:	48 8b 03             	mov    (%rbx),%rax
    2853:	a8 01                	test   $0x1,%al
    2855:	0f 85 87 fd ff ff    	jne    25e2 <mi_page_queue_find_free_ex+0x82>
    285b:	48 8b 43 38          	mov    0x38(%rbx),%rax
    285f:	48 8b 34 24          	mov    (%rsp),%rsi
    2863:	48 89 da             	mov    %rbx,%rdx
    2866:	48 8d b8 60 0e 00 00 	lea    0xe60(%rax),%rdi
    286d:	e8 9e df ff ff       	call   810 <mi_page_queue_enqueue_from_ex.constprop.0>
    2872:	31 f6                	xor    %esi,%esi
    2874:	48 89 df             	mov    %rbx,%rdi
    2877:	e8 a4 d9 ff ff       	call   220 <mi_page_free_collect_ex.constprop.0>
    287c:	e9 61 fd ff ff       	jmp    25e2 <mi_page_queue_find_free_ex+0x82>
    2881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2888:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    288d:	48 89 ee             	mov    %rbp,%rsi
    2890:	e8 bb d7 ff ff       	call   50 <mi_page_extend_free>
    2895:	84 c0                	test   %al,%al
    2897:	0f 85 f3 fd ff ff    	jne    2690 <mi_page_queue_find_free_ex+0x130>
    289d:	e9 fe fe ff ff       	jmp    27a0 <mi_page_queue_find_free_ex+0x240>
    28a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    28a8:	48 8b 34 24          	mov    (%rsp),%rsi
    28ac:	48 89 df             	mov    %rbx,%rdi
    28af:	e8 00 00 00 00       	call   28b4 <mi_page_queue_find_free_ex+0x354>
			28b0: R_X86_64_PLT32	_mi_page_free-0x4
    28b4:	e9 29 fd ff ff       	jmp    25e2 <mi_page_queue_find_free_ex+0x82>
    28b9:	89 88 f0 01 00 00    	mov    %ecx,0x1f0(%rax)
    28bf:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    28c4:	31 f6                	xor    %esi,%esi
    28c6:	e8 00 00 00 00       	call   28cb <mi_page_queue_find_free_ex+0x36b>
			28c7: R_X86_64_PLT32	_mi_theap_collect_retired-0x4
    28cb:	48 8b 04 24          	mov    (%rsp),%rax
    28cf:	48 8b 50 18          	mov    0x18(%rax),%rdx
    28d3:	e9 03 ff ff ff       	jmp    27db <mi_page_queue_find_free_ex+0x27b>
    28d8:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    28dd:	31 f6                	xor    %esi,%esi
    28df:	48 8d bb f0 0f 00 00 	lea    0xff0(%rbx),%rdi
    28e6:	e8 00 00 00 00       	call   28eb <mi_page_queue_find_free_ex+0x38b>
			28e7: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    28eb:	48 8d bb f8 0f 00 00 	lea    0xff8(%rbx),%rdi
    28f2:	be 01 00 00 00       	mov    $0x1,%esi
    28f7:	e8 00 00 00 00       	call   28fc <mi_page_queue_find_free_ex+0x39c>
			28f8: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    28fc:	e9 9f fe ff ff       	jmp    27a0 <mi_page_queue_find_free_ex+0x240>
    2901:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    2908:	00 00 00 00 
    290c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000002910 <mi_find_page>:
    2910:	41 54                	push   %r12
    2912:	55                   	push   %rbp
    2913:	53                   	push   %rbx
    2914:	48 89 fb             	mov    %rdi,%rbx
    2917:	48 89 f7             	mov    %rsi,%rdi
    291a:	48 83 ec 10          	sub    $0x10,%rsp
    291e:	48 85 f6             	test   %rsi,%rsi
    2921:	0f 88 a9 00 00 00    	js     29d0 <mi_find_page+0xc0>
    2927:	49 89 d4             	mov    %rdx,%r12
    292a:	48 85 d2             	test   %rdx,%rdx
    292d:	74 59                	je     2988 <mi_find_page+0x78>
    292f:	be 40 0e 00 00       	mov    $0xe40,%esi
    2934:	b8 49 00 00 00       	mov    $0x49,%eax
    2939:	48 89 c2             	mov    %rax,%rdx
    293c:	48 8d 2c 33          	lea    (%rbx,%rsi,1),%rbp
    2940:	48 c1 e2 05          	shl    $0x5,%rdx
    2944:	48 81 bc 13 38 05 00 	cmpq   $0x80008,0x538(%rbx,%rdx,1)
    294b:	00 08 00 08 00 
    2950:	0f 84 ba 00 00 00    	je     2a10 <mi_find_page+0x100>
    2956:	48 c1 e0 05          	shl    $0x5,%rax
    295a:	48 8b 84 18 20 05 00 	mov    0x520(%rax,%rbx,1),%rax
    2961:	00 
    2962:	48 85 c0             	test   %rax,%rax
    2965:	0f 84 8d 00 00 00    	je     29f8 <mi_find_page+0xe8>
    296b:	48 83 78 08 00       	cmpq   $0x0,0x8(%rax)
    2970:	0f 84 ea 00 00 00    	je     2a60 <mi_find_page+0x150>
    2976:	c6 40 16 00          	movb   $0x0,0x16(%rax)
    297a:	48 83 c4 10          	add    $0x10,%rsp
    297e:	5b                   	pop    %rbx
    297f:	5d                   	pop    %rbp
    2980:	41 5c                	pop    %r12
    2982:	c3                   	ret
    2983:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2988:	48 8d 56 07          	lea    0x7(%rsi),%rdx
    298c:	48 89 d0             	mov    %rdx,%rax
    298f:	48 c1 e8 03          	shr    $0x3,%rax
    2993:	48 83 fa 47          	cmp    $0x47,%rdx
    2997:	0f 87 e1 00 00 00    	ja     2a7e <mi_find_page+0x16e>
    299d:	48 83 f8 01          	cmp    $0x1,%rax
    29a1:	76 15                	jbe    29b8 <mi_find_page+0xa8>
    29a3:	48 83 c0 01          	add    $0x1,%rax
    29a7:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    29ab:	48 8d 70 29          	lea    0x29(%rax),%rsi
    29af:	48 c1 e6 05          	shl    $0x5,%rsi
    29b3:	eb 84                	jmp    2939 <mi_find_page+0x29>
    29b5:	0f 1f 00             	nopl   (%rax)
    29b8:	be 40 05 00 00       	mov    $0x540,%esi
    29bd:	b8 01 00 00 00       	mov    $0x1,%eax
    29c2:	e9 72 ff ff ff       	jmp    2939 <mi_find_page+0x29>
    29c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    29ce:	00 00 
    29d0:	48 89 f2             	mov    %rsi,%rdx
    29d3:	31 c0                	xor    %eax,%eax
    29d5:	bf 4b 00 00 00       	mov    $0x4b,%edi
    29da:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 29e1 <mi_find_page+0xd1>
			29dd: R_X86_64_PC32	.LC2-0x4
    29e1:	e8 00 00 00 00       	call   29e6 <mi_find_page+0xd6>
			29e2: R_X86_64_PLT32	_mi_error_message-0x4
    29e6:	48 83 c4 10          	add    $0x10,%rsp
    29ea:	31 c0                	xor    %eax,%eax
    29ec:	5b                   	pop    %rbx
    29ed:	5d                   	pop    %rbp
    29ee:	41 5c                	pop    %r12
    29f0:	c3                   	ret
    29f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    29f8:	48 83 c4 10          	add    $0x10,%rsp
    29fc:	48 89 ee             	mov    %rbp,%rsi
    29ff:	48 89 df             	mov    %rbx,%rdi
    2a02:	ba 01 00 00 00       	mov    $0x1,%edx
    2a07:	5b                   	pop    %rbx
    2a08:	5d                   	pop    %rbp
    2a09:	41 5c                	pop    %r12
    2a0b:	e9 50 fb ff ff       	jmp    2560 <mi_page_queue_find_free_ex>
    2a10:	e8 00 00 00 00       	call   2a15 <mi_find_page+0x105>
			2a11: R_X86_64_PLT32	_mi_os_good_alloc_size-0x4
    2a15:	4c 89 e1             	mov    %r12,%rcx
    2a18:	48 89 ee             	mov    %rbp,%rsi
    2a1b:	48 89 df             	mov    %rbx,%rdi
    2a1e:	48 89 c2             	mov    %rax,%rdx
    2a21:	e8 8a ec ff ff       	call   16b0 <mi_page_fresh_alloc>
    2a26:	48 85 c0             	test   %rax,%rax
    2a29:	0f 84 4b ff ff ff    	je     297a <mi_find_page+0x6a>
    2a2f:	48 8b 70 28          	mov    0x28(%rax),%rsi
    2a33:	48 8d bb 60 0f 00 00 	lea    0xf60(%rbx),%rdi
    2a3a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    2a3f:	e8 00 00 00 00       	call   2a44 <mi_find_page+0x134>
			2a40: R_X86_64_PLT32	__mi_stat_increase-0x4
    2a44:	48 8d bb c0 0f 00 00 	lea    0xfc0(%rbx),%rdi
    2a4b:	be 01 00 00 00       	mov    $0x1,%esi
    2a50:	e8 00 00 00 00       	call   2a55 <mi_find_page+0x145>
			2a51: R_X86_64_PLT32	__mi_stat_counter_increase-0x4
    2a55:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2a5a:	e9 1b ff ff ff       	jmp    297a <mi_find_page+0x6a>
    2a5f:	90                   	nop
    2a60:	48 8b 50 18          	mov    0x18(%rax),%rdx
    2a64:	48 85 d2             	test   %rdx,%rdx
    2a67:	74 8f                	je     29f8 <mi_find_page+0xe8>
    2a69:	48 89 50 08          	mov    %rdx,0x8(%rax)
    2a6d:	48 c7 40 18 00 00 00 	movq   $0x0,0x18(%rax)
    2a74:	00 
    2a75:	c6 40 17 00          	movb   $0x0,0x17(%rax)
    2a79:	e9 f8 fe ff ff       	jmp    2976 <mi_find_page+0x66>
    2a7e:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    2a84:	0f 87 a5 fe ff ff    	ja     292f <mi_find_page+0x1f>
    2a8a:	48 83 e8 01          	sub    $0x1,%rax
    2a8e:	48 0f bd d0          	bsr    %rax,%rdx
    2a92:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    2a95:	48 d3 e8             	shr    %cl,%rax
    2a98:	83 e0 03             	and    $0x3,%eax
    2a9b:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
    2aa0:	48 8d 70 29          	lea    0x29(%rax),%rsi
    2aa4:	48 c1 e6 05          	shl    $0x5,%rsi
    2aa8:	e9 8c fe ff ff       	jmp    2939 <mi_find_page+0x29>
    2aad:	0f 1f 00             	nopl   (%rax)

0000000000002ab0 <mi_malloc_generic_fallback>:
    2ab0:	41 57                	push   %r15
    2ab2:	49 89 cf             	mov    %rcx,%r15
    2ab5:	41 56                	push   %r14
    2ab7:	49 89 f6             	mov    %rsi,%r14
    2aba:	41 55                	push   %r13
    2abc:	4d 89 c5             	mov    %r8,%r13
    2abf:	41 54                	push   %r12
    2ac1:	41 89 d4             	mov    %edx,%r12d
    2ac4:	55                   	push   %rbp
    2ac5:	53                   	push   %rbx
    2ac6:	48 83 ec 08          	sub    $0x8,%rsp
    2aca:	48 85 ff             	test   %rdi,%rdi
    2acd:	0f 84 89 00 00 00    	je     2b5c <mi_malloc_generic_fallback+0xac>
    2ad3:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2ad7:	48 89 fb             	mov    %rdi,%rbx
    2ada:	48 85 c0             	test   %rax,%rax
    2add:	74 71                	je     2b50 <mi_malloc_generic_fallback+0xa0>
    2adf:	48 8b 83 d8 00 00 00 	mov    0xd8(%rbx),%rax
    2ae6:	48 3d e7 03 00 00    	cmp    $0x3e7,%rax
    2aec:	0f 8f 26 01 00 00    	jg     2c18 <mi_malloc_generic_fallback+0x168>
    2af2:	4c 89 fa             	mov    %r15,%rdx
    2af5:	4c 89 f6             	mov    %r14,%rsi
    2af8:	48 89 df             	mov    %rbx,%rdi
    2afb:	e8 10 fe ff ff       	call   2910 <mi_find_page>
    2b00:	48 89 c5             	mov    %rax,%rbp
    2b03:	48 85 c0             	test   %rax,%rax
    2b06:	0f 84 84 01 00 00    	je     2c90 <mi_malloc_generic_fallback+0x1e0>
    2b0c:	4d 85 ed             	test   %r13,%r13
    2b0f:	74 04                	je     2b15 <mi_malloc_generic_fallback+0x65>
    2b11:	49 89 6d 00          	mov    %rbp,0x0(%r13)
    2b15:	48 89 df             	mov    %rbx,%rdi
    2b18:	41 0f b6 cc          	movzbl %r12b,%ecx
    2b1c:	4c 89 f2             	mov    %r14,%rdx
    2b1f:	48 89 ee             	mov    %rbp,%rsi
    2b22:	e8 00 00 00 00       	call   2b27 <mi_malloc_generic_fallback+0x77>
			2b23: R_X86_64_PLT32	_mi_page_malloc_zero-0x4
    2b27:	48 81 7d 28 00 28 00 	cmpq   $0x2800,0x28(%rbp)
    2b2e:	00 
    2b2f:	48 89 c3             	mov    %rax,%rbx
    2b32:	76 09                	jbe    2b3d <mi_malloc_generic_fallback+0x8d>
    2b34:	0f b7 45 36          	movzwl 0x36(%rbp),%eax
    2b38:	3b 45 10             	cmp    0x10(%rbp),%eax
    2b3b:	74 43                	je     2b80 <mi_malloc_generic_fallback+0xd0>
    2b3d:	48 83 c4 08          	add    $0x8,%rsp
    2b41:	48 89 d8             	mov    %rbx,%rax
    2b44:	5b                   	pop    %rbx
    2b45:	5d                   	pop    %rbp
    2b46:	41 5c                	pop    %r12
    2b48:	41 5d                	pop    %r13
    2b4a:	41 5e                	pop    %r14
    2b4c:	41 5f                	pop    %r15
    2b4e:	c3                   	ret
    2b4f:	90                   	nop
    2b50:	48 8d 05 00 00 00 00 	lea    0x0(%rip),%rax        # 2b57 <mi_malloc_generic_fallback+0xa7>
			2b53: R_X86_64_PC32	_mi_theap_empty_wrong-0x4
    2b57:	48 39 c7             	cmp    %rax,%rdi
    2b5a:	74 1a                	je     2b76 <mi_malloc_generic_fallback+0xc6>
    2b5c:	e8 00 00 00 00       	call   2b61 <mi_malloc_generic_fallback+0xb1>
			2b5d: R_X86_64_PLT32	_mi_thread_init-0x4
    2b61:	48 89 c3             	mov    %rax,%rbx
    2b64:	48 85 c0             	test   %rax,%rax
    2b67:	74 0d                	je     2b76 <mi_malloc_generic_fallback+0xc6>
    2b69:	48 8b 40 08          	mov    0x8(%rax),%rax
    2b6d:	48 85 c0             	test   %rax,%rax
    2b70:	0f 85 69 ff ff ff    	jne    2adf <mi_malloc_generic_fallback+0x2f>
    2b76:	31 db                	xor    %ebx,%ebx
    2b78:	eb c3                	jmp    2b3d <mi_malloc_generic_fallback+0x8d>
    2b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2b80:	4c 8b 6d 38          	mov    0x38(%rbp),%r13
    2b84:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    2b88:	b8 60 0e 00 00       	mov    $0xe60,%eax
    2b8d:	83 e2 01             	and    $0x1,%edx
    2b90:	75 3f                	jne    2bd1 <mi_malloc_generic_fallback+0x121>
    2b92:	66 83 7d 36 01       	cmpw   $0x1,0x36(%rbp)
    2b97:	48 8b 55 28          	mov    0x28(%rbp),%rdx
    2b9b:	0f 84 8f 01 00 00    	je     2d30 <mi_malloc_generic_fallback+0x280>
    2ba1:	48 83 c2 07          	add    $0x7,%rdx
    2ba5:	48 89 d1             	mov    %rdx,%rcx
    2ba8:	48 c1 e9 03          	shr    $0x3,%rcx
    2bac:	48 83 fa 47          	cmp    $0x47,%rdx
    2bb0:	0f 87 5b 02 00 00    	ja     2e11 <mi_malloc_generic_fallback+0x361>
    2bb6:	b8 40 05 00 00       	mov    $0x540,%eax
    2bbb:	48 83 f9 01          	cmp    $0x1,%rcx
    2bbf:	76 10                	jbe    2bd1 <mi_malloc_generic_fallback+0x121>
    2bc1:	48 83 c1 01          	add    $0x1,%rcx
    2bc5:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
    2bc9:	48 8d 41 29          	lea    0x29(%rcx),%rax
    2bcd:	48 c1 e0 05          	shl    $0x5,%rax
    2bd1:	48 89 ee             	mov    %rbp,%rsi
    2bd4:	4c 89 ef             	mov    %r13,%rdi
    2bd7:	4d 8d 64 05 00       	lea    0x0(%r13,%rax,1),%r12
    2bdc:	e8 00 00 00 00       	call   2be1 <mi_malloc_generic_fallback+0x131>
			2bdd: R_X86_64_PLT32	_mi_large_span_on_full-0x4
    2be1:	41 80 bd 11 01 00 00 	cmpb   $0x0,0x111(%r13)
    2be8:	00 
    2be9:	0f 84 09 01 00 00    	je     2cf8 <mi_malloc_generic_fallback+0x248>
    2bef:	31 f6                	xor    %esi,%esi
    2bf1:	48 89 ef             	mov    %rbp,%rdi
    2bf4:	e8 00 00 00 00       	call   2bf9 <mi_malloc_generic_fallback+0x149>
			2bf5: R_X86_64_PLT32	_mi_page_free_collect_no_unpurge-0x4
    2bf9:	8b 45 10             	mov    0x10(%rbp),%eax
    2bfc:	85 c0                	test   %eax,%eax
    2bfe:	0f 85 8c 01 00 00    	jne    2d90 <mi_malloc_generic_fallback+0x2e0>
    2c04:	4c 89 e6             	mov    %r12,%rsi
    2c07:	48 89 ef             	mov    %rbp,%rdi
    2c0a:	e8 00 00 00 00       	call   2c0f <mi_malloc_generic_fallback+0x15f>
			2c0b: R_X86_64_PLT32	_mi_page_free-0x4
    2c0f:	e9 29 ff ff ff       	jmp    2b3d <mi_malloc_generic_fallback+0x8d>
    2c14:	0f 1f 40 00          	nopl   0x0(%rax)
    2c18:	ba 40 42 0f 00       	mov    $0xf4240,%edx
    2c1d:	be 01 00 00 00       	mov    $0x1,%esi
    2c22:	bf 22 00 00 00       	mov    $0x22,%edi
    2c27:	48 01 83 e0 00 00 00 	add    %rax,0xe0(%rbx)
    2c2e:	48 c7 83 d8 00 00 00 	movq   $0x0,0xd8(%rbx)
    2c35:	00 00 00 00 
    2c39:	e8 00 00 00 00       	call   2c3e <mi_malloc_generic_fallback+0x18e>
			2c3a: R_X86_64_PLT32	mi_option_get_clamp-0x4
    2c3e:	48 3b 83 e0 00 00 00 	cmp    0xe0(%rbx),%rax
    2c45:	0f 8e 8d 00 00 00    	jle    2cd8 <mi_malloc_generic_fallback+0x228>
    2c4b:	48 8b 03             	mov    (%rbx),%rax
    2c4e:	48 85 c0             	test   %rax,%rax
    2c51:	74 11                	je     2c64 <mi_malloc_generic_fallback+0x1b4>
    2c53:	48 8b 28             	mov    (%rax),%rbp
    2c56:	e8 00 00 00 00       	call   2c5b <mi_malloc_generic_fallback+0x1ab>
			2c57: R_X86_64_PLT32	_mi_thread_id-0x4
    2c5b:	48 39 c5             	cmp    %rax,%rbp
    2c5e:	0f 84 6c 01 00 00    	je     2dd0 <mi_malloc_generic_fallback+0x320>
    2c64:	31 f6                	xor    %esi,%esi
    2c66:	48 89 df             	mov    %rbx,%rdi
    2c69:	e8 00 00 00 00       	call   2c6e <mi_malloc_generic_fallback+0x1be>
			2c6a: R_X86_64_PLT32	_mi_theap_collect_retired-0x4
    2c6e:	48 8b 03             	mov    (%rbx),%rax
    2c71:	48 89 df             	mov    %rbx,%rdi
    2c74:	c7 80 f4 01 00 00 00 	movl   $0x400,0x1f4(%rax)
    2c7b:	04 00 00 
    2c7e:	e8 00 00 00 00       	call   2c83 <mi_malloc_generic_fallback+0x1d3>
			2c7f: R_X86_64_PLT32	_mi_theap_purge_large_holes-0x4
    2c83:	e9 6a fe ff ff       	jmp    2af2 <mi_malloc_generic_fallback+0x42>
    2c88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    2c8f:	00 
    2c90:	be 01 00 00 00       	mov    $0x1,%esi
    2c95:	48 89 df             	mov    %rbx,%rdi
    2c98:	e8 00 00 00 00       	call   2c9d <mi_malloc_generic_fallback+0x1ed>
			2c99: R_X86_64_PLT32	mi_theap_collect-0x4
    2c9d:	4c 89 fa             	mov    %r15,%rdx
    2ca0:	4c 89 f6             	mov    %r14,%rsi
    2ca3:	48 89 df             	mov    %rbx,%rdi
    2ca6:	e8 65 fc ff ff       	call   2910 <mi_find_page>
    2cab:	48 89 c5             	mov    %rax,%rbp
    2cae:	48 85 c0             	test   %rax,%rax
    2cb1:	0f 85 55 fe ff ff    	jne    2b0c <mi_malloc_generic_fallback+0x5c>
    2cb7:	4c 89 f2             	mov    %r14,%rdx
    2cba:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 2cc1 <mi_malloc_generic_fallback+0x211>
			2cbd: R_X86_64_PC32	.LC3-0x4
    2cc1:	31 c0                	xor    %eax,%eax
    2cc3:	31 db                	xor    %ebx,%ebx
    2cc5:	bf 0c 00 00 00       	mov    $0xc,%edi
    2cca:	e8 00 00 00 00       	call   2ccf <mi_malloc_generic_fallback+0x21f>
			2ccb: R_X86_64_PLT32	_mi_error_message-0x4
    2ccf:	e9 69 fe ff ff       	jmp    2b3d <mi_malloc_generic_fallback+0x8d>
    2cd4:	0f 1f 40 00          	nopl   0x0(%rax)
    2cd8:	48 c7 83 e0 00 00 00 	movq   $0x0,0xe0(%rbx)
    2cdf:	00 00 00 00 
    2ce3:	31 f6                	xor    %esi,%esi
    2ce5:	48 89 df             	mov    %rbx,%rdi
    2ce8:	e8 00 00 00 00       	call   2ced <mi_malloc_generic_fallback+0x23d>
			2ce9: R_X86_64_PLT32	mi_theap_collect-0x4
    2ced:	e9 7c ff ff ff       	jmp    2c6e <mi_malloc_generic_fallback+0x1be>
    2cf2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2cf8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2cfc:	a8 01                	test   $0x1,%al
    2cfe:	0f 85 39 fe ff ff    	jne    2b3d <mi_malloc_generic_fallback+0x8d>
    2d04:	48 8b 45 38          	mov    0x38(%rbp),%rax
    2d08:	4c 89 e6             	mov    %r12,%rsi
    2d0b:	48 89 ea             	mov    %rbp,%rdx
    2d0e:	48 8d b8 60 0e 00 00 	lea    0xe60(%rax),%rdi
    2d15:	e8 f6 da ff ff       	call   810 <mi_page_queue_enqueue_from_ex.constprop.0>
    2d1a:	31 f6                	xor    %esi,%esi
    2d1c:	48 89 ef             	mov    %rbp,%rdi
    2d1f:	e8 fc d4 ff ff       	call   220 <mi_page_free_collect_ex.constprop.0>
    2d24:	e9 14 fe ff ff       	jmp    2b3d <mi_malloc_generic_fallback+0x8d>
    2d29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    2d30:	b8 40 0e 00 00       	mov    $0xe40,%eax
    2d35:	48 81 fa 00 00 08 00 	cmp    $0x80000,%rdx
    2d3c:	0f 87 8f fe ff ff    	ja     2bd1 <mi_malloc_generic_fallback+0x121>
    2d42:	8b 7d 68             	mov    0x68(%rbp),%edi
    2d45:	8d 4f fd             	lea    -0x3(%rdi),%ecx
    2d48:	83 f9 02             	cmp    $0x2,%ecx
    2d4b:	77 0a                	ja     2d57 <mi_malloc_generic_fallback+0x2a7>
    2d4d:	48 39 6d 58          	cmp    %rbp,0x58(%rbp)
    2d51:	0f 82 7a fe ff ff    	jb     2bd1 <mi_malloc_generic_fallback+0x121>
    2d57:	48 83 c2 07          	add    $0x7,%rdx
    2d5b:	48 89 d1             	mov    %rdx,%rcx
    2d5e:	48 c1 e9 03          	shr    $0x3,%rcx
    2d62:	48 83 fa 47          	cmp    $0x47,%rdx
    2d66:	0f 86 4a fe ff ff    	jbe    2bb6 <mi_malloc_generic_fallback+0x106>
    2d6c:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
    2d70:	48 0f bd d0          	bsr    %rax,%rdx
    2d74:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    2d77:	48 d3 e8             	shr    %cl,%rax
    2d7a:	83 e0 03             	and    $0x3,%eax
    2d7d:	48 8d 44 90 26       	lea    0x26(%rax,%rdx,4),%rax
    2d82:	48 c1 e0 05          	shl    $0x5,%rax
    2d86:	e9 46 fe ff ff       	jmp    2bd1 <mi_malloc_generic_fallback+0x121>
    2d8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2d90:	48 89 ee             	mov    %rbp,%rsi
    2d93:	4c 89 e7             	mov    %r12,%rdi
    2d96:	e8 45 d8 ff ff       	call   5e0 <mi_page_queue_remove>
    2d9b:	48 8b 75 38          	mov    0x38(%rbp),%rsi
    2d9f:	48 c7 45 38 00 00 00 	movq   $0x0,0x38(%rbp)
    2da6:	00 
    2da7:	48 8b 45 00          	mov    0x0(%rbp),%rax
    2dab:	48 89 c2             	mov    %rax,%rdx
    2dae:	83 e2 03             	and    $0x3,%edx
    2db1:	f0 48 0f b1 55 00    	lock cmpxchg %rdx,0x0(%rbp)
    2db7:	75 f2                	jne    2dab <mi_malloc_generic_fallback+0x2fb>
    2db9:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    2dbd:	48 89 ef             	mov    %rbp,%rdi
    2dc0:	e8 00 00 00 00       	call   2dc5 <mi_malloc_generic_fallback+0x315>
			2dc1: R_X86_64_PLT32	_mi_arenas_page_abandon-0x4
    2dc5:	e9 73 fd ff ff       	jmp    2b3d <mi_malloc_generic_fallback+0x8d>
    2dca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    2dd0:	48 83 43 20 01       	addq   $0x1,0x20(%rbx)
    2dd5:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 2ddc <mi_malloc_generic_fallback+0x32c>
			2dd8: R_X86_64_PC32	.bss+0x4
    2ddc:	48 85 c0             	test   %rax,%rax
    2ddf:	0f 84 7f fe ff ff    	je     2c64 <mi_malloc_generic_fallback+0x1b4>
    2de5:	48 8b 13             	mov    (%rbx),%rdx
    2de8:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    2dec:	0f 85 72 fe ff ff    	jne    2c64 <mi_malloc_generic_fallback+0x1b4>
    2df2:	c6 42 50 01          	movb   $0x1,0x50(%rdx)
    2df6:	48 8b 15 00 00 00 00 	mov    0x0(%rip),%rdx        # 2dfd <mi_malloc_generic_fallback+0x34d>
			2df9: R_X86_64_PC32	.bss-0x4
    2dfd:	31 ff                	xor    %edi,%edi
    2dff:	48 8b 73 20          	mov    0x20(%rbx),%rsi
    2e03:	ff d0                	call   *%rax
    2e05:	48 8b 03             	mov    (%rbx),%rax
    2e08:	c6 40 50 00          	movb   $0x0,0x50(%rax)
    2e0c:	e9 53 fe ff ff       	jmp    2c64 <mi_malloc_generic_fallback+0x1b4>
    2e11:	48 81 f9 00 00 01 00 	cmp    $0x10000,%rcx
    2e18:	0f 86 4e ff ff ff    	jbe    2d6c <mi_malloc_generic_fallback+0x2bc>
    2e1e:	b8 40 0e 00 00       	mov    $0xe40,%eax
    2e23:	e9 a9 fd ff ff       	jmp    2bd1 <mi_malloc_generic_fallback+0x121>
    2e28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    2e2f:	00 

0000000000002e30 <_mi_page_init>:
    2e30:	41 57                	push   %r15
    2e32:	41 56                	push   %r14
    2e34:	41 55                	push   %r13
    2e36:	41 54                	push   %r12
    2e38:	49 89 fc             	mov    %rdi,%r12
    2e3b:	48 89 f7             	mov    %rsi,%rdi
    2e3e:	55                   	push   %rbp
    2e3f:	53                   	push   %rbx
    2e40:	48 89 f3             	mov    %rsi,%rbx
    2e43:	48 83 ec 08          	sub    $0x8,%rsp
    2e47:	e8 00 00 00 00       	call   2e4c <_mi_page_init+0x1c>
			2e48: R_X86_64_PLT32	_mi_page_purged_reset-0x4
    2e4c:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
    2e51:	74 1d                	je     2e70 <_mi_page_init+0x40>
    2e53:	b8 01 00 00 00       	mov    $0x1,%eax
    2e58:	48 83 c4 08          	add    $0x8,%rsp
    2e5c:	5b                   	pop    %rbx
    2e5d:	5d                   	pop    %rbp
    2e5e:	41 5c                	pop    %r12
    2e60:	41 5d                	pop    %r13
    2e62:	41 5e                	pop    %r14
    2e64:	41 5f                	pop    %r15
    2e66:	c3                   	ret
    2e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2e6e:	00 00 
    2e70:	0f b7 43 14          	movzwl 0x14(%rbx),%eax
    2e74:	0f b7 6b 36          	movzwl 0x36(%rbx),%ebp
    2e78:	66 39 e8             	cmp    %bp,%ax
    2e7b:	73 d6                	jae    2e53 <_mi_page_init+0x23>
    2e7d:	48 83 bb a0 00 00 00 	cmpq   $0x0,0xa0(%rbx)
    2e84:	00 
    2e85:	74 14                	je     2e9b <_mi_page_init+0x6b>
    2e87:	49 8b 34 24          	mov    (%r12),%rsi
    2e8b:	48 89 df             	mov    %rbx,%rdi
    2e8e:	e8 00 00 00 00       	call   2e93 <_mi_page_init+0x63>
			2e8f: R_X86_64_PLT32	_mi_page_unpublish_retired-0x4
    2e93:	0f b7 6b 36          	movzwl 0x36(%rbx),%ebp
    2e97:	0f b7 43 14          	movzwl 0x14(%rbx),%eax
    2e9b:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
    2e9f:	48 29 c5             	sub    %rax,%rbp
    2ea2:	b8 01 00 00 00       	mov    $0x1,%eax
    2ea7:	49 81 fd ff 0f 00 00 	cmp    $0xfff,%r13
    2eae:	0f 86 14 01 00 00    	jbe    2fc8 <_mi_page_init+0x198>
    2eb4:	48 39 c5             	cmp    %rax,%rbp
    2eb7:	44 0f b7 7b 34       	movzwl 0x34(%rbx),%r15d
    2ebc:	48 0f 47 e8          	cmova  %rax,%rbp
    2ec0:	e8 00 00 00 00       	call   2ec5 <_mi_page_init+0x95>
			2ec1: R_X86_64_PLT32	_mi_os_page_size-0x4
    2ec5:	4c 0f af f8          	imul   %rax,%r15
    2ec9:	4d 85 ff             	test   %r15,%r15
    2ecc:	0f 84 ba 00 00 00    	je     2f8c <_mi_page_init+0x15c>
    2ed2:	4c 89 e8             	mov    %r13,%rax
    2ed5:	48 0f af c5          	imul   %rbp,%rax
    2ed9:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
    2edf:	76 19                	jbe    2efa <_mi_page_init+0xca>
    2ee1:	bd 00 00 01 00       	mov    $0x10000,%ebp
    2ee6:	4d 85 ed             	test   %r13,%r13
    2ee9:	74 0f                	je     2efa <_mi_page_init+0xca>
    2eeb:	49 8d 85 ff ff 00 00 	lea    0xffff(%r13),%rax
    2ef2:	31 d2                	xor    %edx,%edx
    2ef4:	49 f7 f5             	div    %r13
    2ef7:	48 89 c5             	mov    %rax,%rbp
    2efa:	44 0f b7 73 14       	movzwl 0x14(%rbx),%r14d
    2eff:	e8 00 00 00 00       	call   2f04 <_mi_page_init+0xd4>
			2f00: R_X86_64_PLT32	_mi_os_page_size-0x4
    2f04:	8b 73 30             	mov    0x30(%rbx),%esi
    2f07:	49 89 d8             	mov    %rbx,%r8
    2f0a:	48 89 c1             	mov    %rax,%rcx
    2f0d:	49 01 ee             	add    %rbp,%r14
    2f10:	b8 00 40 00 00       	mov    $0x4000,%eax
    2f15:	4d 0f af f5          	imul   %r13,%r14
    2f19:	48 39 c1             	cmp    %rax,%rcx
    2f1c:	48 0f 42 c8          	cmovb  %rax,%rcx
    2f20:	48 c1 e6 04          	shl    $0x4,%rsi
    2f24:	48 01 de             	add    %rbx,%rsi
    2f27:	83 7b 68 06          	cmpl   $0x6,0x68(%rbx)
    2f2b:	0f 84 bf 00 00 00    	je     2ff0 <_mi_page_init+0x1c0>
    2f31:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
    2f35:	48 89 f7             	mov    %rsi,%rdi
    2f38:	4c 29 c7             	sub    %r8,%rdi
    2f3b:	49 01 c6             	add    %rax,%r14
    2f3e:	49 01 fe             	add    %rdi,%r14
    2f41:	48 85 c1             	test   %rax,%rcx
    2f44:	0f 84 96 00 00 00    	je     2fe0 <_mi_page_init+0x1b0>
    2f4a:	4c 89 f0             	mov    %r14,%rax
    2f4d:	31 d2                	xor    %edx,%edx
    2f4f:	48 f7 f1             	div    %rcx
    2f52:	49 29 d6             	sub    %rdx,%r14
    2f55:	4d 39 f7             	cmp    %r14,%r15
    2f58:	73 3c                	jae    2f96 <_mi_page_init+0x166>
    2f5a:	4c 89 f2             	mov    %r14,%rdx
    2f5d:	49 8b 7c 24 10       	mov    0x10(%r12),%rdi
    2f62:	31 c9                	xor    %ecx,%ecx
    2f64:	4b 8d 34 38          	lea    (%r8,%r15,1),%rsi
    2f68:	4c 29 fa             	sub    %r15,%rdx
    2f6b:	e8 00 00 00 00       	call   2f70 <_mi_page_init+0x140>
			2f6c: R_X86_64_PLT32	_mi_os_commit-0x4
    2f70:	84 c0                	test   %al,%al
    2f72:	0f 84 e0 fe ff ff    	je     2e58 <_mi_page_init+0x28>
    2f78:	e8 00 00 00 00       	call   2f7d <_mi_page_init+0x14d>
			2f79: R_X86_64_PLT32	_mi_os_page_size-0x4
    2f7d:	31 d2                	xor    %edx,%edx
    2f7f:	48 89 c1             	mov    %rax,%rcx
    2f82:	4c 89 f0             	mov    %r14,%rax
    2f85:	48 f7 f1             	div    %rcx
    2f88:	66 89 43 34          	mov    %ax,0x34(%rbx)
    2f8c:	8b 73 30             	mov    0x30(%rbx),%esi
    2f8f:	48 c1 e6 04          	shl    $0x4,%rsi
    2f93:	48 01 de             	add    %rbx,%rsi
    2f96:	0f b7 43 14          	movzwl 0x14(%rbx),%eax
    2f9a:	48 89 df             	mov    %rbx,%rdi
    2f9d:	48 01 e8             	add    %rbp,%rax
    2fa0:	49 0f af c5          	imul   %r13,%rax
    2fa4:	48 01 c6             	add    %rax,%rsi
    2fa7:	e8 00 00 00 00       	call   2fac <_mi_page_init+0x17c>
			2fa8: R_X86_64_PLT32	_mi_page_unpurge_unformed_upto-0x4
    2fac:	48 89 ea             	mov    %rbp,%rdx
    2faf:	4c 89 ee             	mov    %r13,%rsi
    2fb2:	48 89 df             	mov    %rbx,%rdi
    2fb5:	e8 46 d0 ff ff       	call   0 <mi_page_free_list_extend>
    2fba:	66 01 6b 14          	add    %bp,0x14(%rbx)
    2fbe:	e9 90 fe ff ff       	jmp    2e53 <_mi_page_init+0x23>
    2fc3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2fc8:	b8 00 10 00 00       	mov    $0x1000,%eax
    2fcd:	31 d2                	xor    %edx,%edx
    2fcf:	49 f7 f5             	div    %r13
    2fd2:	e9 dd fe ff ff       	jmp    2eb4 <_mi_page_init+0x84>
    2fd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    2fde:	00 00 
    2fe0:	48 f7 d9             	neg    %rcx
    2fe3:	49 21 ce             	and    %rcx,%r14
    2fe6:	e9 6a ff ff ff       	jmp    2f55 <_mi_page_init+0x125>
    2feb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    2ff0:	49 89 f0             	mov    %rsi,%r8
    2ff3:	66 45 31 c0          	xor    %r8w,%r8w
    2ff7:	e9 35 ff ff ff       	jmp    2f31 <_mi_page_init+0x101>
    2ffc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003000 <_mi_deferred_free>:
    3000:	48 8b 07             	mov    (%rdi),%rax
    3003:	48 85 c0             	test   %rax,%rax
    3006:	74 58                	je     3060 <_mi_deferred_free+0x60>
    3008:	41 54                	push   %r12
    300a:	55                   	push   %rbp
    300b:	89 f5                	mov    %esi,%ebp
    300d:	53                   	push   %rbx
    300e:	4c 8b 20             	mov    (%rax),%r12
    3011:	48 89 fb             	mov    %rdi,%rbx
    3014:	e8 00 00 00 00       	call   3019 <_mi_deferred_free+0x19>
			3015: R_X86_64_PLT32	_mi_thread_id-0x4
    3019:	49 39 c4             	cmp    %rax,%r12
    301c:	74 0a                	je     3028 <_mi_deferred_free+0x28>
    301e:	5b                   	pop    %rbx
    301f:	5d                   	pop    %rbp
    3020:	41 5c                	pop    %r12
    3022:	c3                   	ret
    3023:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3028:	48 83 43 20 01       	addq   $0x1,0x20(%rbx)
    302d:	48 8b 05 00 00 00 00 	mov    0x0(%rip),%rax        # 3034 <_mi_deferred_free+0x34>
			3030: R_X86_64_PC32	.bss+0x4
    3034:	48 85 c0             	test   %rax,%rax
    3037:	74 e5                	je     301e <_mi_deferred_free+0x1e>
    3039:	48 8b 13             	mov    (%rbx),%rdx
    303c:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    3040:	75 dc                	jne    301e <_mi_deferred_free+0x1e>
    3042:	c6 42 50 01          	movb   $0x1,0x50(%rdx)
    3046:	48 8b 15 00 00 00 00 	mov    0x0(%rip),%rdx        # 304d <_mi_deferred_free+0x4d>
			3049: R_X86_64_PC32	.bss-0x4
    304d:	40 0f b6 fd          	movzbl %bpl,%edi
    3051:	48 8b 73 20          	mov    0x20(%rbx),%rsi
    3055:	ff d0                	call   *%rax
    3057:	48 8b 03             	mov    (%rbx),%rax
    305a:	c6 40 50 00          	movb   $0x0,0x50(%rax)
    305e:	eb be                	jmp    301e <_mi_deferred_free+0x1e>
    3060:	c3                   	ret
    3061:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3068:	00 00 00 00 
    306c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003070 <mi_register_deferred_free>:
    3070:	48 89 35 00 00 00 00 	mov    %rsi,0x0(%rip)        # 3077 <mi_register_deferred_free+0x7>
			3073: R_X86_64_PC32	.bss-0x4
    3077:	48 89 3d 00 00 00 00 	mov    %rdi,0x0(%rip)        # 307e <mi_register_deferred_free+0xe>
			307a: R_X86_64_PC32	.bss+0x4
    307e:	c3                   	ret
    307f:	90                   	nop

0000000000003080 <_mi_malloc_generic>:
    3080:	41 56                	push   %r14
    3082:	49 89 c8             	mov    %rcx,%r8
    3085:	48 89 d1             	mov    %rdx,%rcx
    3088:	41 55                	push   %r13
    308a:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
    308e:	41 54                	push   %r12
    3090:	41 89 d4             	mov    %edx,%r12d
    3093:	55                   	push   %rbp
    3094:	41 83 e4 01          	and    $0x1,%r12d
    3098:	48 89 f5             	mov    %rsi,%rbp
    309b:	53                   	push   %rbx
    309c:	48 89 fb             	mov    %rdi,%rbx
    309f:	48 83 ec 10          	sub    $0x10,%rsp
    30a3:	48 85 ff             	test   %rdi,%rdi
    30a6:	74 3f                	je     30e7 <_mi_malloc_generic+0x67>
    30a8:	4c 8b 37             	mov    (%rdi),%r14
    30ab:	4d 85 f6             	test   %r14,%r14
    30ae:	0f 85 cc 00 00 00    	jne    3180 <_mi_malloc_generic+0x100>
    30b4:	48 8b 43 08          	mov    0x8(%rbx),%rax
    30b8:	48 85 c0             	test   %rax,%rax
    30bb:	74 2a                	je     30e7 <_mi_malloc_generic+0x67>
    30bd:	48 8b 83 d8 00 00 00 	mov    0xd8(%rbx),%rax
    30c4:	48 83 c0 01          	add    $0x1,%rax
    30c8:	48 89 83 d8 00 00 00 	mov    %rax,0xd8(%rbx)
    30cf:	48 3d e7 03 00 00    	cmp    $0x3e7,%rax
    30d5:	7f 10                	jg     30e7 <_mi_malloc_generic+0x67>
    30d7:	48 85 c9             	test   %rcx,%rcx
    30da:	75 0b                	jne    30e7 <_mi_malloc_generic+0x67>
    30dc:	48 81 fd ff 27 00 00 	cmp    $0x27ff,%rbp
    30e3:	76 23                	jbe    3108 <_mi_malloc_generic+0x88>
    30e5:	31 c9                	xor    %ecx,%ecx
    30e7:	48 83 c4 10          	add    $0x10,%rsp
    30eb:	41 0f b6 d4          	movzbl %r12b,%edx
    30ef:	48 89 ee             	mov    %rbp,%rsi
    30f2:	48 89 df             	mov    %rbx,%rdi
    30f5:	5b                   	pop    %rbx
    30f6:	5d                   	pop    %rbp
    30f7:	41 5c                	pop    %r12
    30f9:	41 5d                	pop    %r13
    30fb:	41 5e                	pop    %r14
    30fd:	e9 ae f9 ff ff       	jmp    2ab0 <mi_malloc_generic_fallback>
    3102:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3108:	48 8d 55 07          	lea    0x7(%rbp),%rdx
    310c:	48 89 d0             	mov    %rdx,%rax
    310f:	48 c1 e8 03          	shr    $0x3,%rax
    3113:	48 83 fa 47          	cmp    $0x47,%rdx
    3117:	0f 87 ee 00 00 00    	ja     320b <_mi_malloc_generic+0x18b>
    311d:	48 83 f8 01          	cmp    $0x1,%rax
    3121:	0f 86 a9 00 00 00    	jbe    31d0 <_mi_malloc_generic+0x150>
    3127:	48 83 c0 01          	add    $0x1,%rax
    312b:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
    312f:	48 83 c0 29          	add    $0x29,%rax
    3133:	48 89 c2             	mov    %rax,%rdx
    3136:	48 c1 e2 05          	shl    $0x5,%rdx
    313a:	48 c1 e0 05          	shl    $0x5,%rax
    313e:	48 8b 34 03          	mov    (%rbx,%rax,1),%rsi
    3142:	48 85 f6             	test   %rsi,%rsi
    3145:	0f 84 94 00 00 00    	je     31df <_mi_malloc_generic+0x15f>
    314b:	48 83 7e 08 00       	cmpq   $0x0,0x8(%rsi)
    3150:	0f 84 d7 00 00 00    	je     322d <_mi_malloc_generic+0x1ad>
    3156:	c6 46 16 00          	movb   $0x0,0x16(%rsi)
    315a:	4d 85 c0             	test   %r8,%r8
    315d:	74 03                	je     3162 <_mi_malloc_generic+0xe2>
    315f:	49 89 30             	mov    %rsi,(%r8)
    3162:	48 83 c4 10          	add    $0x10,%rsp
    3166:	41 0f b6 cc          	movzbl %r12b,%ecx
    316a:	48 89 ea             	mov    %rbp,%rdx
    316d:	48 89 df             	mov    %rbx,%rdi
    3170:	5b                   	pop    %rbx
    3171:	5d                   	pop    %rbp
    3172:	41 5c                	pop    %r12
    3174:	41 5d                	pop    %r13
    3176:	41 5e                	pop    %r14
    3178:	e9 00 00 00 00       	jmp    317d <_mi_malloc_generic+0xfd>
			3179: R_X86_64_PLT32	_mi_page_malloc_zero-0x4
    317d:	0f 1f 00             	nopl   (%rax)
    3180:	49 8b 86 e8 00 00 00 	mov    0xe8(%r14),%rax
    3187:	48 85 c0             	test   %rax,%rax
    318a:	0f 84 24 ff ff ff    	je     30b4 <_mi_malloc_generic+0x34>
    3190:	4d 8b 2e             	mov    (%r14),%r13
    3193:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    3198:	48 89 0c 24          	mov    %rcx,(%rsp)
    319c:	e8 00 00 00 00       	call   31a1 <_mi_malloc_generic+0x121>
			319d: R_X86_64_PLT32	_mi_thread_id-0x4
    31a1:	48 8b 0c 24          	mov    (%rsp),%rcx
    31a5:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    31aa:	49 39 c5             	cmp    %rax,%r13
    31ad:	0f 85 01 ff ff ff    	jne    30b4 <_mi_malloc_generic+0x34>
    31b3:	4c 89 f7             	mov    %r14,%rdi
    31b6:	e8 00 00 00 00       	call   31bb <_mi_malloc_generic+0x13b>
			31b7: R_X86_64_PLT32	_mi_park_leave-0x4
    31bb:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    31c0:	48 8b 0c 24          	mov    (%rsp),%rcx
    31c4:	e9 eb fe ff ff       	jmp    30b4 <_mi_malloc_generic+0x34>
    31c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    31d0:	ba 40 05 00 00       	mov    $0x540,%edx
    31d5:	b8 2a 00 00 00       	mov    $0x2a,%eax
    31da:	e9 5b ff ff ff       	jmp    313a <_mi_malloc_generic+0xba>
    31df:	48 8d 34 13          	lea    (%rbx,%rdx,1),%rsi
    31e3:	48 89 df             	mov    %rbx,%rdi
    31e6:	ba 01 00 00 00       	mov    $0x1,%edx
    31eb:	4c 89 04 24          	mov    %r8,(%rsp)
    31ef:	e8 6c f3 ff ff       	call   2560 <mi_page_queue_find_free_ex>
    31f4:	4c 8b 04 24          	mov    (%rsp),%r8
    31f8:	48 85 c0             	test   %rax,%rax
    31fb:	48 89 c6             	mov    %rax,%rsi
    31fe:	0f 85 56 ff ff ff    	jne    315a <_mi_malloc_generic+0xda>
    3204:	31 c9                	xor    %ecx,%ecx
    3206:	e9 dc fe ff ff       	jmp    30e7 <_mi_malloc_generic+0x67>
    320b:	48 83 e8 01          	sub    $0x1,%rax
    320f:	48 0f bd d0          	bsr    %rax,%rdx
    3213:	8d 4a fe             	lea    -0x2(%rdx),%ecx
    3216:	48 d3 e8             	shr    %cl,%rax
    3219:	83 e0 03             	and    $0x3,%eax
    321c:	48 8d 44 90 26       	lea    0x26(%rax,%rdx,4),%rax
    3221:	48 89 c2             	mov    %rax,%rdx
    3224:	48 c1 e2 05          	shl    $0x5,%rdx
    3228:	e9 0d ff ff ff       	jmp    313a <_mi_malloc_generic+0xba>
    322d:	48 8b 46 18          	mov    0x18(%rsi),%rax
    3231:	48 85 c0             	test   %rax,%rax
    3234:	74 a9                	je     31df <_mi_malloc_generic+0x15f>
    3236:	48 89 46 08          	mov    %rax,0x8(%rsi)
    323a:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    3241:	00 
    3242:	c6 46 17 00          	movb   $0x0,0x17(%rsi)
    3246:	e9 0b ff ff ff       	jmp    3156 <_mi_malloc_generic+0xd6>
