V7 preflight update (not measured): specialization of the selected retired large singleton removal has a focused RED/GREEN work-count test and clean implementation review. The C and secure C++ large-span tests pass, as does the actual ASan + owner-gate large-span test.

Additional validation exposed two results that are not waived:

1. Secure C++ Debug (`MI_SECURE=5`, `MI_DEBUG=3`) cannot compile unchanged `test/test-purge-holes.c`: gotos to `done` at line 1939 cross initialized locals in `test_owner_sweep_pacing`. Reproduced with identical compiler flags against frozen baseline `227eef06ff03f92966f38508441d6c2f60a75135`; the test source is byte-identical. Exact command and diagnostics are retained locally.
2. The candidate ASan + owner-gate purge suite passed 34 cases but failed `new-thread-does-not-sweep-at-once` at line 2313: 6 discards observed, expected 0. The reuse test passed. A matching frozen-baseline build is in progress to attribute this failure; no unchanged candidate rerun is being used to erase it.

Under rule 7, optimization implementation/measurement is stopped pending validation attribution and disposition. No performance workflow has been dispatched and no gain is claimed. Actual executables, logs and source evidence are retained.
